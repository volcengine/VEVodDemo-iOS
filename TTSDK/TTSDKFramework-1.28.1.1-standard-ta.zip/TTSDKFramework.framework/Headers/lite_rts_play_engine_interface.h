/*
 * Copyright 2020 @bytedance
 *  Created on: Seq 05, 2020
 */

#pragma once

#include "lite_rts_play_engine_define.h"

namespace byterts {

class IRTSPlayEngineObserver {
 public:
    virtual void OnEventNotify(RTSPlayEngineEvent event, void* biz_data) = 0;

    virtual void OnErrorNotify(RTSPlayEngineError error, void* biz_data) = 0;

    virtual void OnAudioFrame(const RTSAudioFrame& aframe) = 0;

    virtual void OnVideoFrame(const RTSVideoFrame& vframe) = 0;

    virtual void OnLogPrint(RTSPlayEngineLogLevel level, const char* content, void* biz_data) = 0;

    virtual void OnTracePrint(
            RTSPlayEngineTraceLevel level, const char* trace_tag, const char* content, void* biz_data) = 0;

    virtual ~IRTSPlayEngineObserver() = default;
};

class IRTSPlayEngine {
 public:

     virtual int32_t Init(IRTSPlayEngineObserver* observer, RTSPlayEngineConfigure config) = 0;

     virtual int32_t UnInit() = 0;

     virtual int32_t Prepare() = 0;

     virtual int32_t Start() = 0;

     virtual int32_t Stop(RTSStopReason reason) = 0;

     virtual bool IsPlaying() = 0;

     virtual const char* GetSdkVersion() const = 0;

     virtual int32_t SetParameter(const char* params) = 0;

     virtual bool SetConnectRetryCount(int count, int interval) = 0;

     virtual int32_t GetStatsReport(RTSPlayEngineStats* rts_stats) = 0;

    virtual int32_t GetTracePrint(RTSTraceType trace_type, RTSPlayEngineTrace* rts_trace) = 0;

     virtual bool SetAudioVolume(int32_t volume) = 0;

     virtual void SetAudioMute(bool mute) = 0;
     virtual ~IRTSPlayEngine() = default;
};

BYTE_RTS_EXPORT IRTSPlayEngine* CreateRtsPlayEngine(const char* app_id);

BYTE_RTS_EXPORT void DestroyRtsPlayEngine(IRTSPlayEngine* engine);

} /* namespace byterts */
