/*
 * Copyright 2020 @bytedance
 *  Created on: Seq 05, 2020
 */

#pragma once

#include <stdint.h>

#ifndef BYTE_RTS_EXPORT
#ifdef WIN32
#define BYTE_RTS_EXPORT extern "C" __declspec(dllexport)
#else // WIN32
#define BYTE_RTS_EXPORT __attribute__((__visibility__("default")))
#endif // WIN32
#endif // BYTE_RTS_EXPORT

namespace byterts {

#define RTS_MAX_BUF_SIZE    1024
#define CONTENT_MIN_SIZE    512
#define CONTENT_MAX_SIZE    4096
#define SEI_BUFFER_MAX_SIZE 16

enum RTSPlayEngineEvent {
    kRtsPlayInited,                // init player(unused)
    kRtsPlaySendOffer,             // send offer
    kRtsPlayRecvAnswer,            // receive answer
    kRtsPlayPrepared,              // prepare offer(unused)
    kRtsPlayStarted,               // start player(unused)
    kRtsPlayStopped,               // stop player(unused)
    kRtsPlayUnInited,              // uninit player(unused)
    kRtsPlayIceConnected,          // ice connect success
    kRtsPlayRecvFirstAudioPacket,  // receive first audio packet
    kRtsPlayRecvFirstVideoPacket,  // receive first video packet
    kRtsPlayRecvFirstAudioFrame,   // receive first audio frame
    kRtsPlayRecvFirstVideoFrame,   // receive first video frame
    kRtsPlayHttpStateChange,       // http state change
};

enum RTSPlayEngineError {
    kRtsPlayErrorNone = 0,
    kRtsPlayErrorIllegalParameters,
    kRtsPlayErrorState,
    
    kRtsPlayErrorPlayBase = 30000,
    kRtsPlayErrorPlayPrepareTimeout,
    
    kRtsPlayErrorSourceBase = 31000,
    kRtsPlayErrorSourceInit,
    kRtsPlayErrorSourcePrepare,
    kRtsPlayErrorSourceStart,
    kRtsPlayErrorSourceStop,
    kRtsPlayErrorSourceUnInit,
    kRtsPlayErrorSourceExpectIpFail,
    kRtsPlayErrorSourceFetchSDPFail,
    kRtsPlayErrorSourceNetRequestFail,

    kRtsPlayErrorPeerBase = 32000,
    kRtsPlayErrorPeerInit,
    kRtsPlayErrorPeerPrepare,
    kRtsPlayErrorPeerStart,
    kRtsPlayErrorPeerStop,
    kRtsPlayErrorPeerUnInit,
    kRtsPlayErrorPeerDecode,        // decoder error
    kRtsPlayErrorPeerNetworkIO,     // network error
    kRtsPlayErrorPeerCreateSDP,     // create sdp error
    kRtsPlayErrorPeerSetLocalSDP,   // set local sdp error
    kRtsPlayErrorPeerSetRemoteSDP,  // set remote sdp error
    kRtsPlayErrorNetworkInterrupt,
};

enum RTSStopReason {
    kRtsStopNormal = 0,
    kRtsStopError,
    kRtsStopTimeout,
};

enum RTSPlayEngineLogLevel {
    kRtsPlayLogLevelVerbose = 0,
    kRtsPlayLogLevelDebug,
    kRtsPlayLogLevelInfo,
    kRtsPlayLogLevelWarning,
    kRtsPlayLogLevelError,
    kRtsPlayLogLevelFatal,
};

enum RTSPlayEngineTraceLevel {
    kRtsPlayTraceLevelVerbose = 0,
    kRtcPlayTraceLevelDebug,
    kRtsPlayTraceLevelInfo,
    kRtsPlayTraceLevelWarning,
    kRtsPlayTraceLevelError,
    kRtsPlayTraceLevelFatal,
};

enum RTSVenderType {
    kRtsVenderTypeTencent = 0,
    kRtsVenderTypeAlibaba,
    kRtsVenderTypeByte,
    kRtsVenderTypeOther,
};

struct RTSPlayEngineConfigure {
    RTSVenderType e_vendor_type = kRtsVenderTypeTencent;
    const char* play_uri;
    const char* scfg_path;
    const char* session_id;
    bool enable_dtls;
    bool enable_hardware_decode;
    bool hardware_with_oes;
    int jitter_buffer_ms;
    int jitter_buffer_max_ms;
    void* jvm;         /* JavaVM* for andriod */
    void* app_context; /* jobject* for android */
};

enum RTSTraceType {
    kRtsStopEventTrace = 0,
    kRtsUnInitEventTrace,
};

struct RTSPlayEngineStats {
    char json_content[CONTENT_MAX_SIZE];
};

struct RTSPlayEngineTrace {
    RTSPlayEngineTraceLevel trace_level;
    char stats_tag[CONTENT_MIN_SIZE];
    char player_stats[CONTENT_MAX_SIZE];
};

enum RTS_AUDIO_FRAME_TYPE {
    FRAME_TYPE_PCM16 = 0,  ///< PCM 16bit little endian
    FRAME_TYPE_AAC,
};

enum RTS_AUDIO_AAC_AOT {
    kRTSAOT_NONE = -1,
    kRTSAOT_AAC_LC = 2, /**< Low Complexity object                     */
    kRTSAOT_SBR = 5,
    kRTSAOT_PS = 29, /**< PS, Parametric Stereo (includes SBR)      */
};

struct RTSAudioFrame {
    RTS_AUDIO_FRAME_TYPE type;
    void* data;
    int32_t samples;
    int32_t channels;
    int32_t samplesPerSec;
    int64_t renderTimeMs;
    int32_t dataSize;
    RTS_AUDIO_AAC_AOT aacAot;
};

enum RTS_VIDEO_FRAME_TYPE {
    // YUV image with i420 layout, also known as yuv420p
    kVideoPixelFormatI420,
    kVideoPixelFormatTexture,
    kVideoPixelFormatNV12,
    kVideoEncoded = 100,
};

enum RTS_VIDEO_CODEC_STANDARD {
    kH264 = 0,
    kBYTEVC1 = 1,
};

enum RTS_VIDEO_PICTURE_TYPE {
    kUnknow = 0,
    kIntra = 1,
    kPredicted = 2,
    kBiPredicted = 3,
    kEmpty = 4,
    kLtrRecovery = 5,  // a frame that reference a long-term-reference-frame
};

struct RTSSEIBuffer {
    uint8_t* seiData;
    int32_t seiDataSize;
};

struct RTSYuvContext {
    int32_t strideY;       ///< stride of Y data buffer
    int32_t strideU;       ///< stride of U data buffer
    int32_t strideV;       ///< stride of V data buffer
    const uint8_t* dataY;  ///< Y data buffer
    const uint8_t* dataU;  ///< U data buffer
    const uint8_t* dataV;  ///< V data buffer
};

struct RTSTextureContext{
    int textureId;         /// oes texture id
    int textureType;       /// oes
    void* eglBase;          /// egl context
    void* eglNativeHandle;   //egl native handle
    float mat4x4[16];       ///render matrix
};

struct RTSEncodedContext {
    uint8_t* data;
    int32_t dataSize;
    RTS_VIDEO_CODEC_STANDARD codec;
    RTS_VIDEO_PICTURE_TYPE picType;
};

struct RTSVideoFrame {
    RTS_VIDEO_FRAME_TYPE type;
    int32_t width;         ///< width of video frame
    int32_t height;        ///< height of video frame
    int32_t rotation;      ///< rotation of this frame (0, 90, 180, 270)
    int64_t renderTimestamp;
    int32_t seiBufferArraySize;
    RTSSEIBuffer seiBufferArray[SEI_BUFFER_MAX_SIZE];

    // only one of these 3 fields is valid
    RTSYuvContext* yuvContext;
    RTSTextureContext* textureContext;
    RTSEncodedContext* encodedContext;
};
}  // namespace byterts
