
#import "LCAudioScore.h"

NS_ASSUME_NONNULL_BEGIN

@interface LCAudioScore (privateApi)

- (void)process:(short *)input inNumberFrames:(int)inNumberFrames channels:(int)channels;

@end

NS_ASSUME_NONNULL_END
