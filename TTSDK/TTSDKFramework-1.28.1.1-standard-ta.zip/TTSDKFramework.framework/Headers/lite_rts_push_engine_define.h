/*
 * Copyright 2021 @bytedance
 * Created on: Sept 15, 2021.
 */

#pragma once

#include "lite_rts_play_engine_define.h"

namespace byterts {

enum RTSPushEngineEvent {
    kRtsPushInited,                // init Pusher(unused)
    kRtsPushSendOffer,             // send offer
    kRtsPushRecvAnswer,            // receive answer
    kRtsPushPrepared,              // prepare offer(unused)
    kRtsPushStopped,               // stop Pusher(unused)
    kRtsPushUnInited,              // uninit Pusher(unused)
    kRtsPushHttpStateChange,       // http state change
    kRtsPushIceConnected,          // ice connect success
    kRtsPushEncoderRequestKey,     // encoder ask key frame
    kRtsPushEncoderSetRate,        // set bit_rate and frame_rate
};

enum RTSPushEngineError {
    kRtsPushErrorNone = 0,
    kRtsPushErrorIllegalParameters,
    kRtsPushErrorState,
    
    kRtsPushErrorPushBase = 30000,
    kRtsPushErrorPushPrepareTimeout,
    
    kRtsPushErrorSourceBase = 31000,
    kRtsPushErrorSourceInit,
    kRtsPushErrorSourcePrepare,
    kRtsPushErrorSourceStart,
    kRtsPushErrorSourceStop,
    kRtsPushErrorSourceUnInit,
    kRtsPushErrorSourceExpectIpFail,
    kRtsPushErrorSourceFetchSDPFail,
    kRtsPushErrorSourceNetRequestFail,

    kRtsPushErrorPeerBase = 32000,
    kRtsPushErrorPeerInit,
    kRtsPushErrorPeerPrepare,
    kRtsPushErrorPeerStart,
    kRtsPushErrorPeerStop,
    kRtsPushErrorPeerUnInit,
    kRtsPushErrorPeerDecode,        // decoder error
    kRtsPushErrorPeerNetworkIO,     // network error
    kRtsPushErrorPeerCreateSDP,     // create sdp error
    kRtsPushErrorPeerModifySDP,
    kRtsPushErrorPeerParseModifiedSDP,
    kRtsPushErrorPeerSetLocalSDP,   // set local sdp error
    kRtsPushErrorPeerSetRemoteSDP,  // set remote sdp error
    kRtsPushErrorNetworkInterrupt,
};

enum RTSPushEngineLogLevel {
    kRtsPushLogLevelVerbose = 0,
    kRtsPushLogLevelDebug,
    kRtsPushLogLevelInfo,
    kRtsPushLogLevelWarning,
    kRtsPushLogLevelError,
    kRtsPushLogLevelFatal,
};

enum RTSPushEngineTraceLevel {
    kRtsPushTraceLevelVerbose = 0,
    kRtcPushTraceLevelDebug,
    kRtsPushTraceLevelInfo,
    kRtsPushTraceLevelWarning,
    kRtsPushTraceLevelError,
    kRtsPushTraceLevelFatal,
};

struct RTSPushEngineConfigure {
    RTSVenderType e_vendor_type = kRtsVenderTypeTencent;
    const char* push_uri;
    const char* scfg_path;
    const char* session_id;
    bool enable_dtls;
};

struct RTSPushEngineStats {
    char local_ip[CONTENT_MIN_SIZE];
    char remote_ip[CONTENT_MIN_SIZE];
    int64_t push_stream_buffer_time;
    int64_t push_packet_send_delay;

    char json_content[CONTENT_MAX_SIZE];
};

struct RTSPushEngineTrace {
    RTSPushEngineTraceLevel trace_level;
    char stats_tag[CONTENT_MIN_SIZE];
    char pusher_stats[CONTENT_MAX_SIZE];
};

}  // namespace byterts
