
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "LiveStreamDefines.h"
#import "LiveStreamEffectDefines.h"
#import "LSMacros.h"

typedef void(^FetchEffectDetectResultCallback)(int result);

typedef NS_ENUM(NSInteger, LSMovieVideoScaleMode) {
    LSMovieVideoScaleFit        = 0,
    LSMovieVideoScaleAspectFill = 1,
    LSMovieVideoScaleFill       = 2,
};

@protocol LiveStreamAudioCatchDelegate <NSObject>

- (void)audioCatchOnData:(NSString *)fileName startTimeMs:(long)startTimeMs durationTimeMs:(long)durationTimeMs outSampleHz:(int)outSampleHz outChannel:(int)outChannel format:(LiveStreamAudioCatchFormatType)format;

- (void)audioCatchOnError:(int)errorCode message:(NSString *)message;

- (void)audioCatchOnComplete;

@end

NS_ASSUME_NONNULL_BEGIN
@class LSLiveAlgorithmResultData;
@class LiveStreamSession;
@class LiveStreamRenderSink;

@interface LiveStreamCaptureConfig : NSObject
#pragma mark -  Camera Config
@property (nonatomic, assign) BOOL useExternalCamera;

#pragma mark -  Render or Preview Config
typedef NS_ENUM(NSInteger, LiveStreamPreviewMode) {
    LiveStreamPreviewMode_LIVE = 0,
    LiveStreamPreviewMode_PK = 1,
    LiveStreamPreviewMode_GAME = 2
};
@property (nonatomic, assign) LiveStreamPreviewMode mode;
@property (nonatomic, assign) BOOL useES3;
@property (nonatomic, copy) NSString *backgroundColorOfCanvas;

#pragma mark -  Effect Config
@property (nonatomic, assign) BOOL useNewEffectLabAPI;
@property (nonatomic, assign) BOOL useAmazing;
@property (nonatomic, copy) NSString *effectPlatformConfig;
@property (nonatomic, copy) NSString *effectLicense; 

+ (LiveStreamCaptureConfig *)defaultConfig;
@end

@interface LiveStreamCapture : NSObject
#pragma mark -  LiveStreamCapture Normal
@property (nonatomic, assign) BOOL purgeMemoryIfNeeded;

@property (nonatomic, assign) BOOL unableMixerWithSameFrameBuffer;

@property (nonatomic, assign) BOOL mixOnClient;

@property (nonatomic, assign) BOOL movieInteractOnlyPlay;

@property (nonatomic, assign) BOOL karaokeRunning;

@property (nonatomic, weak) LiveStreamSession *session;

@property (nonatomic, assign) BOOL enableKTVCamera;

@property (nonatomic, assign) BOOL enablePipelineKTVCamera;

@property (nonatomic, assign) BOOL needPlayMovieInteractAudio;

@property (nonatomic, copy) void(^logCallback)(NSDictionary *log);


- (instancetype)initWithConfig:(LiveStreamCaptureConfig *)config;
- (void)startVideoCapture;

- (void)stopVideoCapture;

- (LiveStreamCaptureConfig *)getCaptureConfig;

#pragma mark - Camera
@property (nonatomic, assign) NSInteger videoFPS;
@property (nonatomic, readwrite) AVCaptureDevicePosition cameraPosition;


#pragma mark - GL Process & size
@property (nonatomic, assign, readonly) int cameraLayerId; 

@property (nonatomic, assign) int cameraZOrder; 
@property (nonatomic, assign) OSType inPixelFmt;
- (void)setCanvasColor:(NSString *)colorString;
@property (nonatomic, assign) LiveStreamRotateMode inRotateMode;
@property (nonatomic, assign) CGSize outputSize;

@property (nonatomic, assign) BOOL renderOnSingleView;

- (EAGLContext *)getGLContext;
- (void)addVideoInput:(CGRect)rect zOrder:(int)zOrder forLayer:(int)layerId;

- (void)addVideoInput:(CGRect)rect
             fillMode:(LSRenderMode)mode
               zOrder:(int)zOrder
             forLayer:(int)layerId
             rotation:(LiveStreamRotateMode)rotate;
- (void)setBypassOutputSize:(CGSize)size pixelFormat:(OSType)fmt enable:(BOOL)enable;

- (void)setBypassOutputSize:(CGSize)size pixelFormat:(OSType)fmt enable:(BOOL)enable isLandscapeVideo:(BOOL)isLandscapeVideo;
- (void)setMixerTriggerLayer:(int)layerId;

- (void)updateVideoRect:(CGRect)rect zOrder:(int)zOrder forLayer:(int)layerId animated:(BOOL)animated frames:(int)frames;
- (void)removeVideoInput:(int)layerId;

@property (nonatomic, weak) id<LiveStreamAudioCatchDelegate> catchDelegate;

- (void)setOutputCropSize:(CGSize)cropSize DEPRECATED_MSG_ATTRIBUTE("use -setCameraCropOutputSize instead");

- (void) setCameraCropOutputSize : (CGSize) cropSize;

- (void) setCameraOutputSize : (CGSize) size;

- (CGSize) getCameraOutputSize;

- (void)setCropFromSize:(CGSize)from;

- (void)renderUseSmooth:(BOOL)useSmooth;

- (void)setShouldCheckInputSize:(BOOL)shouldCheck;

- (NSDictionary <NSString *,NSDictionary*>*)getMixerVideoInfoMessage;

- (void)enableMipmapRatio:(float)mipmap;

- (void)enableSingleView:(BOOL)enable;
- (BOOL)fetchSingleViewStatus;

- (void)setSingleViewCropRegion:(CGRect)region;

#pragma mark - Preview
typedef NS_ENUM(NSInteger, LSPreviewMode) {
    LSPreviewMode_Normal = 0,
    LSPreviewMode_GameInteract,
    LSPreviewMode_Gaming,
    LSPreviewMode_CameraGaming,
    LSPreviewMode_EffectInteractGame,
    LSPreviewMode_MovieInteract,
};
@property (nonatomic, assign) LSPreviewMode previewMode;
- (UIView *)resetPreviewView:(UIView *)view;

- (void)setPreviewFrame:(CGRect)rect;

- (UIView *)previewView;
- (void)setPreviewMirror:(BOOL)bMirror;

- (void)setStreamMirror:(BOOL)bMirror;

#pragma mark - Callback
@property (nonatomic, copy) void(^inputFrameCallback)(CVPixelBufferRef pixelBuffer);
@property (nonatomic, copy) void(^effectFrameCallback)(CVPixelBufferRef pixelBuffer);
- (void)setVideoProcessedCallback:(void (^ _Nullable)(CVPixelBufferRef _Nonnull buffer, GLint texture, CMTime pts))videoProcessedCallback;
@property (nonatomic, copy) void(^firstFrameRenderCallback)(BOOL success, int64_t pts, uint32_t err_no);
- (void)setVideoProcessedBypassCallback:(void (^ _Nonnull)(CVPixelBufferRef _Nonnull buffer, CMTime pts))bypassCallback;

#pragma mark - Push
- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              withCMTime:(CMTime)pts
                toLayer:(GLint)layerId;

- (void)forceDisplayTexture:(int)textureId
                      width:(NSInteger)width
                     height:(NSInteger)height
                        pts:(CMTime)pts
                    layerId:(int)layerId;

- (void)pushVideoTexture:(int)textureId
                   width:(NSInteger)width
                  height:(NSInteger)height
                     pts:(CMTime)pts
                 toLayer:(int)layerId;

#pragma mark - Effect
typedef void(^EffectInfoBlock_t)(void *a, void *b);
@property (nonatomic, copy) void(^effectInfoBlck)(void *framebuffer, CMTime frametime, EffectInfoBlock_t(^)(void));
- (BOOL)isEffectEnabled;

- (void)setEnableEffect:(BOOL)enable;

- (BOOL) isEffectEnabled:(LSLiveEffectType) type;

- (CVPixelBufferRef)getPixelBufferWithIsEffected:(BOOL)effected DEPRECATED_MSG_ATTRIBUTE("use inputFrameCallback && effectFrameCallback instead");

- (NSData *)getJpegDataWithIsEffected:(BOOL)effected compressionRatio:(CGFloat)ratio DEPRECATED_MSG_ATTRIBUTE("use inputFrameCallback && effectFrameCallback instead");

- (void)fetchEffectDetectPhotoContentWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType isLastPhone:(BOOL)isLastPhone callback:(FetchEffectDetectResultCallback)callback;

- (void)setEffectRenderCacheTextureWithImage:(UIImage *)image algorithmType:(NSString *) algorithmType;


@end

@interface LiveStreamCapture (ReducedMode)

typedef NS_ENUM(NSInteger, LSCaptureMode) {
    LSCaptureEffectMode,    
    LSCaptureReducedMode    
};

- (instancetype)initWithMode:(LSCaptureMode)mode config:(LiveStreamCaptureConfig *)config;

@end

@interface LiveStreamCapture(DumpRawData)
- (void)startRecordingWithDuration:(NSTimeInterval)duration
                             delay:(NSTimeInterval)delay
                               fps:(NSUInteger)fps
                WithCompletionHandler:(void (^)(NSError * _Nonnull error, int type, NSURL * _Nonnull url))completionHandler;

- (void)resetRecording;
- (BOOL)dumpIsFinished;

- (void) setEffectRecordPath:(NSString *)filePath;


- (void) startRecordingWav:(NSInteger) ticketId maxRecordingDuration:(float) recordingSeconds withCompleteHandler:(void (^)(NSString *audioURL, NSInteger ticketId, NSError *error)) completionHandler;
 
- (void) stopRecordingWav:(void (^)(NSString *audioURL, NSInteger ticketId, NSError *error)) completionHandler;

- (void)configureAudioCatcher:(NSString *)path durationMs:(long)durationMs format:(LiveStreamAudioCatchFormatType)format isPeriodCatch:(bool)periodCatch totalDurationMsOnPeriodCatch:(long)totalDurationMsOnPeriodCatch outSampleHz:(int)outSampleHz outChannel:(int)outChannel;

- (void)startAudioCatcherWithDelegate:(id<LiveStreamAudioCatchDelegate>)delegate;

- (void)stopAudioCatcher;

@end

@interface LiveStreamCapture (statistic)
- (NSDictionary *)getStatisticInfo;
- (NSDictionary *)getMessageInfo;
@end

@interface LiveStreamCapture (SpeechRecognizing)

- (void)setEnableAudioEffect:(BOOL)enable;

@end

@interface LiveStreamCapture (privateAPI)
- (void)audioProcessWithData:(void *_Nonnull)ioData
               processedData:(void *)processedData
              earMonitorData:(void *)earMonitingData
                        size:(UInt32)mDataByteSize
                   timeStamp:(const int64_t)timeStamp
             mNumberChannels:(UInt32)mNumberChannels
              numberOfFrames:(int)inNumberFrames
                     admType:(LSAdmType)admType;
- (void)audioProcessWithData:(void *_Nonnull)ioData
                        size:(UInt32)mDataByteSize
                   timeStamp:(const int64_t)timeStamp
             mNumberChannels:(UInt32)mNumberChannels
              numberOfFrames:(int)inNumberFrames;

- (void)doPlayerProcessWithData:(void *)ioData size:(UInt32)mDataByteSize numberOfFrames:(int)frames;

- (void)doPlayerCommonAuxStreamProcessWithData:(void *)ioData size:(UInt32)mDataByteSize numberOfFrames:(int)frames;

- (void)doPlayerAecRefProcessWithData:(void *)ioData size:(UInt32)mDataByteSize numberOfFrames:(int)frames;

- (void)p_processOtherMixHandle:(AudioBufferList* )ioData sampleFrames:(NSInteger)inNumberFrames elementIndex:(UInt32)index withMixerHandle:(id )handle;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts needRender:(BOOL)needRender;
@end



NS_ASSUME_NONNULL_END
