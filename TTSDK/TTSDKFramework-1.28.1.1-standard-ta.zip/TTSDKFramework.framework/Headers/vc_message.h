//
// Created by 黄清 on 2/27/21.
//

#ifndef VIDEOENGINE_VC_MESSAGE_H
#define VIDEOENGINE_VC_MESSAGE_H
#pragma once

#include "vc_base.h"
#include "vc_net_simple.h"
#include "vc_state_supplier.h"
#include <memory>
#include <mutex>
#include <string>
#include <vc_media_info.h>

VC_NAMESPACE_BEGIN

class VCMessage;
class IVCMessageHandle {
public:
    virtual ~IVCMessageHandle(){};
    virtual void receiveMessage(std::shared_ptr<VCMessage> &msg) = 0;
};

typedef enum : int
{
    MsgWhatIsUnknown = -1,
    /// IO
    MsgWhatIsIO = 0,
    MsgLoaderReqProgress = 1,
    MsgLoaderReqStart = 2,
    MsgLoaderReqEnd = 3,
    MsgTaskStart = 4,
    MsgTaskEnd = 5,

    /// Player
    MsgWhatIsPlayer = 1000,
    MsgPlayerPlay = 1001,
    MsgPlayerPause = 1002,
    MsgPlayerSeek = 1003,
    MsgPlayerSwitchBitrate = 1004,
    MsgPlayerBufStart = 1005,
    MsgPlayerBufEnd = 1006,
    MsgPlayerStop = 1007,
    MsgPlayerClose = 1008,
    MsgPlayerPrepare = 1009,

    /// Scene
    MsgWhatIsScene = 2000,
    MsgSceneSwitch = 2001,
    MsgSceneDestroy = 2002,
    MsgMediaRefresh = 2003,
    MsgMediaUpdate = 2004,

    /// Running
    MsgWhatIsRunning = 3000,
    MsgPlayStrategyRet = 3001,
    MsgIntervalTrigger = 3002,

    MsgWhatIsPreload = 3200,
    MsgPreloadTaskFinished = 3201,
    MsgPreloadBlockPlay = 3202,

    /// Business
    MsgWhatIsBusiness = 4000,
    MsgAppState = 4001,
    MsgSmartPreloadRetUpdate = 4002,
    MsgPreloadTimelinessRetUpdate = 4003,
    MsgPreloadSmartConfigJsonUpdate = 4004,
    MsgFocusMedia = 4005,
    MsgSmartRangeRequestUpdate = 4006,
    MsgAppPreloadCancelAll = 4007,
    MsgAlgoJsonStringUpdate = 4008,

    /// Select bitrate
    MsgWhatIsSelectBitrate = 5000,
    MsgGetBitrate = 5001,

    /// Bandwidth
    MsgWhatIsBandwidth = 6000,
    MsgGetBandwidth = 6002,
    MsgNetSampling = 6003,
    MsgSpeedQueueSize = 6004,

} VCMsgWhat;

class WhatUtil {
public:
    static std::string WhatString(VCMsgWhat what);
};

class VCMsgArgs;
class _VCMessagePool;
class VCMessage final : public IVCPrintable {
public:
    typedef std::shared_ptr<VCMessage> Ptr;

public:
    static Ptr obtain();
    static Ptr obtain(int what);
    static Ptr obtain(int what, int arg1);
    static Ptr obtain(int what, int arg1, int arg2);
    static Ptr obtain(int what, const std::string &argStr);
    static Ptr obtain(int what, int arg1, int arg2, const std::string &argStr);
    static Ptr obtain(int what, const std::shared_ptr<VCMsgArgs> &args);
    static Ptr
    obtain(int what, int arg1, const std::shared_ptr<VCMsgArgs> &args);
    static Ptr obtain(int what,
                      int arg1,
                      int arg2,
                      const std::string &argStr,
                      const std::shared_ptr<VCMsgArgs> &args);

public:
    static bool recycle(std::shared_ptr<VCMessage> &message);

public:
    void copyFrom(std::shared_ptr<VCMessage> &o);

public:
    std::string toString() const override;

public:
    VCMessage() = default;
    ~VCMessage() override;

private:
    friend class _VCMessagePool;
    Ptr next{nullptr};

public:
    VCMsgWhat what{MsgWhatIsUnknown};
    int arg1{0};
    int arg2{0};
    std::string argStr;
    std::shared_ptr<VCMsgArgs> args{nullptr};

private:
    int mId{0};

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMessage);
};
VC_NAMESPACE_END

/// MARK: - Message.Args

VC_NAMESPACE_BEGIN

class VCMsgArgs : public IVCPrintable {
public:
    VCMsgArgs() = default;
    virtual ~VCMsgArgs() = default;

public:
    std::string toString() const override {
        return "<base MsgArgs>";
    };

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgArgs);
};

typedef enum : int
{
    VCIOTaskTypeUnknown = 0,
    VCIOTaskTypePlay = 1,
    VCIOTaskTypePreload = 2,
} VCIOTaskType;

typedef enum : int
{
    VCIOTaskReadSourceUnknown = 0,
    VCIOTaskReadSourceNormalRead = 1,
    VCIOTaskReadSourcePreRead = 2,
} VCIOTaskReadSource;

class VCMsgIOArgs : public VCMsgArgs {
public:
    VCMsgIOArgs();
    ~VCMsgIOArgs() override;

public:
    std::string mMediaId;
    std::string mFileHash;
    std::string mTaskId;
    int mIsHeader{false};
    VCIOTaskReadSource mReadSource{VCIOTaskReadSourceUnknown};
    VCIOTaskType mTaskType{VCIOTaskTypeUnknown};
    int64_t mOff{0};
    int64_t mSize{0};
    std::map<std::string, std::string> mInfo;

public:
    std::string toString() const override {
        return "IOArgs: mMediaId = " + mMediaId + ", mFileHash = " + mFileHash +
               ", mTaskId = " + mTaskId +
               ", mIsHeader = " + std::to_string(mIsHeader) +
               ", mReadSource = " + std::to_string(mReadSource) +
               ", mTaskType = " + std::to_string(mTaskType) +
               ", mOff = " + std::to_string(mOff) +
               ", mSize = " + std::to_string(mSize) +
               ", mInfo.size = " + std::to_string(mInfo.size());
    }

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgIOArgs);
};

class VCMsgPlayArgs : public VCMsgArgs {
public:
    VCMsgPlayArgs();
    ~VCMsgPlayArgs() override;

public:
    std::string mMediaId;
    std::string mSceneId;

    std::string toString() const override {
        return "PlayArgs: mediaId = " + mMediaId + ", sceneId = " + mSceneId;
    }

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgPlayArgs);
};

class VCMsgSceneArgs : public VCMsgArgs {
public:
    VCMsgSceneArgs();
    ~VCMsgSceneArgs() override;

public:
    std::string mSceneId;
    std::string mAlgoParam;

    std::string toString() const override {
        return "SceneArgs: mSceneId " + mSceneId +
               ", mAlgoParam = " + mAlgoParam;
    }

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgSceneArgs);
};

/// MARK: - VCMsgBlockPlayArgs

class VCMsgBlockPlayArgs final : public VCMsgArgs {
public:
    VCMsgBlockPlayArgs() = default;
    ~VCMsgBlockPlayArgs() override {
        LOGD("~VCMsgBlockPlayArgs");
    };

public:
    std::string mFileHash;
    int mResumeTask{1};

public:
    std::string toString() const override {
        return "BlockPlayArgs: mFileHash = " + mFileHash +
               ", mResumeTask =" + std::to_string(mResumeTask);
    }

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgBlockPlayArgs);
};

VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

class VCMsgSelectBitrateArgs final : public VCMsgArgs {
public:
    VCMsgSelectBitrateArgs() = default;
    ~VCMsgSelectBitrateArgs() override;

public:
    VCMediaInfo::Ptr mMedia{nullptr};
    SelectBitrateType mType;
    std::map<std::string, std::string> mParam;
    IVCSelectBitrateContext::Ptr mContext;

public:
    std::string toString() const override;

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgSelectBitrateArgs);
};

VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

class VCMsgNetSimpleArgs final : public VCMsgArgs {
public:
    VCMsgNetSimpleArgs() = default;
    ~VCMsgNetSimpleArgs() override;

public:
    std::shared_ptr<VCNetSimple> mSimple;

public:
    std::string toString() const override;

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMsgNetSimpleArgs);
};

VC_NAMESPACE_END

#endif // VIDEOENGINE_VC_MESSAGE_H
