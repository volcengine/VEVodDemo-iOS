//
// Created by 黄清 on 5/1/21.
//

#ifndef PRELOAD_VC_IEXECUTOR_H
#define PRELOAD_VC_IEXECUTOR_H
#pragma once

#include "av_player_interface.h"
#include "AVMDLIOManager.h"
#include "vc_base.h"
#include "vc_imodule.h"

VC_NAMESPACE_BEGIN

using AVMDLIOManager = com::ss::ttm::medialoader::AVMDLIOManager;
using AVMDLIOTaskListener = com::ss::ttm::medialoader::AVMDLIOTaskListener;
using IPlayer = com::ss::ttm::player::IPlayer;

class VCPlayerManager;
class MessageTaskRunner;
class IVCExecutor : public IVCResultListener, public IVCRunner {
public:
    IVCExecutor(VCModuleType type);
    ~IVCExecutor() override;

public:
    virtual void setIOManager(AVMDLIOManager *ioManager);
    virtual void setContext(IVCContext *context);
    virtual void setIOTaskListener(AVMDLIOTaskListener *listener);
    virtual void setPlayerManager(VCPlayerManager *playerManager);
    void setRunner(const std::shared_ptr<MessageTaskRunner> &runner) override;
    void onResult(const IVCResultListener *listener,
                  const std::shared_ptr<VCStrategyResult> &result) override;
    void onMessage(const IVCResultListener *listener,
                   const std::shared_ptr<VCMessage> &msg) override;
    VCModuleType getType(void);

public:
    inline bool operator==(const IVCExecutor &o) {
        return &o == this || o.mType == mType;
    }

protected:
    VCModuleType mType;
    AVMDLIOManager *mIOManager{nullptr};
    AVMDLIOTaskListener *mIOTaskListener{nullptr};
    IVCContext *mContext{nullptr};
    VCPlayerManager *mPlayerManager{nullptr};
};

VC_NAMESPACE_END

#endif // PRELOAD_VC_IEXECUTOR_H
