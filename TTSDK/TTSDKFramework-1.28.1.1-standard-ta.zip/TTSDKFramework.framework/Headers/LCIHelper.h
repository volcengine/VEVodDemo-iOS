
#import <Foundation/Foundation.h>
#import <CoreAudio/CoreAudioTypes.h>


NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, LCApplicationStatus) {
    LCApplicationStatusBecomeActive,
    LCApplicationStatusForeground,
    LCApplicationStatusWillResignActive,
    LCApplicationStatusBackground,
};

@interface LCIHelper : NSObject
@property (nonatomic, readonly) LCApplicationStatus appStatus;
+ (instancetype)sharedInstance;

#if DEBUG
- (double) GetCPUFrequency;
#endif
- (NSString *)convertToJsonData:(NSDictionary *)dict;

- (NSString *)convertDataToHexStr:(NSData *)data;

- (CVPixelBufferRef)createDarkFrameWithFrameSize:(CGSize)frameSize enableLeakFix:(bool)enableLeakFix;

+ (CVPixelBufferRef)copyPixelBufferFrom:(CVPixelBufferRef)buffer;

+ (int64_t)millisecondFrom:(const int64_t)timeStamp;
@end

typedef NS_ENUM(NSInteger, LCIElapseStatus) {
    LCIElapseStatus_Undefine             = 0,
    LCIElapseStatus_VideoFrameToRTCStart = 1,
    LCIElapseStatus_VideoFrameToRTCEnd   = 2,
    LCIElapseStatus_AudioFrameToRTCStart = 3,
    LCIElapseStatus_AudioFrameToRTCEnd   = 4,
};

#define CurrentMediaMilliTime (CACurrentMediaTime() * 1000)

#define ElapseStatisticsNoError              0
#define ElapseStatisticsOverflowError        -1
#define ElapseStatisticsNotAllow             -2

@interface LCIElapseHelper : NSObject

@property (nonatomic, assign) BOOL enableStatistics;

@property (nonatomic, assign) CFTimeInterval videoFrameToRTCElapsed;
@property (nonatomic, assign) CFTimeInterval audioFrameToRTCElapsed;

@property (nonatomic, assign) CFTimeInterval RTCLinkElapsed;

@property (nonatomic, assign) CFTimeInterval startInteractStreamingTime;
@property (nonatomic, assign) CFTimeInterval startInteractTime;

@property (nonatomic, assign) CFTimeInterval joinChannelTime;
@property (nonatomic, assign) CFTimeInterval joinChannelSuccessTime;
@property (nonatomic, assign) CFTimeInterval startPushDataTime;

@property (nonatomic, assign) CFTimeInterval pushLiveStreamTime;
@property (nonatomic, assign) CFTimeInterval publishRtmpStreamTime;

@property (nonatomic, assign) CFTimeInterval firstRemoteVideoDecodedTime;
@property (nonatomic, assign) CFTimeInterval firstRemoteVideoRenderTime;

@property (nonatomic, assign) CFTimeInterval stopInteractStreamingTime;

+ (instancetype)sharedInstance;

+ (NSDictionary *)handleSEIDataForElapsedTimeWithDic:(NSDictionary *)dic;

- (void)cleanRtcElapseData;

- (int)elapsedTimeStatisticsWithStatus:(LCIElapseStatus)status timeStampValue:(double)timeStampValue;
- (void)rtcLinkElapsedTimeStatisticsWithSEIData:(NSData *)SEIData;

@end

NS_ASSUME_NONNULL_END
