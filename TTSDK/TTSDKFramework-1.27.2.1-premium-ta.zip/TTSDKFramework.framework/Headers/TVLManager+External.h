//
//  TVLManager+External.h
//  TTVideoLive
//
//  Created by 陈昭杰 on 2019/7/5.
//  Copyright © 2019 ByteDance. All rights reserved.
//

#import "TVLManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TVLManager (External)
+ (BOOL)isSupportSR;//当前机型是否支持超分
@end

NS_ASSUME_NONNULL_END
