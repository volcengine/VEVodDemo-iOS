#pragma once

#ifdef WIN32
#define BYTEAUDIO_API __declspec(dllexport)
#else
#define BYTEAUDIO_API __attribute__((__visibility__("default")))
#endif

/**
 * Private header file, defines some private stream option key.
 */
namespace bae {
/**
 * @brief Private option key of byteaudio engine.
 * scope: [0 ~ 1000)
 */
enum ByteAudioEnginePrivateOptionKey {
    /**
     * @brief Adjust capture vocal volume in KTV (for engine).
     */
    kEngineOptVocalVolume = 0,

    /**
     * @brief enable local audio with higher priority.
     */
    kEngineOptEnableLocalAudio = 1,

    /**
     * @brief used to get the current audio route (only for ios & android).
     */
    kEngineOptCurrentAudioRoute = 2,

    /**
     * @brief enable/disable hands-free ear monitor. This option does't control headset ear monitor.
     */
    kEngineOptEnableHandsFreeEarMonitor = 3,

    /**
     * @brief whether enable audiosession deactive to avoid the low voice problem in ios14 device, default false.
     *        enable this option will interrupt the audio playback of other processes, such as game audio.
     */
    kEngineOptEnableAudioSessionDeactive = 5,

    /**
     * @brief set vender id
     */
    kEngineOptVendorIdFlag = 6,

    /**
     * @brief rnn noise enable
     */
    kEngineOptEnableRnnNoise = 7,

    /**
     * @brief microphone aagc
     */
    kEngineOptEnableMicAagc = 8,

    /**
     * @brief aec option from ui
     */
    kEngineOptUIAecOption = 9,

    /**
     * @brief ns option from ui
     */
    kEngineOptUINsOption = 10,

    /**
     * @brief ios music mode option from ui
     */
    kEngineOptUIIOSMusicModeOption = 11,

    /**
     * @brief enable aecH when using some specific displayAudio device
     */
    kEngineOptEnableAECH = 12,

    /**
     * @brief change aecH delay mode
     */
    kEngineOptEnableAECHExtralDelay = 13,

    /**
     * @brief used to get the capacity of devices, whether devices support ear-monitor;
     */
    kEngineOptEarBackSupport = 14,

    /**
     * @brief used to set the ear back enable;
     */
    kEngineOptEnableHeadSetEarBack = 15,

    /**
     * @brief key-value to set ear monitor reverb mode;
     */
    kEngineOptSetEarBackEffect = 16,

    /**
     * @brief key-value to set ear monitor equalizer mode;
     */
    kEngineOptSetEarBackEqualizer = 17,

    /**
     * @brief howl detect enable from ui
     */
    kEngineOptEnableHowlDetect = 18,

    /**
     * @brief return the model download path value
     */
    kEngineOptModelDownloadedPath = 19,

    /**
     * @brief key-value to set config level;
     */
    kEngineOptSetConfigLevel = 20,

    /**
     * @brief echo detect from ui
     */
    kEngineOptEnablePreMeetingEchoDetect = 21,
    /**
     * @brief echo detect file length ms
     */
    kEngineOptTestFileLength = 22,
    /**
     * @brief Mobile built-in microphone select strategy type when using media mode and mono record.
     *        value: 0 - No client mic select strategy by default.
     *               1 - Optimize for software aec and avoid use bottom mic for landscape such as game.
     * @attention Only for iOS for now.
     */
    kEngineOptMobileMicStrategy = 23,

    /**
     * @brief key-value to set ear monitor volume;
     */
    kEngineOptSetEarBackVolume = 24,

    /**
     * @brief Set Android record audio preferred source type when using media mode.
     *        value: 0 - default
     *               1 - voice_recognition
     * @attention Only for Android for now.
     */
    kEngineOptAndroidRecordMediaModeMicSource = 25,

    /**
     * @brief query if this engine instance has real device
     */
    kEngineOptSupportRealDevice = 26,
};

/**
 * @brief Private option key of input/output/aux stream.
 * scope: [1000 ~ 10000)
 */
enum ByteAudioStreamPrivateOptionKey {
    /**
     * @brief Enable opus dtx encode, used for RealX (for input stream).
     * value_type: bool, default false
     */
    kInputOptOpusUseDTX = 1003,

    /**
     * @brief Enable opus in-band fec, used for RealX (for input stream).
     * value_type: bool, default false
     */
    kInputOptOpusUseInBandFEC = 1004,

    /**
     * @brief Set encode loss rate, used for RealX (for input stream).
     * value_type: int32_t, default 0
     */
    kInputOptEncLossRate = 1005,

    /**
     * @brief get capture audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kInputOptRecordLevel = 1006,

    /**
     * @brief get encode audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kInputOptEncodeLevel = 1007,

    /**
     * @brief Whether lead to a start of audio device (for input stream).
     * value_type: bool, default true
     */
    kInputOptImpactDevice = 1008,

    /**
     * @brief get prep smooth audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kInputOptSmoothPrepLevel = 1009,

    /**
     * @brief Enable audio low bandwdith encoder.
     * value_type: bool, default false
     */
    kInputOptAudioLowBandwidth = 1010,

    /**
     * @brief Opus enc_bitrate decrease speed.
     * value_type: int32_t, [1000~36000]
     */
    kInputEncDownBitrate = 1011,

    /**
     * input publish event session id
     */
    kInputOptPublishEventSessionId = 1012,

    /**
     * @brief aux stream is effct audio
     * value_type: bool, default false
     */
    kAuxOptEffect = 2000,
    /**
     * @brief stream id
     * value_type: int32_t
     */
    kAuxOptSoundId = 2001,

    /**
     * @brief get plaback audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kOutputOptPlaybackLevel = 3000,

    /**
     * @brief get decode audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kOutputOptDecodeLevel = 3001,

    /**
     * @brief get receive smooth audio level, used for RealX (for input stream).
     * value_type: int32_t, [0~32767]
     */
    kOutputOptSmoothRecvLevel = 3002,

    /**
     * @brief active stream for mix node pull buffer
     * value_type: bool, default true
     */
    kOutputOptActiveStream = 3003,
};

BYTEAUDIO_API void set_engine_context(void* env, void* context);
}  // namespace bae
