//
//  BDImageDecoderAVIFConversion.h
//  BDWebImage
//
//  Created by bytedance on 12/30/20.
//

#import "avif.h"

extern CGImageRef _Nullable BDCreateCGImageFromAVIF(avifImage * _Nonnull avif) __attribute__((visibility("hidden")));
