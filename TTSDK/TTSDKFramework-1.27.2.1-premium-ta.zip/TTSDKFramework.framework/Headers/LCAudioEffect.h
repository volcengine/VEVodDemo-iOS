
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LCAudioEffectScene) {
    LCAudioEffectSceneNone,
    LCAudioEffectSceneKTV,
};

@interface LCAudioEffectConfig : NSObject

+ (instancetype)configWithScene:(LCAudioEffectScene)scene;

@property (nonatomic, assign, readonly) LCAudioEffectScene scene;

@property (nonatomic, assign) AudioStreamBasicDescription audioStreamBasicDescription;

@end

@interface LCAudioEffect : NSObject

@property (nonatomic, assign) CGFloat volume;

- (instancetype)initWithConfig:(LCAudioEffectConfig *)config;

- (void)processAudioBufferList:(AudioBufferList *)ioData inNumberFrames:(UInt32)inNumberFrames;

- (void)enableReverberation:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
