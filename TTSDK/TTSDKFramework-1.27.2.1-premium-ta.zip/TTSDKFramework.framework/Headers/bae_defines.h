#pragma once

#include <string>
#ifdef WIN32
#define BYTEAUDIO_API __declspec(dllexport)
#else
#define BYTEAUDIO_API __attribute__((__visibility__("default")))
#endif

namespace bae {

/**
 * @brief Error code.
 */
enum ByteAudioErrorCode {
    /**
     * @brief success
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioSuccess = 0,

    /**
     * @brief general failure
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Notify user error message if need.
     */
    kByteAudioFailure = -1,

    /**
     * @brief failure of invalid param
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioInvalidParam = -2,

    /**
     * @brief failure of wrong state
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioWrongState = -3,

    /**
     * @brief failure of no frame
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioNoFrame = -4,

    /**
     * @brief failure of not implemented
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Notify user error message if need.
     */
    kByteAudioNotImplemented = -5,

    /**
     * @brief don't have permission to use microphone.
     * Affect Platform
     *    Windows
     *        We will get this error when we try to start capture in microphone. It starts since Windows 10 build 17063.
     *    Mac/IOS/Android
     *        We need apply permission through App settings.
     * Suggestions:
     *    It must promote to user that microphone need to be granted to access from system.
     */
    kByteAudioNoPermission = -6,

    /**
     * @brief failure of resource unavailable
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioResourceLimited = -7,

    /**
     * @brief Set a device which has been plugged out.
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Pop warning, indicating that the device has been removed, try another device
     */
    kByteAudioDeviceNotExists = -8,

    /**
     * @brief failure of device not support format
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Notify user error message if need.
     */
    kByteAudioDeviceFormatNotSupport = -9,

    /**
     * @brief general warning, some API return failure, but it doesn't affect function.
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Needn't take action.
     */
    kByteAudioWarning = -10,

    /**
     * @brief No device in system
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    It must notify user that no microphone in system, remote side can't hear him.
     *    Ask user to plug in another device.
     */
    kByteAudioDeviceNoDevice = -11,

    /**
     * @brief Device can't be used.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    It must promote to user select another device to join meeting.
     */
    kByteAudioDeviceCannotUse = -12,

    /**
     * @brief It meets system error when calling intializing device.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    It must promote to user select another device to join meeting.
     */
    kByteAudioDeviceInitFailed = -13,

    /**
     * @brief It meets system error when starting intializing device\.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    It must promote to user select another device to join meeting or restart the call.
     */
    kByteAudioDeviceStartFailed = -14,

    /**
     * @brief Find microphone in system, but it failes when try to start capture due to coreaudio's active function.
     * Affect Platform
     *    Windows
     * Suggestions:
     *    1. Choose another deivce.
     *    2. Exit and restart the call.
     *    3. Restart machine if 1&2 doesn't work.
     */
    kByteAudioDeviceCoreAudioActiveError = -15,

    /**
     * @brief Find device in system, but it failes when try to start due to coreaudio's initialization function.
     * Affect Platform
     *    Windows
     * Suggestions:
     *    1. Choose another deivce.
     *    2. Exit and restart the call.
     *    3. Restart machine if 1&2 doesn't work.
     */
    kByteAudioDeviceCoreAudioInitError = -16,

    /**
     * @brief Find device in system, but it failes when try to start open, intialize, get format due to service error.
     * Affect Platform
     *    Windows
     * Suggestions:
     *    Suggest to restart machine.
     */
    kByteAudioDeviceCoreAudioServiceError = -17,

    /**
     * @brief Device is occupied by other apps.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Promote user that device is occupied by other APPs. Ask user to quit suspicious Apps.
     */
    kByteAudioDeviceSessionDisconnectedByExclusiveMode = -18,

    /**
     * @brief It meets system error when stopping device.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    No Action is requried.
     */
    kByteAudioDeviceStopFailed = -19,

    /**
     * @brief It meets system error when creating volume mute object.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Pop warning, indicating cannot do mute/unmute.
     */
    kByteAudioDeviceCannotMute = -20,

    /**
     * @brief It meets system error when creating volume  object.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Pop warning, indicating cannot adjust volume.
     */
    kByteAudioDeviceCannotAdjustVolume = -21,

    /**
     * @brief Android device's playback mode isnot in communication mode.
     * Affect Platform
     *    Android
     * Suggestions:
     *    Pop warning, indicating cannot adjust volume.
     */
    kByteAudioDeviceNotCommunicationMode = -22,

    /**
     * @brief property changed in system, such as format, signal processing.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Need restart capture or playback
     */
    kByteAudioDevicePropertyChanged = -23,

    /**
     * @brief device is in background
     * Affect Platform
     *    ios
     * Suggestions:
     *    TBD
     */
    kByteAudioDeviceInBackGround = -24,

    /**
     * @brief audio unit set property failed
     * Affect Platform
     *    ios
     * Suggestions:
     *    TBD
     */
    kByteAudioDeviceAudioUnitSetPropertyFailed = -25,

    /**
     * @brief It opens device successfully, but it can't get system callbacks in run-time.
     * Affect Platform
     *    All platforms
     * Suggestions:
     *    Promote notification that remote can't hear him due to it can't capture data from microphone if role is record,
     *    Promote notification that he can't hear remote due to it can't play to speaker if role is playback.
     *    1. Choose another device.
     *    2. Restart the call.
     */
    kByteAudioDeviceNoCallback = -100,

    /**
     * @brief System calls too fast.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Try another device or restart machine
     */
    kByteAudioDeviceTooFast = -101,

    /**
     * @brief System calls too slow.
     * Affect Platform
     *    All platform
     * Suggestions:
     *    Try another device or restart machine
     */
    kByteAudioDeviceTooSlow = -102,

    /**
     * @brief Acoustic echo is leaked
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseLeakEcho = -200,

    /**
     * @brief Audio captured data is clipped
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseClipping = -201,

    /**
     * @brief Audio captured data is too noisy
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseLowSNR = -202,

    /**
     * @brief Audio captured data is muted
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseCaptureInsertSilence = -203,
    kByteAudioDiagnoseCaptureSilence = -204,
    kByteAudioDiagnoseCaptureSilenceDisappear = -205,

    /**
     * @brief Acoustic howling is detected
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseHowling = -206,

    /**
     * @brief Audio captured data is messy
     * Affect Platform
     *    All platforms
     * Suggestions:
     *
     */
    kByteAudioDiagnoseMessySound = -207,
    kByteAudioDianoisePreMeetingEchoDetection = -208,
};

/**
 * @brief event key indicating a special event used for event callback method
 */
enum ByteAudioEventKey {
    // notify route changed. code: new route. See @ByteAudioRouting; msg: change reason
    kByteAudioEventRouteChanged = 1000,
    // iOS interruption begin
    kByteAudioEventInterruptionBegin = 1001,
    // iOS interruption end
    kByteAudioEventInterruptionEnd = 1002,
    // iOS media server terminate
    kByteAudioEventMediaServerTerminate = 1003,
    // iOS media server reset
    kByteAudioEventMediaServerReset = 1004,
    // iOS switch to media mode when screen captured to avoid interrupt background screen capture
    kByteAudioEventScreenCaptureMediaMode = 1005,
    // device restart event
    kByteAudioEventDeviceRestart = 1006,
    // engine restart current record device three times, but the device still work badly, thus report the fail
    kByteAudioEventRecordDeviceRestartFail = 1007,
    // engine restart current record device three times, but the device still work badly, thus report the fail
    kByteAudioEventPlayoutDeviceRestartFail = 1008,

    // record start event. code: 0 success; other: error see @ByteAudioErrorCode
    kByteAudioEventRecordingStart = 1100,
    // record first frame callback. msg: time_since_start(milliseconds)
    kByteAudioEventRecordingFirstCallback = 1101,
    // record no frame error. msg: check_time_seconds, start time out(seconds)
    kByteAudioEventRecordingNoCallbackError = 1102,
    // record stop event. code: 0 success; other: error see @ByteAudioErrorCode
    kByteAudioEventRecordingStop = 1103,
    // record stream interrupt error.
    kByteAudioEventRecordingStreamError = 1104,
    // record frame silence notify.
    kByteAudioEventRecordingSilence = 1105,

    // playout start event. code: 0 success; other: error see @ByteAudioErrorCode
    kByteAudioEventPlayoutStart = 1200,
    // playout first frame callback. msg: time_since_start, start delay(milliseconds)
    kByteAudioEventPlayoutFirstCallback = 1201,
    // playout no frame error. msg: check_time_seconds, start time out(seconds)
    kByteAudioEventPlayoutNoCallbackError = 1202,
    // playout stop event. code: 0 success; other: error see @ByteAudioErrorCode
    kByteAudioEventPlayoutStop = 1203,
    // playout stream interrupt error.
    kByteAudioEventPlayoutStreamError = 1204,

    // frst audio frame recorded of input stream. code: the id of stream
    kByteAudioEventInputStreamFirstRecorded = 2000,
    // frst audio frame encoded of input stream. code: the id of stream
    kByteAudioEventInputStreamFirstEncoded = 2001,
    // audio frame encode failed of input stream. code: the id of stream
    kByteAudioEventInputStreamEncodeFailed = 2002,

    // first audio frame decoded of output stream. code: the id of stream
    kByteAudioEventOutputStreamFirstDecoded = 4000,

    /**
    * internal event key, only used for engine communicates with adm or nodes
    * which should be export to the caller ,e.g. RtcSDK, thus, sdk should not
    * parsing the following event key
    */
    // PC system default record device changed.
    kByteAudioEventRecordingSystemDefaultChanged = 5000,
    // PC communication default record device changed.
    kByteAudioEventRecordingCommDefaultChanged = 5101,
    // PC record device add.
    kByteAudioEventRecordingDeviceAdd = 5102,
    // PC record device remove.
    kByteAudioEventRecordingDeviceRemove = 5103,

    // PC system default playout device changed.
    kByteAudioEventPlayoutSystemDefaultChanged = 5104,
    // PC communication default playout device changed.
    kByteAudioEventPlayoutCommDefaultChanged = 5105,
    // PC playout device add.
    kByteAudioEventPlayoutDeviceAdd = 5106,
    // PC playout device remove.
    kByteAudioEventPlayoutDeviceRemove = 5107,
    // PC whether is white list device (hit whitelist config).
    kByteAudioEventWhiteListDevice = 5108,

    // record device volume changed.
    kByteAudioEventRecordingDeviceVolumeChanged = 5110,
    // playout device volume changed.
    kByteAudioEventPlayoutDeviceVolumeChanged = 5111,
    // Audio session info on mobile.
    kByteAudioEventAudioSessionInfoUpdated = 5112,

    // Audio device related event report
    kByteAudioDeviceEventReport = 5200,
    // Audio device support hardware earback or not
    kByteAudioDeviceEventSupportHardwareEarback = 5201,

    // Audio dump
    kByteAudioDumpEventReport = 5202,

    // Audio device hardware earback released
    kByteAudioDeviceEventHardwareEarbackReleased = 5203,

    // Model download message
    kByteAudioModelDownload = 5300,

    // Audio System API releated event report
    kByteAudioSystemAPIEventReport = 5500,
    kByteAudioSystemAPIEventReportTimeOut = 5501

};

/**
 * @brief Audio codec type supported.
 */
enum ByteAudioCodecType {
    // Invalid type
    kByteAudioCodecInvalid = 0,
    // PCM
    kByteAudioCodecPCM = 10000,
    // Opus
    kByteAudioCodecOpus = 10001,
    // G711A
    kByteAudioCodecG711A = 10002,
    // G711U
    kByteAudioCodecG711U = 10003,
    // AAC
    kByteAudioCodecAAC = 10004,
    // G.722.1 audio codec
    kByteAudioCodecG722_1 = 10005,
    // NICO audio codec
    // NICO 1.0
    kByteAudioCodecNICO = 10007,
    // NICO 2.0
    kByteAudioCodecNICO2 = 10008,
};

enum ByteAudioAACTransType {
    kByteAudioTTRAW = 0,
    kByteAudioTTADTS = 1,
    kByteAudioTTADIF = 2,
    kByteAudioTTLATM_MCP1 = 3,
    kByteAudioTTLATM_MCP0 = 4,
    kByteAudioTTInvalid
};

/**
 * @brief Audio routing.
 */
enum ByteAudioRouting {
    // default audio routing
    kByteAudioRoutingDefault = 0,
    // headset
    kByteAudioRoutingHeadset = 1,
    // earpiece
    kByteAudioRoutingEarpiece = 2,
    // speaker
    kByteAudioRoutingSpeakerhone = 3,
    // headset bluetooth
    kByteAudioRoutingHeadsetBluetooth = 4,
};

/**
 * @brief Audio device type.
 */
enum ByteAudioDeviceType {
    kByteAudioDeviceUnknown = -1,
    // render device
    kByteAudioRenderDevice = 0,
    // capture device
    kByteAudioCaptureDevice = 1,
    // sharing device, only valid for start_device/stop_device interface
    kByteAudioShareDevice = 2,
};

/**
 * @brief Get audio device with option.
 */
enum ByteAudioDeviceOption {
    // the opening device
    kByteAudioCurrentUseDevice = 0,
    // the system default device
    kByteAudioSystemDefaultDevice,
    // the communication default device, only valid on Windows
    kByteAudioCommunicationDefaultDevice,
};

/**
 * @brief Audio device state.
 */
enum ByteAudioDeviceStateType {
    // The device is active.
    kByteAudioDeviceStateActive = 1,
    // The device is disabled.
    kByteAudioDeviceStateDisabled = 2,
    // The device is not present.
    kByteAudioDeviceStateNotPresent = 4,
    // The device is unplugged.
    kByteAudioDeviceStateUnplugged = 8
};

/**
 * @brief Audio device generic config.
 */
enum ByteAudioDeviceConfigKey {
    // Unknown config, won't handle
    kByteAudioUnknownConfig = -1,
    /**
     * @brief Mute audio unit capture data in vpio mode, the microhpone icon disappear after ios 14
     * Affect Platform: IOS
     * Affect Device Type: kByteAudioCaptureDevice
     */
    kByteAudioUnitMuteInput = 1000,

    /**
     * @brief Bypass all voice processing in vpio mode, uesd in music mode
     * Affect Platform: IOS
     * Affect Device Type: kByteAudioCaptureDevice
     */
    kByteAudioUnitByPassProcessing = 1001,

    /**
     * @brief When virtual driver installing, no need to restart current device.
     * Affect Platform: Mac
     * Affect Device Type: kByteAudioShareDevice
     */
    kByteAudioPassRestartProcessing = 1002,

    /** @brief Capture dmo mode need render device guid
     * Affect Platform: Windows
     * Affect Device Type: kByteAudioCaptureDevice
     */
    kByteAudioDmoSettingsRenderDevice = 1003,

    /** @brief Set runtime stats silence checkt max threshold(used by internal)
     * Affect Platform: All
     * Affect Device Type: kByteAudioCaptureDevice
     */
    kByteAudioRuntimeStatsSilenceChecktMaxThreshold = 1004,

    /**
     * @brief Whether use external soloAmbient/Ambient category when only play for enable ios silence mode in game scene.
     * Affect Platform: IOS
     * Affect Device Type: kByteAudioCaptureDevice
     */
    kEngineOptIOSOnlyPlayEnableSilenceMode = 1005,
};

/**
 * @brief Audio device property.
 */
struct ByteAudioDeviceProperty {
    /**
    * @brief Audio device transport type.
    */
    enum ByteAudioDeviceTransportType {
        kByteAudioTypeUnknown = -1,
        kByteAudioTypeBuiltIn,
        kByteAudioTypeBlueTooth,
        kByteAudioTypeVirtual,
        kByteAudioTypeUSB,
        kByteAudioTypeDisplayAudio,
        kByteAudioTypePCI,
        kByteAudioTypeAirPlay,
    };

    bool handsfree_mode = false;
    bool stereo_mode = false;
    ByteAudioDeviceTransportType transport_type = kByteAudioTypeUnknown;
};

/**
 * @brief Audio device volume ability.
 */
struct ByteAudioDeviceVolumeAbility {
    /**
    * @brief Audio device ability.
    */
    enum ByteAudioAbilityType {
        kByteAudioUnknown = -1,
        kByteAudioAble,
        kByteAudioUnable,
    };

    ByteAudioAbilityType volume_gain_able = kByteAudioUnknown;
    ByteAudioAbilityType volume_set_able = kByteAudioUnknown;
    ByteAudioAbilityType volume_mute_able = kByteAudioUnknown;
};

/**
 * @brief Audio device information.
 */
struct BYTEAUDIO_API ByteAudioDeviceInfo {
    /**
    * @brief Audio device status.
    */
    enum ByteAudioDeviceStatus {
        kByteAudioStatusUnkown = -1,
        kByteAudioNormal,
        kByteAudioNotExist,
        kByteAudioOccupiedByOthers,
    };

    ByteAudioDeviceInfo();

    ByteAudioDeviceInfo(const ByteAudioDeviceInfo& src) = default;

    ByteAudioDeviceInfo& operator=(const ByteAudioDeviceInfo& src);

    // reset all device info property
    void reset();

    // compare device info
    bool equals(const struct ByteAudioDeviceInfo* pOther);

    std::string device_id;
    std::string device_name;
    std::string device_container_id;
    int64_t device_vid;
    int64_t device_pid;
    ByteAudioDeviceType device_flow;
    ByteAudioDeviceStatus device_status;
    ByteAudioDeviceProperty device_property;
    ByteAudioDeviceVolumeAbility device_volume_ability;
};

enum ByteAudioDeviceStage {
    kByteAudioDeviceStageUnkown = -1,
    /**
    * @brief Device Operations
    */
    kByteAudioDeviceStageInit = 1,
    kByteAudioDeviceStageSet = 2,
    kByteAudioDeviceStageInitialize = 3,
    kByteAudioDeviceStageStart = 4,
    kByteAudioDeviceStageStop = 5,
    kByteAudioDeviceStageTerminate = 6,
    kByteAudioDeviceStageGetDeviceNumber = 7,
    kByteAudioDeviceStageGetDeviceName = 8,
    kByteAudioDeviceStageGetMuteCapability = 9,
    kByteAudioDeviceStageSetMute = 10,
    kByteAudioDeviceStageGetMute = 11,
    kByteAudioDeviceStageGetVolumeCapability = 12,
    kByteAudioDeviceStageSetVolume = 13,
    kByteAudioDeviceStageGetVolume = 14,
    kByteAudioDeviceStageGetDefaultDevice = 15,
    kByteAudioDeviceStageStartBegin = 16,  // start begin
    kByteAudioDeviceStageStopBegin = 17,   // stop begin
    /**
     * @brief Check audio whehter having permission when calling start capture.
     *          it just records the event, no action is so far, APP should handle it already.
     *
     */
    kByteAudioDeviceStageCheckPermission = 18,  //check permission
    /**
     * @brief IOS/Android receive route change event from system.
     *      it just records the event, no action is required.
     *
     */
    kByteAudioDeviceStageRouteChanged = 19,  //route changed, ios/anroid
    /**
     * @brief IOS receives interruption begin from other APP.
     *          it just records the event, no action is required.
     *
     */
    kByteAudioDeviceStageInterruptionBegin = 20,  //interruption begin, ios only

    /**
     * @brief IOS receives interruption end from other APP.
     *          it just records sthe event, no action is required.
     */
    kByteAudioDeviceStageInterruptionEnd = 21,  //interruption end,ios only
    /**
     * @brief IOS receives mediaserver ternimate from system.
     *              it just records the event, no action is required.
     */
    kByteAudioDeviceStageMediaserverTerminated = 22,  //mediaservice terminate, ios only
    /**
     * @brief IOS receives mediaserver reset from system.
     *      it just records the event, no action is required.
     */
    kByteAudioDeviceStageMediaserverReset = 23,  //mediaservice reset, ios only

    /**
     * @brief Due to no data is captured or played in certain seconds, it will do restart.
     *          it just records the event, no action is required.
     */
    kByteAudioDeviceStageRestart = 24,  //restart begin

    /**
    * @brief Run time error, such as interruption, plug in/out session disconnect
    *        check device running status.
    *           1. if first frame is arrive, the error code will be kByteAudioSuccess
    *           2. if it doesn't capture any data in 2 second, it will return error code kByteAudioDeviceNoCallback
    *           3. if it received format change event, it will return error code kByteAudioDevicePropertyChanged.
    *        2, 3 need to reatart capture or playback.
    */
    kByteAudioDeviceStageDeviceRunning = 100,

    /**
    * @brief audio signal issue, such as echoling, choppy, clipping.
    */
    kByteAudioDeviceStageSignalRunning = 200
};

struct ByteAudioEventInfo {
    ByteAudioDeviceType device_type = kByteAudioDeviceUnknown;
    ByteAudioErrorCode rtc_error = kByteAudioSuccess;
    ByteAudioDeviceStage device_stage = kByteAudioDeviceStageUnkown;
    int32_t system_error_code = 0;
    int64_t elapse = 1;
    std::string system_api = "";
    std::string call_parameters = "";
    std::string verbose = "";
    std::string location = "";
    std::string device_id = "";
    std::string device_name = "";
    std::string media_mode = "";
    std::string scenario = "";
    std::string event_session_id = "";
    std::string device_vid = "";
    std::string device_pid = "";
};

/**
 * @brief android record detect callback info,
 *        see https://developer.android.com/reference/android/media/AudioRecordingConfiguration
 *        audio_session_id: the session number of the recording. (available api 24)
 *        client_audio_source: the audio source selected by the client. (available api 24)
 *        audio_source: the audio source currently used to configure the capture path. (available api 29)
 *                      -1: not supported (lower than api 29)
 *        is_client_silenced: whether if the audio returned to the client is currently being silenced
 *                            by the audio framework due to concurrent capture policy. (available api 29)
 *                            1: be silenced
 *                            0: not silenced
 *                            -1: not supported (lower than api 29)
 *        is_by_self: whether if the info callback by AndroidRecord capture in byteaudio (available api 24)
 *                    1: callback by byteaudio self
 *                    0: callback by other record instance
 *                    -1: not supported (using OpenSLES, can not distinguish session id)
*/
struct ByteAudioAndroidRecordCallbackInfo {
    int audio_session_id = -1;
    int client_audio_source = -1;
    int audio_source = -1;
    int is_client_silenced = -1;
    int is_by_self = -1;
};

}  // namespace bae
