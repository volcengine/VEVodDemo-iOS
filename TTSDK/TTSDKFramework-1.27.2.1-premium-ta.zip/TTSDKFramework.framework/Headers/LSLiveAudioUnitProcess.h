//  Copyright © 2018 tianzhuo. All rights reserved.

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "LSLiveAudioEffect.h"
#import "LSLiveAudioConverter.h"

@interface LSLiveAudioUnitConfig : NSObject

@property (nonatomic) NSURL *musicURL;
@property (nonatomic) AudioStreamBasicDescription asbd;
@property (nonatomic) NSTimeInterval musicStartTime;
@property (nonatomic) LSMusicType musicType;
@property NSInteger numberOfLoops;
@property (nonatomic, assign) BOOL newPlayerMode;
@property (nonatomic,copy) void(^musicPlayErrorBlock)(int status, NSString* errorMsg);

@end

@interface LSLiveAudioUnitProcess : NSObject

@property (nonatomic,assign)BOOL blueToothPlayAllowed;
@property (nonatomic) LSLiveAudioEffect *audioEffect;
@property (nonatomic,copy) void(^musicPlayEndBlock)(BOOL success);
@property (nonatomic,assign) BOOL closeProcess;
@property (nonatomic, copy) void (^loopEndBlock)(void);
@property (nonatomic, strong) LSLiveAudioUnitConfig *config;
@property (nonatomic, assign) BOOL bEnableLoudNorm;

- (instancetype)initWithConfig:(LSLiveAudioUnitConfig *)config;

- (void)startProcess;
- (void)pauseProcess;
- (void)stopProcess;
- (void)restart;
- (void)getBgmAudioData:(int16_t *)ioData dataSize:(UInt32)dataSize channels:(int)channels inNumberFrames:(UInt32)inNumberFrames;
- (void)processAudioBufferList:(AudioBufferList *)ioData inNumberFrames:(UInt32)inNumberFrames;
- (void)processAudioData:(int16_t *)mData dataSize:(UInt32)dataSize  inNumberFrames:(UInt32)inNumberFrames;
- (BOOL)isPlaying;

- (NSInteger)getCurLoop;

- (NSInteger)numberOfLoop;

- (void)setRecordVolume:(CGFloat)recordVolume;

- (CGFloat)getRecordVolume;
- (void)setMusicVolume:(CGFloat)musicVolume;

- (CGFloat)getMusicVolume;

- (void)setMusicPlayerVolume:(CGFloat)musicVolume;

- (CGFloat)getMusicPlayerVolume;

- (NSTimeInterval)getMusicDuration;
- (NSTimeInterval)getCurrentPlayTime;

- (uint64_t)readFirstFrameTick;

- (void)seekToTime:(NSTimeInterval)time;

- (void)replacePlayerItem:(NSString *)path;

- (void)setEnableAudioPitchShifter:(BOOL)enable;

- (BOOL)isEnableAudioPitchShifter;

- (void)setPitch:(double)pitch;

@end
