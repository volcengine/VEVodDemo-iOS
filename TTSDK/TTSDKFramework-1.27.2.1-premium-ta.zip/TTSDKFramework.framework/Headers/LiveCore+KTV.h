
#import "LiveCore.h"
#import "LCAudioScore.h"
#import "LCAudioKTVEffect.h"


NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, LCKTVType) {
    LCKTVTypeNormal = 0,        
    LCKTVTypeOnlyLocalPlay      
};

typedef NS_ENUM(NSUInteger, LCKTVMusicType) {
    LCKTVMusicTypeAccompany = 0,
    LCKTVMusicTypeOriginalSing,
};

typedef NS_ENUM(NSInteger, LCKTVErrorCode) {
    LCKTVErrorCodeUnsupportedRemoteIOType       = -1,
    LCKTVErrorCodeUnsupportedDevice             = -2,
    LCKTVErrorCodeSessionNotRunning             = -3,
    LCKTVErrorCodeAudioStreamDescriptionInvalid = -4,
    LCKTVErrorCodeOpenURLFailed                 = -5,
    LCKTVErrorCodeAudioConverterFailed          = -6,
    LCKTVErrorCodeAudioFileReadPacketFailed     = -7, 
    LCKTVErrorCodeMusicUrlIsNULL                = -8,
    LCKTVErrorCodeStartTimeError                = -9,
};

typedef void(^LCKTVLyricInfoDidReceiveCallback)(NSString *key, NSDictionary *lyricInfo);

@interface LCKTVConfig : NSObject

@property (nonatomic, strong) NSURL *musicURL;

@property (nonatomic, assign) BOOL loop;

@property (nonatomic, assign) NSTimeInterval musicStartTime;

@property (nonatomic, assign) LCKTVType ktvType;

@property (nonatomic, assign) LCKTVMusicType musicType;

+ (instancetype)defaultConfigWithMusicURL:(NSURL *)musicURL;

@end

@interface LiveCore (KTV)

@property (nonatomic, copy) LCKTVLyricInfoDidReceiveCallback lyricInfoDidReceiveCallback;

@property (nonatomic, assign, getter=isReverberationEnabled) BOOL reverberationEnabled;

+(BOOL)ktvAllowed;
- (void)playBgMusicWithURL:(NSURL *)url loop:(BOOL)loop volume:(float)volume createPlayerCompletion:(void(^)(BOOL success, NSError *error))createBlock completionBlock:(void(^)(void))completionBlock;

- (void)playBgMusicWithConfig:(LCKTVConfig *)config
       createPlayerCompletion:(void(^)(BOOL success, NSError *error))createBlock
              completionBlock:(void(^)(void))completionBlock;

- (NSTimeInterval)currentPlayTime;

- (NSTimeInterval)musicDuration;

- (void)seekToTime:(NSTimeInterval)time;

- (void)sendLyricInfo:(NSDictionary *)lyricInfo withKey:(NSString *)key;

- (void)sendLyricStringInfo:(NSString *)lyricInfo withKey:(NSString *)key;

- (void)stopBgMusic;
- (void)pauseBgMusic;
- (void)resumeBgMusic;
- (BOOL)musicIsPlaying;

- (float)getMusicVolume;
- (void)setMusicVolume:(float)musicVolume;
- (float)getMusicPlayerVolume;
- (void)setMusicPlayerVolume:(CGFloat)musicVolume;
- (float)getAudioVolume;
- (void)setAudioVolume:(float)audioVolume;

- (void)applyReverb2Format:(NSString *)type;

- (void)setAudioScoreEngine:(LCAudioScore *)engine;

- (void)setKtvEffectEngine:(LCAudioKTVEffect *)engine;

- (void)muteLocalAudioStream:(BOOL)mute exceptBgm:(BOOL)exceptBgm;

- (void)setEnableAudioPitchShifter:(BOOL)enable;
- (BOOL)isEnableAudioPitchShifter;
- (void)setPitch:(double)pitch;

- (void)setEnableLoudNorm:(BOOL)enable;
- (BOOL)isEnableLoudNorm;
- (void)setLoudNormParams:(NSDictionary *)loudNormParam;

- (void)forceMediaMode:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
