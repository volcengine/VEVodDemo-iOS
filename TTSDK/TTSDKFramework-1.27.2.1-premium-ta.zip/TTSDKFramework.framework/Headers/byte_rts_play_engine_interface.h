/*
 * Copyright 2020 @bytedance
 *  Created on: Seq 05, 2020
 */

#pragma once

#include "byte_rts_play_engine_define.h"

#ifdef WIN32
#define BYTE_RTS_EXPORT __declspec(dllexport)
#else
#define BYTE_RTS_EXPORT __attribute__((__visibility__("default")))
#endif

namespace bytertc {

class IRTSPlayEngineObserver {
 public:
    /**
     * @brief Notify RtsPlay of critical events
     * @param [out] event The event type
     *        [out] biz_data,  Business private data
     */
    virtual void OnEventNotify(RTSPlayEngineEvent event, void* biz_data) = 0;
    /**
     * @brief Notifies RtsPlay of error events
     * @param [out] Error Error type
     *        [out] private_data,  Business private data
     */
    virtual void OnErrorNotify(RTSPlayEngineError error, void* biz_data) = 0;
    /**
     * @brief Audio data frame callback after decoding
     * @param [out] aframe Audio Data Frame (PCM)
     */
    virtual void OnAudioFrame(const RTSAudioFrame& aframe) = 0;
    /**
     * @brief Audio data frame callback after decoding
     * @param [out] vframe Video data frame (YUV420P or OES)
     */
    virtual void OnVideoFrame(const RTSVideoFrame& vframe) = 0;

    /**
     * @brief Log the callback
     * @param [out] level The level of logging
     *        [out] content Log contents
     *        [out] private_data,  Business private data
     *
     */
    virtual void OnLogPrint(RTSPlayEngineLogLevel level, const char* content, void* biz_data) = 0;
    /**
     * @brief Buried point correction
     * @param [out] level Buried point level
     *        [out] trace_tag Buried point label
     *        [out] content Buried point content
     *        [out] private_data,  Business private data
     *
     */
    virtual void OnTracePrint(
            RTSPlayEngineTraceLevel level, const char* trace_tag, const char* content, void* biz_data) = 0;
    /**
     * @brief The destructor
    */
    virtual ~IRTSPlayEngineObserver() = default;
};

class IRTSPlayEngine {
 public:
    /**
     * @brief Player initialization
     * > Player initialize self compent, thread object
     * @param [in] observer Player delegate object
     *        [in] config  Player configuration
     * @return
     *        0: success；
     *    other: failure；
     */
     virtual int32_t Init(IRTSPlayEngineObserver* observer, RTSPlayEngineConfigure config) = 0;
     /**
      * @brief Player Reverse initialization
      * >  Release the child component and release the thread object
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual int32_t UnInit() = 0;
     /**
      * @brief Player Pre-broadcast preparation
      * >  1， Request to answer 2, Establish a ICE 3 ，Decoding the first frame
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual int32_t Prepare() = 0;
     /**
      * @brief Player premiere
      * >  Changes the play state and adjusts the audio video data
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual int32_t Start() = 0;
     /**
      * @brief Player Close play
      * >  Changes the play state and stop the audio video data
      * @param reason
      *        The cause of stop play,see RTSStopReason
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual int32_t Stop(RTSStopReason reason) = 0;
     /**
      * @brief Player Whether it is on open state
      * >
      * @return
      *     true : open；
      *     false: close；
      */
     virtual bool IsPlaying() = 0;
     /**
      * @brief Player Obtain the SDK version number
      */
     virtual const char* GetSdkVersion() const = 0;
     /**
      * @brief Player Setting Private Parameters
      * >
      * @param [in] params Private parameters (JSON format)
      */
     virtual int32_t SetParameter(const char* params) = 0;
     /**
      * @brief Set the ICE reconnection times and reconnection interval
      * >  By default, the number of reconnections is 3, and the reconnection interval is 1000ms
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual bool SetConnectRetryCount(int count, int interval) = 0;
     /**
      * @brief Get play status
      * >
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual int32_t GetStatsReport(RTSPlayEngineStats* rts_stats) = 0;
    /**
        * @brief Obtain engine report information
        * @param trace_type
        *        Type of Information reported,see RTSTraceType
        * @param rts_trace
        *        Report information Pointer,see RTCPlayEngineTrace
        * @return
        *        0: success；
        *    other: failure；
        */
    virtual int32_t GetTracePrint(RTSTraceType trace_type, RTSPlayEngineTrace* rts_trace) = 0;
     /**
      * @brief Set the Play Volume
      * >  Setting the Downlink Volume (0 to 100)
      * @return
      *        0: success；
      *    other: failure；
      */
     virtual bool SetAudioVolume(int32_t volume) = 0;
     /**
      * @brief Mute can make
      * >mute:true mute，mute:false cancel the mute
      * @param [in] mute Mute signal
      */
     virtual void SetAudioMute(bool mute) = 0;
     virtual ~IRTSPlayEngine() = default;
};

/**
 * @brief Creating a play engine
 * > This method creates and initializes an instance of IRTSPlayEngine. To use IRTSPlayEngine, you must first call this interface for initialization.
 * @param [in] app_id,  Byte is the App ID issued for the application developer
 */
BYTE_RTS_EXPORT IRTSPlayEngine* CreateRtsPlayEngine(const char* app_id);

/**
 *@brief Destroy playback engine
 * > This method frees all resources used by the IRTSPlayEngine instance.
 * @param [in] engine,   An instance created by CreateRtsPlayEngine
 */
BYTE_RTS_EXPORT void DestroyRtsPlayEngine(IRTSPlayEngine* engine);

} /* namespace bytertc */
