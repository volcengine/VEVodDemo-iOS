//
//  TTLiveURLComposer.h
//  TTSDK
//
//  Created by guojieyuan on 2021/8/31.
//

#import <Foundation/Foundation.h>
#import "TVLPlayerItemPreferences.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTLiveURLComposer : NSObject

/**
 Enable Video Process。when set YES, first Check device is support by [TVLManager isSupportSR]
 */
@property (nonatomic) BOOL enableSR;

/**
 Mutilple Codec Function
 
 Add New Live Stream Url With Specific  'Codec' / 'Source'
 `See TTSDK Live API doc form more detail.`
 
 Default Setting:  Resolution - Origin / Format - FLV
 
 @param url Live Stream Url.
 @param encodeType Stream Video Codec: TVLVideoCodecType - (h264/h264)
 @param source Stream Source Type: TVLMediaSourceType - (origin / backup)
 */
- (void)addUrl:(NSString *)url
      forCodec:(TVLVideoCodecType)encodeType
     forSource:(TVLMediaSourceType)source;

/**
 Mutiple Format Function
 Add New Live Stream Url With Specific 'Format'
 
 @param url Live Stream Url.
 @param format Stream Video Format: TVLMediaFormatType - (FLV / HLS...)
 */
- (void)addUrl:(NSString *)url forFormat:(TVLMediaFormatType)format;

/**
 Mutiple Resoulution Function
 Add New Live Stream Url With Specific 'Res'
 
 @param url Live Stream Url.
 @param resolution Stream Resoulution: TVLMediaResolutionType - (origin/ld/sd/hd/...)
 */
- (void)addUrl:(NSString *)url
 forResolution:(TVLMediaResolutionType)resolution;

/**
 Add New Live Stream Url With Specific 'Resoulution' / 'Codec' / 'Source' / 'Format'
 `See TTSDK Live API doc form more detail.`
 
 @param url Live Stream Url.
 @param resolution Stream Resoulution: TVLMediaResolutionType - (origin/ld/sd/hd/...)
 @param encodeType Stream Video Codec: TVLVideoCodecType - (h264/h264)
 @param source Stream Source Type: TVLMediaSourceType - (origin / backup)
 @param format Stream Video Format: TVLMediaFormatType - (FLV / HLS...)
 
 */
- (void)addUrl:(NSString *)url
 forResolution:(TVLMediaResolutionType)resolution
      forCodec:(TVLVideoCodecType)encodeType
     forSource:(TVLMediaSourceType)source
     forFormat:(TVLMediaFormatType)format;

@end

NS_ASSUME_NONNULL_END
