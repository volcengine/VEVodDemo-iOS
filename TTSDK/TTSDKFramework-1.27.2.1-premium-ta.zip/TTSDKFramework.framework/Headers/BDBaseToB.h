//
//  BDBaseToB.h
//  BDWebImage
//
//  Created by wby on 2021/2/9.
//

#import <Foundation/Foundation.h>
#import "BDBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDBaseToB : NSObject<BDBase>

@end

NS_ASSUME_NONNULL_END
