//  Copyright © 2017 zhaokai. All rights reserved.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, LiveStreamAudioSource) {
    LiveStreamAudioSourceMic = 0, 
    LiveStreamAudioSourceMix = 1, 
};

typedef NS_ENUM(NSInteger, LiveStreamMode)
{
    LiveStreamModeAudioAndVideo  = 0, 
    LiveStreamModeAudioOnly          = 1, 
    LiveStreamModeVideoOnly          = 2, 
    LiveStreamModeAudioANDDarkFrame = 3, 
};

typedef NS_ENUM(NSUInteger, LiveStreamVideoCodec) {
    LiveStreamVideoCodec_VT_264 = 0, 
    LiveStreamVideoCodec_VT_ByteVC1 = 1, 
};

typedef NS_ENUM(NSInteger, LiveStreamAudioCodec) {
	LiveStreamAudioCodec_AT_AAC_LC	    = 0,
    LiveStreamAudioCodec_AT_AAC_HE      = 1,
	LiveStreamAudioCodec_FAAC_LC        = 2,
	LiveStreamAudioCodec_FAAC_HE        = 3,
	LiveStreamAudioCodec_FAAC_HE_V2     = 4,
};

typedef NS_ENUM(NSInteger, LiveProfileLevelType)
{
    LiveEnCodecBaseline30       = 130,
    LiveEnCodecBaseline31       = 131,
    LiveEnCodecBaseline32       = 132,
    LiveEnCodecBaseAutoLevel    = 159,
    LiveEnCodecMainProfile30    = 230,
    LiveEnCodecMainProfile31    = 231,
    LiveEnCodecMainProfile32    = 232,
    LiveEnCodecMainAutoLevel    = 259,
    LiveEnCodecHighProfile30    = 330,
    LiveEnCodecHighProfile31    = 331,
    LiveEnCodecHighProfile32    = 332,
    LiveEnCodecHighAutoLevel    = 359,
    
    LiveEnCodecByteVC1MainAutoLevel    = 901,
    LiveEnCodecByteVC1Main10AutoLevel  = 902,
};

typedef NS_ENUM(NSInteger, LiveStreamBitrateAdaptationStrategy) {
    LiveStreamBitrateAdaptationStrategy_NORMAL = 0,
    LiveStreamBitrateAdaptationStrategy_SENSITIVE,
    LiveStreamBitrateAdaptationStrategy_MORE_SENSITIVE,
};

typedef NS_OPTIONS(NSInteger, LiveStreamLogFlag) {
    LiveStreamLogFlagNone                = 0,
    LiveStreamLogFlagPrint               = 1 << 0, 
    LiveStreamLogFlagAlog                = 1 << 1, 
    
    LiveStreamLogFlagAll                 = (LiveStreamLogFlagPrint |
                                            LiveStreamLogFlagAlog),
};

@interface SITIConfig : NSObject

@property (nonatomic, assign) int sitiStrategyVer;

@property (nonatomic, assign) BOOL usingGPU;
@property (nonatomic, assign) int threadCount;
@property (nonatomic, assign) int periodMS;
@property (nonatomic, assign) int extractDuration;
@property (nonatomic, assign) int framesCountsCalcSiti;

@property (nonatomic, assign) int qulityMode;

@end

@interface LiveStreamConfiguration : NSObject

+ (instancetype)defaultConfiguration;

@property (nonatomic, copy) NSString *rtmpURL;

@property (nonatomic, copy) NSArray<NSString *> *URLs;

@property (nonatomic, copy) NSDictionary *sdkParams;

@property (nonatomic, copy) NSString *project_key;

@property (nonatomic, assign) LiveStreamMode streamMode;

@property (nonatomic, assign) LiveStreamAudioSource audioSource;


@property (nonatomic, copy) NSString *capturePreset;

@property (nonatomic, assign) CGSize outputSize;

@property (nonatomic, assign) NSUInteger bitrate;

@property (nonatomic, assign) NSUInteger maxBitrate;

@property (nonatomic, assign) NSUInteger minBitrate;

@property (nonatomic, assign) NSUInteger audioBitrate;

@property (nonatomic, assign) NSUInteger videoFPS;

@property (nonatomic, assign) NSInteger gopSec;

@property (nonatomic, assign) CGFloat gopSecMax;

@property (nonatomic, assign) BOOL enableBFrame;

@property (nonatomic, assign) BOOL nodeProbePoll;

@property (nonatomic, assign) BOOL enableNTP;

@property (nonatomic, strong) NSArray<NSString *> *NTPServers;

@property (nonatomic, assign) LiveStreamBitrateAdaptationStrategy bitrateAdaptStrategy;

@property (nonatomic, assign) BOOL enableOpenGOP;

@property (nonatomic, assign) NSUInteger audioChannelCount;
@property (nonatomic, assign) NSUInteger audioSampleRate;

@property (nonatomic, assign) NSInteger streamLogTimeInterval;

@property (nonatomic, assign) BOOL allowsRealTimeAudioPowerLevel;

@property (nonatomic, assign) LiveStreamAudioCodec aCodec;

@property (nonatomic, assign) LiveStreamVideoCodec vCodec;

@property (nonatomic, assign) LiveProfileLevelType profileLevel;

@property (nonatomic, assign) BOOL enableExtenionMode;

@property (nonatomic, assign) BOOL enableBackgroundMode;

@property (nonatomic, strong) UIImage *backgroundImage;

@property (nonatomic, assign) BOOL useCustomizedSEI DEPRECATED_MSG_ATTRIBUTE("will be delete");

@property (nonatomic, assign) BOOL SEINeedSource;

@property (nonatomic, assign) BOOL enableCompleteFrames;

@property (nonatomic, assign) NSInteger dtsAdjustParam;

@property (nonatomic, copy) NSString *authorizationString;

@property (nonatomic, assign) BOOL enableWSEI;

@property (nonatomic, assign) BOOL enableDownPKResolution;
@property (nonatomic, assign) BOOL enableAudioCaptureStopAsync;
@property (nonatomic, assign) BOOL enableForceCompositingLayout;
@property (nonatomic, assign) float enableMipmapRatio;
@property (nonatomic, assign) BOOL enableRTCElapseStatistics;

@property (nonatomic, assign) int expectFps;

@property (nonatomic, assign) BOOL psnrEnable;
@property (nonatomic, assign) int psnrPeriodSeconds;
@property (nonatomic, assign) int psnrCalcFrames;

@property (nonatomic, assign) BOOL reduceMode;

@property (nonatomic, assign) LiveStreamLogFlag liveStreamLogFlag;

@property (nonatomic, assign) int64_t seiCurrentShiftDiffTime;
@property (nonatomic, assign) BOOL enableSeiCurrentShiftDiffTime;

@property (nonatomic, assign) BOOL enableManualHEAACConfigPacket;

@property (nonatomic, assign) BOOL enableSetOpenGOP;
@property (nonatomic, assign) BOOL enableSetGopSec;
@property (nonatomic, assign) BOOL enableNewSetOutputSizeMode;

@property (nonatomic, assign) BOOL addMixerNodeWhenCameraNotFull;

@property (nonatomic, assign) BOOL enableNewUpdateSendCacheConfig;

@property (nonatomic, assign) BOOL enableRtmpStopPoll;
@property (nonatomic, assign) int64_t rtmpTimeRotation;

@property (nonatomic, assign) int vEncImpl;

@property (nonatomic, assign) BOOL enableDynamicDtsAdjust;
@property (nonatomic, assign) int extraDtsAdjust;

@property (nonatomic, assign) BOOL enableBlackFrameLeakFix;

@property (nonatomic, assign) BOOL enableBlackFrameOptimization;

@property (nonatomic, assign) BOOL enableDeferredCompositingLayout;

@property (nonatomic, assign) BOOL unableMixerWithSameFrameBuffer;

@property (nonatomic, assign) BOOL enableVideoResOpt;

@property (nonatomic, assign) BOOL enableAddMixCheck;

@property (nonatomic, assign) BOOL enableRenderStallStats;

@property (nonatomic, assign) BOOL purgeFBOnInputGLError;

@property (nonatomic, assign) BOOL enableVEncInputPtsLimit;

@property (nonatomic, assign) BOOL onlyRenderOnViewReady;

@property (nonatomic, assign) BOOL enableSITI;
@property (nonatomic, strong) SITIConfig* sitiConfig;

@property (nonatomic, assign) BOOL enablePerformanceObserve;

@property (nonatomic, assign) BOOL rtsSupportVideoRtx;

@property (nonatomic, assign) NSInteger contourCalculateThreshold;
@property (nonatomic, assign) NSInteger enableContourCalculate;
@property (nonatomic, assign) BOOL enableMergeContourInfoSEI;

@property (nonatomic, assign) BOOL rtsEnableDtls;

@property (nonatomic, assign) BOOL rtsAllowIgnoreBrAdjust;

@property (nonatomic, assign) int rtsStartNoBrAdjustMs;

@property (nonatomic, assign) int rtsHttpPort;

@property (nonatomic, assign) bool enableVideoPipelineLagDetection;

@property (nonatomic, assign) int videoPipelineLagDetectionTimeGap;

@property (nonatomic, assign) int feedFrameTargetFps;

@end
