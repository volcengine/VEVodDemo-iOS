
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

#define VIDEO_FULL_LINK_ENABLE_DUMP 0

#if DEBUG
#define AUDIO_FULL_LINK_ENABLE_DUMP 1
#else
#define AUDIO_FULL_LINK_ENABLE_DUMP 0
#endif

#if VIDEO_FULL_LINK_ENABLE_DUMP
static NSString * _Nullable const kVideoFullLinkEnableDumpNotification = @"kVideoFullLinkEnableDumpNotification";

#define LSRD_VideoDumpDeclare(instance)\
@property (nonatomic, strong) LiveStreamRawDataHelper *instance;
#define LSRD_VideoDumpLazyLoad(methodName,instance)\
- (LiveStreamRawDataHelper *)methodName { \
    if (!instance) { \
        instance = [[LiveStreamRawDataHelper alloc] init]; \
    } \
    return instance; \
}

#define LSRD_VideoDumpAddObserver \
[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleFullLinkEnableDumpNotifications:) name:kVideoFullLinkEnableDumpNotification object:nil];
#define LSRD_VideoDumpRemoveObserver \
[[NSNotificationCenter defaultCenter] removeObserver:self];
#define LSRD_VideoDumpPostNotification(interacted) \
[[NSNotificationCenter defaultCenter] postNotificationName:kVideoFullLinkEnableDumpNotification object:self userInfo:@{@"isInteract": @(interacted)}];

#define LSRD_VideoDumpProcessVideoPixelbuf(receiver,pixelbuf,sourceTypeValue) \
[receiver processVideoPixelbuf:pixelbuf sourceType:sourceTypeValue];
#define LSRD_VideoDumpProcessVideoPixelbufWithFrameTime(receiver,pixelbuf,frameTime,sourceTypeValue) \
[receiver processVideoPixelbuf:pixelbuf presentationTime:frameTime sourceType:sourceTypeValue];

#define LSRD_VideoDumpStartVideoRawRecording(receiver,fileName,maxProcessVideoBufCount,completionHandler) \
[receiver startRawRecordingWithFileName:fileName maxProcessVideoBufCount:maxProcessVideoBufCount CompletionHandler:completionHandler];
#define LSRD_VideoDumpStartVideoRawRecordingWithIsAssemble(receiver,fileName,maxProcessBufCount,assemble,completionHandler) \
[receiver startRawRecordingWithFileName:fileName maxProcessVideoBufCount:maxProcessBufCount isAssemble:assemble CompletionHandler:completionHandler];
#define LSRD_VideoDumpResetRecording(receiver) \
[receiver videoResetRecording];

#else

#define LSRD_VideoDumpDeclare(instance)
#define LSRD_VideoDumpAddObserver
#define LSRD_VideoDumpRemoveObserver
#define LSRD_VideoDumpPostNotification(interacted)
#define LSRD_VideoDumpLazyLoad(methodName,instance)
#define LSRD_VideoDumpProcessVideoPixelbuf(receiver,pixelbuf,sourceTypeValue)
#define LSRD_VideoDumpProcessVideoPixelbufWithFrameTime(receiver,pixelbuf,frameTime,sourceTypeValue)
#define LSRD_VideoDumpStartVideoRawRecording(receiver,fileName,maxProcessVideoBufCount,completionHandler)
#define LSRD_VideoDumpStartVideoRawRecordingWithIsAssemble(receiver,fileName,maxProcessVideoBufCount,isAssemble,completionHandler)
#define LSRD_VideoDumpResetRecording(receiver) 

#endif

#if AUDIO_FULL_LINK_ENABLE_DUMP

#define LSRD_AudioDumpStartAudioRawRecording(receiver,fileName,audioFormatStr) \
[receiver startAudioRawRecordingWithFileName:fileName audioFormat:audioFormatStr];
#define LSRD_AudioDumpStartAudioRawRecordingWithLimitSize(receiver,fileName,audioFormatStr,limitSize) \
[receiver startAudioRawRecordingWithFileName:fileName audioFormat:audioFormatStr audioLimitSize:limitSize];

#define LSRD_AudioDumpProcessPCMData(receiver,pcmData,lengthValue) \
[receiver processPCMData:pcmData length:lengthValue];

#else

#define LSRD_AudioDumpStartAudioRawRecording(receiver,fileName,audioFormat)
#define LSRD_AudioDumpStartAudioRawRecordingWithLimitSize(receiver,fileName,audioFormat,limitSize)
#define LSRD_AudioDumpProcessPCMData(receiver,pcmData,length)

#endif

#if VIDEO_FULL_LINK_ENABLE_DUMP || AUDIO_FULL_LINK_ENABLE_DUMP

#define LSRD_LiveStreamRawDataHelperDeclare(instance)\
@property (nonatomic, strong) LiveStreamRawDataHelper *instance;
#define LSRD_LiveStreamRawDataHelperLazyLoad(methodName,instance)\
- (LiveStreamRawDataHelper *)methodName { \
    if (instance) { \
        instance = [[LiveStreamRawDataHelper alloc] init]; \
    } \
    return instance; \
}

#define LSRD_LiveStreamRawDataHelperCategoryLazyLoad(instance)\
- (LiveStreamRawDataHelper *)instance { \
    LiveStreamRawDataHelper *instance = objc_getAssociatedObject(self, _cmd); \
    if (!instance) { \
        instance = [[LiveStreamRawDataHelper alloc] init]; \
        objc_setAssociatedObject(self, _cmd, instance, OBJC_ASSOCIATION_RETAIN_NONATOMIC); \
    } \
    return instance; \
}
#define LSRD_LiveStreamRawDataHelperCategorySetter(methodName,instance)\
- (void)methodName:(LiveStreamRawDataHelper *)instance { \
    objc_setAssociatedObject(self, @selector(instance), instance, OBJC_ASSOCIATION_RETAIN_NONATOMIC); \
}

#else

#define LSRD_LiveStreamRawDataHelperLazyLoad(methodName,instance)
#define LSRD_LiveStreamRawDataHelperDeclare(instance)
#define LSRD_LiveStreamRawDataHelperCategoryLazyLoad(instance)
#define LSRD_LiveStreamRawDataHelperCategorySetter(methodName,instance)

#endif

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LSRawDataSourceType) {
    LSRawDataSourceTypeOrigin    = 0, 
    LSRawDataSourceTypeH264,          
    LSRawDataSourceTypeEffectedH264,  
    LSRawDataSourceTypeEncoded,       
    LSRawDataSourceTypeUnknown,
};

typedef void (^LSRawDataRecordCompletionHandler)(NSError *error,LSRawDataSourceType type,NSURL *url);

@interface LiveStreamRawDataHelper : NSObject
@property (nonatomic, readonly) BOOL dumpIsFinished;

- (BOOL)processVideoPixelbuf:(CVPixelBufferRef)pixelbuf sourceType:(LSRawDataSourceType) type;

- (BOOL)processVideoPixelbuf:(CVPixelBufferRef)pixelbuf presentationTime:(CMTime) frameTime sourceType:(LSRawDataSourceType) type;


- (void)startRawRecordingWithFileName:(NSString *)fileName
              maxProcessVideoBufCount:(NSInteger)maxProcessVideoBufCount
                    CompletionHandler:(nullable LSRawDataRecordCompletionHandler)completionHandler;

- (void)startRawRecordingWithFileName:(NSString *)fileName
              maxProcessVideoBufCount:(NSInteger)maxProcessVideoBufCount
                           isAssemble:(BOOL)isAssemble
                    CompletionHandler:(nullable LSRawDataRecordCompletionHandler)completionHandler;

- (void)setUserData:(NSDictionary *)user_data type:(LSRawDataSourceType)type;
- (void)videoResetRecording;

- (void)startAudioRawRecordingWithFileName:(NSString *)fileName audioFormat:(nullable NSString *)audioFormat;
- (void)startAudioRawRecordingWithFileName:(NSString *)fileName audioFormat:(nullable NSString *)audioFormat audioLimitSize:(int)audioLimitSize;

- (void)audioResetRecording;

- (int)processPCMData:(void *)pcmData length:(int)length;

@end

NS_ASSUME_NONNULL_END
