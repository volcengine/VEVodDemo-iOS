//
//  BDWebImageURLFilter.h
//  BDWebImage
//
//  Created by 刘诗彬 on 2017/11/28.
//

#import <Foundation/Foundation.h>

@interface BDWebImageURLFilter : NSObject

- (NSString *)identifierWithURL:(NSURL *)url;

@end
