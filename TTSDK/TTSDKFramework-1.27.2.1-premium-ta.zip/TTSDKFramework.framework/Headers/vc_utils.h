//  Created by 黄清 on 2020/5/22.
//

#ifndef Utils_hpp
#define Utils_hpp
#pragma once

#include "vc_base.h"
#include <string>

VC_NAMESPACE_BEGIN

class VCMethodConsume {
public:
    explicit VCMethodConsume(const std::string &des);
    ~VCMethodConsume();

private:
    static uint64_t Serial_num;

private:
    std::string mDes;
    uint64_t mMSTime{0};
    uint64_t mSerialNum{0};

private:
    VC_DISALLOW_COPY_ASSIGN_AND_MOVE(VCMethodConsume);
};

#ifndef __METHOD_CONSUME__
#define __METHOD_CONSUME__

#define DEBUG_TIMING 0
#if DEBUG || DEBUG_TIMING
#define METHOD_CONSUME(des) \
    __attribute__((__unused__)) VCMethodConsume unUseInstace(des)
#else
#define METHOD_CONSUME(des)
#endif
#endif

VC_NAMESPACE_END

VC_NAMESPACE_BEGIN

namespace Utils {
/*
std::vector<std::string> split(const std::string &str,
                               const std::string &delim);
std::int64_t getCurrentTimestamp(void);
*/
std::string mapToString(const StringValueMap &map);
StringValueMap stringToMap(const std::string &str);
std::string longValueMapToString(const LongValueMap &map);
/*
LongValueMap stringToLongValueMap(const std::string &str);
*/

#if defined(__ANDROID__)
bool attachEnv(void);
void detachEnv(void);
#endif

std::string BuildPlayerID(const std::string &sceneId,
                          const std::string &mediaId);
} // namespace Utils

VC_NAMESPACE_END

#endif /* Utils_hpp */
