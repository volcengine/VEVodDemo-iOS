//
//  BDImageDecoderHeic.h
//  BDWebImage
//
//  Created by 刘诗彬 on 2017/11/30.
//

#import "BDImageDecoder.h"

@interface BDImageDecoderHeic : NSObject<BDImageDecoder, BDThumbImageDecoder>

@end
