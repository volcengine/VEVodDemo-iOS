#pragma once
#ifndef PRELOAD_VC_JSON_H
#define PRELOAD_VC_JSON_H

#include "json.h"
#include "vc_base.h"

VC_NAMESPACE_BEGIN

class VCJson {
    template <typename Iterator>
    class IteratorImpl;

public:
    enum class ValueType : int8_t
    {
        Invalid = -1,
        Null,
        Object,
        Array,
        String,
        Bool,
        IntegerNumber,
        UnsignedNumber,
        RealNumber,
    };

    /// Member types

    using size_type = size_t;
    using reference = VCJson &;
    using const_reference = const VCJson &;
    using iterator = IteratorImpl<Json::ValueIterator>;
    using const_iterator = IteratorImpl<Json::ValueConstIterator>;

    /// Constructors

    VCJson(ValueType type);
    VCJson(std::nullptr_t = nullptr);
    /*
    VCJson(VCStrCRef str);
    VCJson(bool b);
    VCJson(int64_t i);
    VCJson(uint64_t u);
    VCJson(double d);
    */

    template <typename CompatibleType,
              typename = typename std::enable_if<
                      std::is_constructible<Json::Value,
                                            CompatibleType>::value>::type>
    VCJson(CompatibleType v) :
            mValue(new Json::Value(v)),
            mType(TypeConvert(mValue->type())),
            mNeedDelete(true) {}

    VCJson(const VCJson &other);
    VCJson(VCJson &&other) noexcept;

    /// Destructors

    ~VCJson();

    /// Assignments

    VCJson &operator=(const VCJson &other);
    // VCJson &operator=(VCJson &&other) = delete;

    /// Iterators

    iterator begin();
    const_iterator begin() const;
    const_iterator cbegin() const;
    iterator end();
    const_iterator end() const;
    const_iterator cend() const;
    /*
    iterator rbegin();
    const_iterator rbegin() const;
    const_iterator crbegin() const;
    iterator rend();
    const_iterator rend() const;
    const_iterator crend() const;
    */

    /// Capacity

    bool empty() const;
    size_type size() const;

    /// Observers

    ValueType type() const;
    VCString typeName() const;
    bool isNull() const;
    bool isObject() const;
    bool isArray() const;
    bool isString() const;
    bool isBool() const;
    bool isNumber() const;
    bool isIntegerNumber() const;
    bool isUnsignedNumber() const;
    bool isRealNumber() const;
    bool isInvalid() const;

    template <ValueType type>
    bool is() const;

    /// Lookup

    /*
    iterator find(VCStrCRef key);
    const_iterator find(VCStrCRef key) const;
    */
    bool contains(VCStrCRef key) const;

    /// Element access

    /*
    reference at(VCStrCRef key);
    const_reference at(VCStrCRef key) const;
    */
    VCJson operator[](VCStrCRef key);
    VCJson operator[](VCStrCRef key) const;
    VCJson operator[](size_type idx);
    VCJson operator[](size_type idx) const;

    template <typename T>
    T value(VCStrCRef key, const T &defaultValue) const {
        Json::Value res = mValue->get(key, defaultValue);
        if (JsonIsHelper<T>(res))
            return JsonAsHelper<T>(res);
        return defaultValue;
    }

    // template <typename T>
    // T get() const;

    template <typename T>
    bool getTo(T &v) const {
        if (!JsonIsHelper<T>(*mValue))
            return false;
        v = JsonAsHelper<T>(*mValue);
        return true;
    }

    // template <typename T>
    // operator T() const;

    /// Serialization/deserialization

    VCString dump(bool humanReadable = false) const;

    /**
     * Deserialize from a compatible input.
     * @tparam InputType A compatible input
     * @param input input to read from
     * @return deserialized JSON value; in case of a parse error, the return
     * value will be @c ValueType::Invalid.
     */
    template <typename InputType>
    static VCJson parse(InputType &&input) {
        return parse<VCStrCRef>(VCString(std::forward<InputType>(input)));
    }

    template <typename InputIt>
    static VCJson parse(InputIt first, InputIt last) {
        return parse(VCString(first, last));
    }

private:
    Json::Value *mValue;
    ValueType mType;
    bool mNeedDelete;

    static ValueType TypeConvert(Json::ValueType type);
    static Json::ValueType TypeConvert(ValueType type);

    VCJson(Json::Value *jsonPtr, bool needDelete);

    /**
     * Specialized templates for Json::Value::isT()
     * @tparam T target type
     */
    template <typename T>
    static bool JsonIsHelper(const Json::Value &value) = delete;
    /**
     * Specialized templates for Json::Value::asT()
     * Caution: check type before convert
     * @tparam T target type
     * @return converted value
     */
    template <typename T>
    static T JsonAsHelper(const Json::Value &value) = delete;
};

template <>
VCJson VCJson::value(VCStrCRef key, const VCJson &defaultValue) const;

template <>
VCJson VCJson::parse(VCStrCRef input);

template <>
inline bool VCJson::JsonIsHelper<bool>(const Json::Value &value) {
    return value.isBool();
}
template <>
inline bool VCJson::JsonIsHelper<Json::Int>(const Json::Value &value) {
    return value.isInt();
}
template <>
inline bool VCJson::JsonIsHelper<Json::UInt>(const Json::Value &value) {
    return value.isUInt();
}
template <>
inline bool VCJson::JsonIsHelper<Json::Int64>(const Json::Value &value) {
    return value.isInt64();
}
template <>
inline bool VCJson::JsonIsHelper<Json::UInt64>(const Json::Value &value) {
    return value.isUInt64();
}
template <>
inline bool VCJson::JsonIsHelper<double>(const Json::Value &value) {
    return value.isDouble();
}
template <>
inline bool VCJson::JsonIsHelper<JSONCPP_STRING>(const Json::Value &value) {
    return value.isString();
}

template <>
inline bool VCJson::JsonAsHelper<bool>(const Json::Value &value) {
    return value.asBool();
}
template <>
inline Json::Int VCJson::JsonAsHelper<Json::Int>(const Json::Value &value) {
    return value.asInt();
}
template <>
inline Json::UInt VCJson::JsonAsHelper<Json::UInt>(const Json::Value &value) {
    return value.asUInt();
}
template <>
inline Json::Int64 VCJson::JsonAsHelper<Json::Int64>(const Json::Value &value) {
    return value.asInt64();
}
template <>
inline Json::UInt64
VCJson::JsonAsHelper<Json::UInt64>(const Json::Value &value) {
    return value.asUInt64();
}
template <>
inline double VCJson::JsonAsHelper<double>(const Json::Value &value) {
    return value.asDouble();
}
template <>
inline JSONCPP_STRING
VCJson::JsonAsHelper<JSONCPP_STRING>(const Json::Value &value) {
    return value.asString();
}
template <>
inline float VCJson::JsonAsHelper<float>(const Json::Value &value) {
    return value.asFloat();
}
template <>
inline const char *
VCJson::JsonAsHelper<const char *>(const Json::Value &value) {
    return value.asCString();
}

template <typename Iterator>
class VCJson::IteratorImpl {
    static_assert(
            std::is_same<Iterator, Json::ValueIterator>::value ||
                    std::is_same<Iterator, Json::ValueConstIterator>::value,
            "For internal use only");
    friend class VCJson;

private:
    IteratorImpl(const Iterator &iter) : mIter(iter) {}
    Iterator mIter;

public:
    using difference_type = ptrdiff_t;
    using value_type = typename std::conditional<
            std::is_same<Iterator, Json::ValueConstIterator>::value,
            const VCJson,
            VCJson>::type;
    using pointer = std::shared_ptr<value_type>;
    using reference = value_type;
    using iterator_category = std::bidirectional_iterator_tag;

    VCJson operator*() const;
    std::shared_ptr<value_type> operator->() const;

    template <typename U>
    IteratorImpl &operator=(const IteratorImpl<U> &other) {
        mIter = other.mIter;
        return *this;
    }

    template <typename U>
    bool operator!=(const IteratorImpl<U> &other) const {
        return mIter != other.mIter;
    }

    template <typename U>
    bool operator==(const IteratorImpl<U> &other) const {
        return mIter == other.mIter;
    }

    template <typename U>
    difference_type operator-(const IteratorImpl<U> other) const {
        return mIter - other.mIter;
    }

    IteratorImpl &operator++() {
        ++mIter;
        return *this;
    }

    IteratorImpl operator++(int) {
        auto ret(*this);
        operator++();
        return ret;
    }

    IteratorImpl &operator--() {
        --mIter;
        return *this;
    }

    IteratorImpl operator--(int) {
        auto ret(*this);
        operator--();
        return ret;
    }
};

VC_NAMESPACE_END

#endif // PRELOAD_VC_JSON_H
