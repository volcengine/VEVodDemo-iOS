//
//  TTVideoEngineUrlSource.h
//  TTVideoEngine
//
//  Created by wangzhiyong on 2021/9/10.
//

#import <Foundation/Foundation.h>
#import "TTVideoEngineMediaSource.h"

NS_ASSUME_NONNULL_BEGIN

@interface TTVideoEngineUrlSource : NSObject <TTVideoEngineMediaSource>

/// play url
@property (nonatomic, copy) NSString *url;

/// media data loader cache video unique identification key, recommended  you can use unique url md5 string
@property (nonatomic, copy) NSString *cacheKey;

/// encode type of this resource
@property (nonatomic, assign) TTVideoEngineEncodeType encodeType;

/// video id
@property (nonatomic, copy) NSString *vid;

/// is hdr, default no
@property (nonatomic, assign) BOOL isHDRSource;

/// custom decryption key
@property (nonatomic, strong) NSString *decryptionKey;

/// custom defined cache file path.
@property (nonatomic, copy, nullable) NSString *filePath;

- (instancetype)init UNAVAILABLE_ATTRIBUTE;
+ (instancetype)new UNAVAILABLE_ATTRIBUTE;


/// Designated initializer.
/// @param url The encode type of current asset, make sure it is correct.
/// @param cacheKey MDL cache key. Alternative with filePath
- (instancetype)initWithUrl:(NSString *)url
                   cacheKey:(NSString *)cacheKey
                    videoId:(NSString *)vid;

/// Designated initializer.
/// @param url The encode type of current asset, make sure it is correct.
/// @param cacheKey MDL cache key. Alternative with filePath
/// @param isHDRSource is hdr source
- (instancetype)initWithUrl:(NSString *)url
                   cacheKey:(NSString *)cacheKey
                    videoId:(NSString *)vid
                isHDRSource:(BOOL)isHDRSource;

/// Designated initializer.
/// @param url The encode type of current asset, make sure it is correct.
/// @param cacheKey MDL cache key. Alternative with filePath
/// @param encodeType The encode type of current asset, make sure it is correct.
/// @param decryptionKey auth key for encrypted video.
/// @param filePath Cache file path. Alternative with cacheKey
- (instancetype)initWithUrl:(NSString *)url
                   cacheKey:(NSString *)cacheKey
                    videoId:(NSString *)vid
                 encodeType:(TTVideoEngineEncodeType)encodeType
              decryptionKey:(NSString * _Nullable)decryptionKey
                   filePath:(NSString * _Nullable)filePath;

/// Designated initializer.
/// @param url The encode type of current asset, make sure it is correct.
/// @param cacheKey MDL cache key. Alternative with filePath
/// @param encodeType The encode type of current asset, make sure it is correct.
/// @param decryptionKey auth key for encrypted video.
/// @param filePath Cache file path. Alternative with cacheKey
/// @param isHDRSource is hdr source
- (instancetype)initWithUrl:(NSString *)url
                   cacheKey:(NSString *)cacheKey
                    videoId:(NSString *)vid
                 encodeType:(TTVideoEngineEncodeType)encodeType
              decryptionKey:(NSString * _Nullable)decryptionKey
                   filePath:(NSString * _Nullable)filePath
                isHDRSource:(BOOL)isHDRSource;

@end

NS_ASSUME_NONNULL_END
