//  Copyright © 2018 tangzhixin. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <AVFoundation/AVFoundation.h>
#import "LiveStreamConfiguration.h"
#import "LiveAudioConfiguration.h"
#import "LiveStreamDefines.h"
#import "LiveStreamLinkInfo.h"
#import "LiveStreamMediaSource.h"

@class LiveStreamSession;
@protocol LiveStreamSessionProtocol;
@class LiveStreamLinkInfo;
@class LiveStreamCapture;


@interface LiveStreamSession : NSObject

@property (nonatomic, weak) id<LiveStreamSessionProtocol> delegate;

@property (nonatomic, readonly) LiveStreamSessionState liveSessionState;

@property (nonatomic, assign, getter=isAudioMute) BOOL audioMute;

@property (nonatomic, readonly) LiveStreamConfiguration *configuration;

#pragma mark - Report Log
@property (nonatomic, assign) NSInteger streamLogTimeInterval;

@property (nonatomic, copy) void(^streamLogCallback)(NSDictionary *log);

#pragma mark - Reconnect
@property (nonatomic, assign) BOOL shouldAutoReconnect;

@property (nonatomic, assign) NSInteger reconnectCount DEPRECATED_MSG_ATTRIBUTE("Use -maxReconnectCount instead");;

@property (nonatomic, assign) NSInteger maxReconnectCount;

@property (nonatomic, assign) NSInteger reconnectTimeInterval;

#pragma mark - Track
@property (nonatomic, assign) NSInteger mainVideoTrackId;

@property (nonatomic, assign) NSInteger mainAudioTrackId;

+ (NSString *)getSdkVersion;

@property (nonatomic, copy) void(^didCapturedAudioBufferList)(void *mData, UInt32 inNumberFrames, void *processedData, void *headphonesMonitoringData);
@property (nonatomic, copy) void(^didCapturedAudioBufferList_withBGMPlayer)(void *ioData, UInt32 mDataSize, UInt32 inNumberFrames, void *processedData, void *headphonesMonitoringData);
- (void)setGetAudioCallback:(void (^)(void * _Nonnull buffer, int bufferSize, int frames, int bytesPerSample, int channels, int sampleRate))getAudioCallback;

- (instancetype)initWithConfig:(LiveStreamConfiguration *)config;

- (void)pushRestartUpdateParams;

- (void)start;

- (void)startStreamWithURL:(NSString *)rtmpURL;

- (void)stop;

- (int)sendSEIMsgWithKey:(NSString *)key
                   value:(NSObject *)value
             repeatTimes:(NSInteger)repeatTimes
            keyFrameOnly:(BOOL)keyFrameOnly
           allowsCovered:(BOOL)allowsCovered
                 timeGap:(int)timeGap;


- (int)sendSEIMsgWithKey:(NSString *)key
                   value:(NSObject *)value
             repeatTimes:(NSInteger)repeatTimes;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
              andCMTime:(CMTime)pts;

- (void)pushVideoBuffer:(CVPixelBufferRef)pixelBufferRef
                texture:(int32_t)textureId
              andCMTime:(CMTime)pts;


- (void)pushVideoDataWithTrackId:(NSUInteger)tid
                       timestamp:(int64_t)timestamp_ns
                         yBuffer:(void *)yBuffer yStride:(int)yStride
                         uBuffer:(void *)uBuffer uStride:(int)uStride
                         vBuffer:(void *)vBuffer vStride:(int)vStride
                           width:(int)width
                          height:(int)height
                        rotation:(int)rotation;

- (void)pushVideoBuffer:(CVPixelBufferRef)buffer
                texture:(int32_t)textureId
              andCMTime:(CMTime)pts
                trackId:(NSUInteger)tid;

- (void)flushLastImageBufferWithTime:(CMTime)pts;

- (void)pushAudioBuffer:(uint8_t *)data
      andInNumberFrames:(int)inNumberFrames
      andBytesPerSample:(int)bytesPerSample
    andNumberOfChannels:(int)audioChannelCount
          andSampleRate:(int)sampleRate
         andTimestampUs:(int64_t)timestamp_us;

- (void)pushAudioBuffer:(uint8_t *)data
             andDataLen:(size_t)size
      andInNumberFrames:(int)inNumberFrames
              andCMTime:(CMTime)pts;


- (void)pushAudioBuffer:(uint8_t *)data
             andDataLen:(size_t)size
      andInNumberFrames:(int)inNumberFrames
              timestamp:(int64_t)pts_us
                trackId:(int)trackId;

- (void)pushAudioBuffer:(uint8_t *)data
         andDataLen:(size_t)size
         sampelRate:(int)sampelRate
           channels:(int)channels
  andBytesPerSample:(int)bytesPerSample
          timestamp:(int64_t)pts
                trackId:(int)tid;

- (void)pushEncodedData:(uint8_t *)data size:(int)size timestamp:(int64_t)timestamp_us dts:(int64_t)dts videoFrameType:(int)videoFrameType;
@property (nonatomic, copy) void(^updateEncodeBitrateCallback)(int bitrate);

- (void)setSeiCurrentShiftDiffTime:(int64_t)timeMs;

- (EAGLContext *)getEAGLContext;

#pragma - mark DNSNodeSort
@property (nonatomic, copy) NSDictionary *(^shouldUpdateOptimumIPAddress)(NSString *host);

#pragma - Status
- (BOOL)isRunning;

- (id)getStreamInfoForKey:(NSString *)name;

- (NSDictionary *)getStatistics;

#pragma mark - StreamMixer
@property (nonatomic, assign) BOOL enableAudioMixing;
@property (nonatomic, assign) BOOL enableVideoMixing;

- (void)addAudioSource:(LiveStreamLinkInfo *)linkInfo;

- (void)addVideoSource:(LiveStreamLinkInfo *)linkInfo;

- (void)setMixerOutputSize:(CGSize)size;

- (void)removeVideoSource:(NSString *)uid;

- (LSStreamMediaSource *)getSourceWithUID:(NSString *)uid streamType:(int)type;

- (LSStreamAudioSource *)getOriginAudioSource;
- (void)updateLinkInfo:(LSStreamMediaSource *)source;

- (void)updateTransportParamter:(NSString *)key value:(NSNumber *)value;

- (void)updateTransportParams:(NSDictionary *_Nullable)parmas;

- (void)requestIDRFrame;

- (void)updateAudioDeviceWithCapture:(LiveStreamCapture *_Nonnull)capture;

- (AudioSource *)streamAudioSource;
@end

@protocol LiveStreamSessionProtocol <NSObject>

@required
- (void)streamSession:(LiveStreamSession *_Nonnull)session onStatusChanged:(LiveStreamSessionState)state;

- (void)streamSession:(LiveStreamSession *_Nonnull)session onError:(LiveStreamErrorCode)error;

@end

@protocol LiveStreamSessionAudioProtocol <NSObject>

- (void)streamSession:(LiveStreamSession *_Nonnull)session
        pullAudioData:(void *_Nonnull)ioData
       earMonitorData:(void *_Nullable)earMonitingData
                 size:(UInt32)mDataSize
      mNumberChannels:(int)mNumberChannels
       numberOfFrames:(int)inNumberFrames
              admType:(LSAdmType)admType;

- (void)streamSession:(LiveStreamSession *_Nonnull)session
  pushPlayerAudioData:(AudioBufferList *)ioData
               frames:(int)frames
       bytesPerSample:(int)bytesPerSample
             channels:(int)channels
           sampleRate:(int)sampleRate;

@end

@interface LiveStreamSession (Audio)

- (void)setupAudioCaptureWithConfig:(LiveAudioConfiguration *_Nullable)config;

- (void)startAudioCapture;

- (void)stopAudioCapture;

- (void)startFakeAudioCapture;

- (void)stopFakeAudioCapture;

- (void)audioCaptureInterrupted:(BOOL)bInterrupt;

- (void)audioPlayerInterrupted:(BOOL)bInterrupt;

#pragma mark - set
- (void)setEnableAudioCaptureInBackground:(BOOL)enable;

- (void)setEnableSpeaker:(BOOL)enable;

- (void)setEnableNoiseSuppression:(BOOL)enable param:(float)param;

- (void)setEnableAudioLoudNorm:(BOOL)enable param:(float)param;

- (void)setHeadphonesMonitoringEnabled:(BOOL)headphonesMonitoringEnabled;

- (void)setEchoCancellationEnabled:(BOOL)echoCancellationEnabled;

- (void)setEnablePlayer:(BOOL)enable;

- (void)setEnableAudioLowLatency:(BOOL)enable ioBufferDuration:(float)ioBufferDuration;

#pragma mark - get
- (BOOL)isMicRunning;

- (BOOL)isFakeAudioCaptureRunning;

- (BOOL)isHeadphonesMonitoringEnabled;

- (BOOL)isEchoCancellationEnabled;

- (BOOL)isRouteToSpeaker;

- (AudioStreamBasicDescription)audioStreamBasicDescription;

@end

@interface LiveStreamSession (Debug)
- (void)setLogLevel:(LiveStreamLogLevel)level;

- (void)setOnlyRTMPKMode:(BOOL)enable;

@end
