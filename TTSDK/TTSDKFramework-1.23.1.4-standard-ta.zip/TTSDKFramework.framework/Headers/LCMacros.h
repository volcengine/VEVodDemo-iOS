
#ifndef LCMacros_h
#define LCMacros_h

#define kDefaultResolution CGSizeMake(368, 640)
#define kDefaultDarkFrameResolution CGSizeMake(64, 64)
#define kDefaultDarkFrameRate 15
#define kDefaultDarkFrameBitrate 20
#define kDefaultAudioBufferSize 1764 
#define kDefaultAudioChannel 2
#define LC_API_EVENT_KEY @"LiveCoreAPI"
#define LC_DEVICE_STATUS_EVENT_KEY @"LiveCoreDeviceStatus"
#define LC_APP_STATUS_EVENT_KEY @"LiveCoreApplicationStatus"


#endif 
