//  Copyright © 2018 wangkecheng. All rights reserved.

#pragma - mark LiveStreamInfoKeys
static NSString *const LiveStreamInfo_SDKVersion = @"sdk_version";
static NSString *const LiveStreamInfo_StreamType = @"push_type";
static NSString *const LiveStreamInfo_StreamDuration = @"duration";
static NSString *const LiveStreamInfo_PublishURL = @"url";
static NSString *const LiveStreamInfo_RemoteIpAddress = @"cdn_ip";
static NSString *const LiveStreamInfo_LocalIpAddress = @"local_ip";
static NSString *const LiveStreamInfo_DnsIpAddressList = @"dns_ip_list";
static NSString *const LiveStreamInfo_ProjectKey = @"project_key";

static NSString *const LiveStreamInfo_VideoCodec = @"video_codec";
static NSString *const LiveStreamInfo_AudioCodec = @"audio_codec";

static NSString *const LiveStreamInfo_VideoBitrate = @"meta_video_bitrate";
static NSString *const LiveStreamInfo_MinVideoBitrate = @"meta_min_video_bitrate";
static NSString *const LiveStreamInfo_MaxVideoBitrate = @"meta_max_video_bitrate";
static NSString *const LiveStreamInfo_CurrentVideoBitrate = @"current_video_bitrate";
static NSString *const LiveStreamInfo_RealEncodeBitrate = @"encode_bitrate";

static NSString *const LiveStreamInfo_AudioBitrate = @"meta_audio_bitrate";
static NSString *const LiveStreamInfo_RealTransportBitrate = @"real_bitrate";

static NSString *const LiveStreamInfo_VideoFPS = @"meta_video_framerate";
static NSString *const LiveStreamInfo_PreviewFPS = @"preview_fps";
static NSString *const LiveStreamInfo_EncodeFPS = @"encode_fps";
static NSString *const LiveStreamInfo_RealFPS = @"real_video_framerate";

static NSString *const LiveStreamInfo_VideoSize = @"video_size";
static NSString *const LiveStreamInfo_AudioChannelCount = @"audio_channel";
static NSString *const LiveStreamInfo_AudioSampleRate = @"audio_sample_rate";

static NSString *const LiveStreamInfo_PSNRStatisticsFrames = @"psnr_statistic_frames";
static NSString *const LiveStreamInfo_PSNRStatisticsPeriodSeconds = @"psnr_statistic_period_seconds";
static NSString *const LiveStreamInfo_PSNREnable = @"estream_psnr_enable";

#define LS_EXPORT extern __attribute__((visibility("default")))

#if defined(__cplusplus)
#define LS_EXTERN "C" LS_EXPORT
#else
#define LS_EXTERN LS_EXPORT
#endif

#pragma -
typedef NS_ENUM(NSInteger, LiveStreamSessionState)
{
    LiveStreamSessionStateNone,
    LiveStreamSessionStateStarting,
    LiveStreamSessionStateStarted,
    LiveStreamSessionStateReconnecting,
    LiveStreamSessionStateEnded,
    LiveStreamSessionStateError,
    LiveStreamSessionStateUrlerr,
};

typedef NS_ENUM(NSInteger, LiveStreamErrorCode)
{
    LiveStreamErrorCode_UNKNOWN                    = -10000,
    LiveStreamErrorCode_RTMP_ConfiguraitonError    = -10001,
    LiveStreamErrorCode_RTMP_CONNECT_FAILED        = -10002,
    LiveStreamErrorCode_INTERLEAVE_ERROR           = -10003,
    LiveStreamErrorCode_AVSYNC_ERROR               = -10004,
    LiveStreamErrorCode_RTMP_SEND_PACKET_FAIL      = -10005,
    
    LiveStreamErrorCode_REQUEST_STREAM_INFO_ERROR  = -10210,  
    LiveStreamErrorCode_NEED_UPDATE_STREAM_INFO    = -10211,  
};

typedef NS_ENUM(NSUInteger, LiveStreamRotateMode) {
    LSRotateModeNoRotation,
    LSRotateModeRotateLeft,
    LSRotateModeRotateRight,
    LSRotateModeFlipVertical,
    LSRotateModeFlipHorizonal,
    LSRotateModeRotateRightFlipVertical,
    LSRotateModeRotateRightFlipHorizontal,
    LSRotateModeRotate180
};

typedef NS_ENUM(NSUInteger, LiveStreamLogLevel) {
    LiveStreamLogLevelVerbose = 2,
    LiveStreamLogLevelDebug = 3,
    LiveStreamLogLevelInfo = 4,
    LiveStreamLogLevelWarning = 5,
    LiveStreamLogLevelError = 6,
};

typedef NS_ENUM(NSUInteger, LSRenderMode) {
    LSRenderModeScaleToFill     = 0,
    LSRenderModeScaleAspectFit  = 1,
    LSRenderModeScaleAspectFill = 2
};

typedef NS_ENUM(NSUInteger, LSAdmType) {
    LSAdmTypeNormal,
    LSAdmTypeByteAudio,
};

static NSString *const LSStreamingParameterKeyFrameRate = @"ls_streaming_key_fps";    
