
#ifndef LSMacros_h
#define LSMacros_h

#define Cloud_Render_Enable 1
#ifndef liveStream_keywordify
#if DEBUG
    #define liveStream_keywordify autoreleasepool {}
#else
    #define liveStream_keywordify try {} @catch (...) {}
#endif
#endif

#ifndef ls_weakify
    #if __has_feature(objc_arc)
        #define ls_weakify(object) liveStream_keywordify __weak __typeof__(object) weak##_##object = object;
    #else
        #define ls_weakify(object) liveStream_keywordify __block __typeof__(object) block##_##object = object;
    #endif
#endif

#ifndef ls_strongify
    #if __has_feature(objc_arc)
        #define ls_strongify(object) liveStream_keywordify __typeof__(object) object = weak##_##object;
    #else
        #define ls_strongify(object) liveStream_keywordify __typeof__(object) object = block##_##object;
    #endif
#endif

#define float_equal(a, b) fabs((a) - (b)) < DBL_EPSILON

#define BYTEAUDIO_LOG_EVENT_KEY @"baeEvent"

#endif 
