//
//  TTVideoEngineMediaSource.h
//  TTVideoEngine
//
//  Created by wangzhiyong on 2021/11/18.
//

#import <Foundation/Foundation.h>
#import "TTVideoEngineModelDef.h"
#import "TTVideoEnginePlayerDefine.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, TTVideoEngineSourceType) {
    TTVideoEngineSourceTypeVideoId   = 0,
    TTVideoEngineSourceTypeDirectUrl = 1,
    TTVideoEngineSourceTypeCodeStrategyUrl = 2,
};

@protocol TTVideoEngineMediaSource <NSObject>

@property (nonatomic, readonly, strong, getter=getUniqueId) NSString *uniqueId;

@property (nonatomic, assign) TTVideoEngineSourceType sourceType;

@end


NS_ASSUME_NONNULL_END
