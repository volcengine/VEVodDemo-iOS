//
//  TVLPlayerItem+TTSDK.h
//  TTSDK
//
//  Created by guojieyuan on 2021/9/1.
//

#import "TVLPlayerItem.h"

NS_ASSUME_NONNULL_BEGIN

@class TTLiveURLComposer;

@interface TVLPlayerItem (TTSDK)

/**
 Use TTLiveURLComposer to Create A TVLPlayerItem
 
 @param composer with final TTLiveURLComposer instance.
 */
+ (instancetype)playerItemWithComposer:(TTLiveURLComposer *)composer;

@end

NS_ASSUME_NONNULL_END
