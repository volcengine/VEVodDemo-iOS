//
//  BDImageDecoderAVIF.h
//  BDALog
//
//  Created by bytedance on 12/28/20.
//

#import "BDImageDecoder.h"

NS_ASSUME_NONNULL_BEGIN

@interface BDImageDecoderAVIF : NSObject<BDImageDecoder>

@end

NS_ASSUME_NONNULL_END
