//
// Created by 黄清 on 4/20/21.
//

#ifndef PRELOAD_VC_EXECUTOR_H
#define PRELOAD_VC_EXECUTOR_H
#pragma once

#include "AVMDLIOManager.h"
#include "av_player_interface.h"
#include "vc_base.h"
#include "vc_iexecutor.h"
#include "vc_imodule.h"

VC_NAMESPACE_BEGIN

/// MARK: - VCExecutor
class MessageTaskRunner;
class VCStrategyResult;
class VCExecutor final : public IVCExecutor {
public:
    VCExecutor();
    ~VCExecutor() override;

public:
    void start(void) override;
    void stop(void) override;

public:
    void onResult(const IVCResultListener *listener,
                  const std::shared_ptr<VCStrategyResult> &result) override;
    void setIOManager(AVMDLIOManager *ioManager) override;
    void setContext(IVCContext *context) override;
    void setIOTaskListener(AVMDLIOTaskListener *listener) override;

public:
    bool addExecutor(IVCExecutor *executor);
    /// type is single value.
    IVCExecutor *getExecutor(VCModuleType type);

private:
    std::list<IVCExecutor *> mExecutors;
};

VC_NAMESPACE_END

#endif // PRELOAD_VC_EXECUTOR_H
