#ifndef BYTE_AUDIO_ENGINE_TYPES_H
#define BYTE_AUDIO_ENGINE_TYPES_H

#import <AVFoundation/AVFoundation.h>

#define BYTEAUDIO_API __attribute__((__visibility__("default")))

typedef NS_ENUM(NSInteger, ByteAudioErrorCode) {
    // success
    ByteAudioErrorCodeSuccess = 0,
    // general failure
    ByteAudioErrorCodeFailure = -1,
    // failure of invalid param
    ByteAudioErrorCodeInvalidParam = -2,
    // failure of wrong state
    ByteAudioErrorCodeWrongState = -3,
    // failure of no frame
    ByteAudioErrorCodeNoFrame = -4,
    // failure of not implemented
    ByteAudioErrorCodeNotImplemented = -5,
    // don't have permission to use microphone.
    ByteAudioErrorCodeNoPermission = -6,
    // failure of resource unavailable
    ByteAudioErrorCodeResourceLimited = -7,
    // Set a device which has been plugged out.
    ByteAudioErrorCodeDeviceNotExists = -8,
    // failure of device not support format
    ByteAudioErrorCodeDeviceFormatNotSupport = -9,
    // general warning, some API return failure, but it doesn't affect function.
    ByteAudioErrorCodeWarning = -10,
    // No device in system
    ByteAudioErrorCodeDeviceNoDevice = -11,
    // Device can't be used.
    ByteAudioErrorCodeDeviceCannotUse = -12,
    // It meets system error when calling intializing device.
    ByteAudioErrorCodeDeviceInitFailed = -13,
    // It meets system error when starting intializing device.
    ByteAudioErrorCodeDeviceStartFailed = -14,
    // Find microphone in system, but it failes when try to start capture due to coreaudio's active
    // function.
    ByteAudioErrorCodeDeviceCoreAudioActiveError = -15,
    // Find device in system, but it failes when try to start due to coreaudio's initialization
    // function.
    ByteAudioErrorCodeDeviceCoreAudioInitError = -16,
    // Find device in system, but it failes when try to start open, intialize, get format due to
    // service error.
    ByteAudioErrorCodeDeviceCoreAudioServiceError = -17,
    // Some Apps, such as Cisco Teams, Cisco proximity tool, ZOOM,will use exculsive mode to capture
    // data from microphone.
    ByteAudioErrorCodeDeviceSessionDisconnectedByExclusiveMode = -18,
    // It meets system error when stopping device.
    ByteAudioErrorCodeDeviceStopFailed = -19,
    // It meets system error when creating volume mute object.
    ByteAudioErrorCodeDeviceCannotMute = -20,
    // It meets system error when creating volume  object.
    ByteAudioErrorCodeDeviceCannotAdjustVolume = -21,
    // Android device's playback mode isnot in communication mode.
    ByteAudioErrorCodeDeviceNotCommunicationMode = -22,
    // property changed in system, such as format, signal processing.
    ByteAudioErrorCodeDevicePropertyChanged = -23,
    // device is in background
    ByteAudioErrorCodeDeviceInBackGround = -24,
    // audio unit set property failed
    ByteAudioErrorCodeDeviceAudioUnitSetPropertyFailed = -25,
    // It opens device successfully, but it can't get system callbacks in run-time.
    ByteAudioErrorCodeDeviceNoCallback = -100,
    // System calls too fast.
    ByteAudioErrorCodeDeviceTooFast = -101,
    // System calls too slow.
    ByteAudioErrorCodeDeviceTooSlow = -102,
    // Acoustic echo is leaked
    ByteAudioErrorCodeDiagnoseLeakEcho = -200,
    // Audio captured data is clipped
    ByteAudioErrorCodeDiagnoseClipping = -201,
    // Audio captured data is too noisy
    ByteAudioErrorCodeDiagnoseLowSNR = -202,
    // Audio captured data is muted
    ByteAudioErrorCodeDiagnoseCaptureInsertSilence = -203,
    ByteAudioErrorCodeDiagnoseCaptureSilence = -204,
    ByteAudioErrorCodeDiagnoseCaptureSilenceDisappear = -205,
    // Acoustic howling is detected
    ByteAudioErrorCodeDiagnoseHowling = -206,
    // Audio captured data is messy
    ByteAudioErrorCodeDiagnoseMessySound = -207,
};

typedef NS_ENUM(NSInteger, ByteAudioRouting) {
    // default audio routing
    ByteAudioRoutingDefault = 0,
    // headset
    ByteAudioRoutingHeadset = 1,
    // earpiece
    ByteAudioRoutingEarpiece = 2,
    // speaker
    ByteAudioRoutingSpeakerPhone = 3,
    // headset bluetooth
    ByteAudioRoutingHeadsetBluetooth = 4,
};

#pragma mark - ByteAudioStreamOption
/**
 *  ByteAudioStreamOption
 * Used to create ByteAudioInputStream, ByteAudioOutputStream, ByteAudioMuxStream, and specify
 * stream parameters
 */
typedef NS_ENUM(NSInteger, ByteAudioOption) {
    // Enable mix with aux (for input stream).
    ByteAudioInputOptMixWithAux = 10001,
    // Enable mix with playout (for input stream).
    ByteAudioInputOptMixWithPlayout = 10002,
    // Enable mix with record (for input stream).
    ByteAudioInputOptMixWithRecord = 10003,
    // Enable mix with screen audio (for input stream).
    ByteAudioInputOptMixWithScreen = 10004,
    
    // Enable smart mix (for input stream).
    ByteAudioInputOptEnableSmartMix = 10005,
    // Enable loudnorm for VOIP voices when smart mix is enabled (for input stream).
    ByteAudioInputOptEnableLoudnorm = 10006,
    
    // Aux stream type (for aux stream).
    ByteAudioAuxOptStreamType = 20000,
    // Enable mix to input (for aux stream).
    ByteAudioAuxOptMix2Input = 20001,
    // Enable mix to output (for aux stream).
    ByteAudioAuxOptMix2Output = 20002,
    // Volume gain of mix to input (for aux stream).
    ByteAudioAuxOptMix2InputGain = 20003,
    // Volume gain of mix to output (for aux stream).
    ByteAudioAuxOptMix2OutputGain = 20004,
    // position of file aux
    ByteAudioAuxOptPosition = 20005,
    // duration of file aux
    ByteAudioAuxOptDuration = 20006,
    // Whether to mute of file aux (for aux stream).
    ByteAudioAuxOptMute = 20007,
    // loop time for file aux
    ByteAudioAuxOptLoopCount = 20008,
    // select audio track
    ByteAudioAuxOptAudioTrack = 20009,
    // Wether aux stream is preloaded
    ByteAudioAuxOptPreloaded = 20010,
    // Force switch to media mode when the aux stream is ready to playing out,
    ByteAudioAuxOptForceMediaMode = 20011,
    // loudness for each aux stream
    ByteAudioAuxOptIntegratedLoudness = 20012,
    // playout delay in ms of the aux stream.
    ByteAudioAuxOptPlayoutDelayMs = 20013,
    // publish delay in ms of the aux stream.
    ByteAudioAuxOptPublishDelayMs = 20014,
};

typedef NS_ENUM(NSInteger, ByteAudioCodecType) {
    // Invalid type
    ByteAudioCodecInvalid = 0,
    // PCM
    ByteAudioCodecPCM = 10000,
    // Opus
    ByteAudioCodecOpus = 10001,
    // G711A
    ByteAudioCodecG711A = 10002,
    // G711U
    ByteAudioCodecG711U = 10003,
    // AAC
    ByteAudioCodecAAC = 10004,
    // NICO audio codec
    ByteAudioCodecNICO = 10007,
};

typedef NS_ENUM(NSInteger, ByteAudioEventKey) {
    // notify route changed. code: new route. See @ByteAudioRouting; msg: change reason
    ByteAudioEventRouteChanged = 1000,
    // iOS interruption begin
    ByteAudioEventInterruptionBegin = 1001,
    // iOS interruption end
    ByteAudioEventInterruptionEnd = 1002,
    // iOS media server terminate
    ByteAudioEventMediaServerTerminate = 1003,
    // iOS media server reset
    ByteAudioEventMediaServerReset = 1004,
    // iOS switch to media mode when screen captured to avoid interrupt background screen capture
    ByteAudioEventScreenCaptureMediaMode = 1005,
    // device restart event
    ByteAudioEventDeviceRestart = 1006,
    // engine restart current record device three times, but the device still work badly, thus
    // report the fail
    ByteAudioEventRecordDeviceRestartFail = 1007,
    // engine restart current record device three times, but the device still work badly, thus
    // report the fail
    ByteAudioEventPlayoutDeviceRestartFail = 1008,

    // record start event. code: 0 success; other: error see @ByteAudioErrorCode
    ByteAudioEventRecordingStart = 1100,
    // record first frame callback. msg: time_since_start(milliseconds)
    ByteAudioEventRecordingFirstCallback = 1101,
    // record no frame error. msg: check_time_seconds, start time out(seconds)
    ByteAudioEventRecordingNoCallbackError = 1102,
    // record stop event. code: 0 success; other: error see @ByteAudioErrorCode
    ByteAudioEventRecordingStop = 1103,
    // record stream interrupt error.
    ByteAudioEventRecordingStreamError = 1104,
    // record frame silence notify.
    ByteAudioEventRecordingSilence = 1105,

    // playout start event. code: 0 success; other: error see @ByteAudioErrorCode
    ByteAudioEventPlayoutStart = 1200,
    // playout first frame callback. msg: time_since_start, start delay(milliseconds)
    ByteAudioEventPlayoutFirstCallback = 1201,
    // playout no frame error. msg: check_time_seconds, start time out(seconds)
    ByteAudioEventPlayoutNoCallbackError = 1202,
    // playout stop event. code: 0 success; other: error see @ByteAudioErrorCode
    ByteAudioEventPlayoutStop = 1203,
    // playout stream interrupt error.
    ByteAudioEventPlayoutStreamError = 1204,

    // frst audio frame recorded of input stream. code: the id of stream
    ByteAudioEventInputStreamFirstRecorded = 2000,
    // frst audio frame encoded of input stream. code: the id of stream
    ByteAudioEventInputStreamFirstEncoded = 2001,
    // audio frame encode failed of input stream. code: the id of stream
    ByteAudioEventInputStreamEncodeFailed = 2002,

    // first audio frame decoded of output stream. code: the id of stream
    ByteAudioEventOutputStreamFirstDecoded = 4000,

    /**
     * internal event key, only used for engine communicates with adm or nodes
     * which should be export to the caller ,e.g. RtcSDK, thus, sdk should not
     * parsing the following event key
     */
    // PC system default record device changed.
    ByteAudioEventRecordingSystemDefaultChanged = 5000,
    // PC communication default record device changed.
    ByteAudioEventRecordingCommDefaultChanged = 5101,
    // PC record device add.
    ByteAudioEventRecordingDeviceAdd = 5102,
    // PC record device remove.
    ByteAudioEventRecordingDeviceRemove = 5103,

    // PC system default playout device changed.
    ByteAudioEventPlayoutSystemDefaultChanged = 5104,
    // PC communication default playout device changed.
    ByteAudioEventPlayoutCommDefaultChanged = 5105,
    // PC playout device add.
    ByteAudioEventPlayoutDeviceAdd = 5106,
    // PC playout device remove.
    ByteAudioEventPlayoutDeviceRemove = 5107,

    // record device volume changed.
    ByteAudioEventRecordingDeviceVolumeChanged = 5110,
    // playout device volume changed.
    ByteAudioEventPlayoutDeviceVolumeChanged = 5111,
    // Audio session info on mobile.
    ByteAudioEventAudioSessionInfoUpdated = 5112,

    // Audio device related event report
    kByteAudioDeviceEventReport = 5200,

     // Audio dump
    kByteAudioDumpEventReport = 5202,
};

typedef NS_ENUM(NSInteger, ByteAudioScenarioType) {
    // music scenario, which is default.
    // use communication mode in speaker/receiver, media mode in others.
    // suitable in need of music performance such as live broatcasting or game.
    ByteAudioScenarioMusic = 0,
    // high-quality communication scenario.
    // use communication mode in speaker/receiver and bluetooth, media mode in others.
    // suitable in scenes of voice chat app with music.
    ByteAudioScenarioHighQualityCommunication = 1,
    // communication scenario.
    // use communication mode every time whenever.
    // suitable in scenes of switch mic frequently or video conference.
    ByteAudioScenarioCommunication = 2,
    // media scenario.
    // use media mode every time whenever.
    // suitable for special business needs and not recommended.
    ByteAudioScenarioMedia = 3,
    // game streaming scenario.
    // use media mode when speaker/receiver and wired headset.
    // use communication mode when bluetooth.
    ByteAudioScenarioGameStreaming = 4,
};

typedef NS_ENUM(NSInteger, ByteAudioDeviceType) {
    ByteAudioDeviceUnknown = -1,
    // render device
    ByteAudioRenderDevice = 0,
    // capture device
    ByteAudioCaptureDevice = 1,
    // sharing device, only valid for start_device/stop_device interface
    ByteAudioShareDevice = 2,
};

typedef NS_ENUM(NSInteger, ByteAudioDeviceStateType) {
    // The device is active.
    ByteAudioDeviceStateActive = 1,
    // The device is disabled.
    ByteAudioDeviceStateDisabled = 2,
    // The device is not present.
    ByteAudioDeviceStateNotPresent = 4,
    // The device is unplugged.
    ByteAudioDeviceStateUnplugged = 8
};

#pragma mark - ByteAudioStreamFormat
/**
 *  ByteAudioStreamFormat Specify audio data format
 */
BYTEAUDIO_API
@interface ByteAudioStreamFormat : NSObject
@property(nonatomic, assign) int sampleRate;
@property(nonatomic, assign) int channelNum;
@property(nonatomic, assign) int bitrateBps;
@property(nonatomic, assign) int frameSizeMs;
@property(nonatomic, assign) ByteAudioCodecType codecType;

- (int)getSampleRate;

- (int)getChannelNum;

- (ByteAudioCodecType)getCodecType;
@end

#pragma mark - ByteAudioStreamBuffer
/**
 *  ByteAudioStreamBuffer Specify ByteAudio external SDK data interaction structure
 */
BYTEAUDIO_API
@interface ByteAudioStreamBuffer : NSObject

@property(nonatomic, assign) int8_t* _Nullable data;
@property(nonatomic, assign) int length;
@property(nonatomic, assign) unsigned int timestamp;
@property(nonatomic, assign) ByteAudioStreamFormat* _Nonnull streamFormat;

- (void)initWithComponents:(int8_t* _Nullable)data
                    format:(ByteAudioStreamFormat* _Nonnull)streamFormat;

- (int)getLength;

- (unsigned int)getTimeStamp;

- (ByteAudioStreamFormat* _Nonnull)getStreamFormat;

@end

/**
 *  ByteAudioFilterDelegate Register into ByteAudioEngine for ByteAudio
 * SDK and external data exchange
 */
@protocol ByteAudioFilterDelegate <NSObject>

/**
 * ByteAudio SDK exchanges data with external audio processing
 *
 * @param stream Data buffer for data exchange
 *
 * @return @see ByteAudioErrorCode
 */
- (ByteAudioErrorCode)onProcess:(ByteAudioStreamBuffer* _Nonnull)stream;

@end

#endif  // BYTE_AUDIO_ENGINE_TYPES_H
