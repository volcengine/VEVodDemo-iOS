//  Copyright © 2018 wangkecheng. All rights reserved.

#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "LSMacros.h"
#import <CoreMedia/CoreMedia.h>

#define USE_FEEDBACK_LOOP 0

#define LS_SET_WEAK_ASSOCIATE(obj, target, key) do{\
    LSWeakProxy *proxy = [[LSWeakProxy alloc] init];\
    proxy.weakObject = obj;\
    objc_setAssociatedObject(target, key, proxy, OBJC_ASSOCIATION_RETAIN_NONATOMIC);\
} while(0);

#define LS_GET_WEAK_ASSOCIATE(target, key) \
[LSWeakProxy LS_GET_WEAK_ASSOCIATE:target withKey:key];

typedef NS_ENUM(NSInteger, LSApplicationStatus) {
    LSApplicationStatusBecomeActive,
    LSApplicationStatusForeground,
    LSApplicationStatusWillResignActive,
    LSApplicationStatusBackground,
};

typedef NS_ENUM(NSInteger, LSLinkEvent) {
    LSLinkEvent_pushLocalVideoBuffer,
    LSLinkEvent_pushLocalAudioBuffer,
};


@protocol LiveStreamAPPStatusProtocol <NSObject>

- (void)appStatusDidChanged:(LSApplicationStatus)status;

@end

@interface LSIHelper : NSObject
+ (void)swizzleForClass:(Class)cls oriSEL:(SEL)originalSelector newSEL:(SEL)swizzledSelector;

+ (void)swizzleForClass:(Class)cls oriSEL:(SEL)originalSelector fromClass:(Class)newClass newSEL:(SEL)swizzledSelector;

+ (instancetype)sharedInstance;

+ (void)registerAppStatusNofity:(id)handler withCallback:(void(^)(LSApplicationStatus status))block;

- (void)notifyListenerNewEvent:(LSLinkEvent)event value:(NSObject *)value;

+ (void)registerLinkEventNofity:(id)handler withCallback:(void(^)(LSLinkEvent event,NSObject *value))block;

@property (nonatomic, readonly) LSApplicationStatus appStatus;

+ (CVPixelBufferRef)generateCVPixelBufferWithFmt:(OSType)fmt
                                         yBuffer:(void *)yBuffer
                                         uBuffer:(void *)uBuffer
                                         vBuffer:(void *)vBuffer
                                         yStride:(int)yStride
                                         uStride:(int)uStride
                                         vStride:(int)vStride
                                           width:(int)width
                                          height:(int)height;

+ (CVPixelBufferRef)imageBufferFromImage:(UIImage *)image;

+ (BOOL)shouldDropLiveCoreCameraOutput;

+ (BOOL)closeCapture;
+ (BOOL)closePreview;
+ (BOOL)closeEffect;
+ (BOOL)closeEncode;
+ (BOOL)closePushStream;
+ (void)cleanTestStatus;

BOOL isCloseEncode();
BOOL isClosePushStream();

+ (AudioBufferList *)createBufferListWith:(uint32_t)numberBuffers size:(uint32_t)bufferSize channel:(uint32_t)numberChannels;

+ (void)copyBufferList:(AudioBufferList* const)dst src:( AudioBufferList* const)src;

+ (void)destroyBufferList:(AudioBufferList**)pBufferList;

+ (NSString *)setPriorityForUrl:(NSString *)url;

+ (NSString *)addQueryForURL:(NSString *)url withName:(NSString *)name value:(NSString *)value;


@end

@interface LSIParamRecordHelper : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, assign) BOOL enableVideoInfoStatistic;

@property (nonatomic, strong, readonly) NSDictionary<NSNumber *,NSString*> *layer_id_map;
- (void)setLayerIdMap:(NSDictionary<NSNumber *,NSString*> *)map;

@end



@interface LSWeakProxy : NSObject
@property (nonatomic, weak) id<NSObject> weakObject;
+ (id)LS_GET_WEAK_ASSOCIATE:(id _Nonnull)target withKey:(const void * _Nonnull)key;
@end
