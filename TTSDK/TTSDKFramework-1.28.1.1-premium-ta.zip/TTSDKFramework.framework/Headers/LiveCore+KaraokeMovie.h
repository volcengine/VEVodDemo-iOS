
#ifndef LiveCore_KaraokeMovie_h
#define LiveCore_KaraokeMovie_h

#import <UIKit/UIKit.h>

#import "LiveCore.h"

@interface LiveCore (KaraokeMovie)


- (void) resetMovieRenderView:(UIView *)view;

- (void) setKaraokeVideoMixerDescription:(NSInteger)index withPosition:(CGRect)rect;
- (void) setKaraokeVideoMixerDescription:(NSInteger)index zOrder:(int)zOrder withPosition:(CGRect)rect;

- (void) pushKaraokeMovieBuffer:(CVPixelBufferRef)pixelBuffer andCMTime:(CMTime)pts;

- (void) pushKaraokeMovieAudioBuffer:(float **)audioData samples:(int) samples;

- (void) prepareKaraokeMovieAudio:(int) sampleRate channels:(int) channesNumber;

- (void) stopPushKaraokeAudio;

- (void) setKaraokeMixVolume:(float)karaokeVolume captureVolume:(float) captureVolume;

- (void) setKaraokePlayVolume:(float)karaokeVolume;

- (void) pauseMV;

- (void) playMV;

- (void)setEnableKaraokeMovieAudioPitchShifter:(BOOL)enable;
- (BOOL)isEnableKaraokeMovieAudioPitchShifter;
- (void)setKaraokeMoviePitch:(double)pitch;

- (int)karaokeMovieZOrder;

@end


#endif 
