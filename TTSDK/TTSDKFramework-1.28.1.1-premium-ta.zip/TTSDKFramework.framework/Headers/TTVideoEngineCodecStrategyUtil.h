//
//  TTVideoEngineCodecStrategyUtil.h
//  TTVideoEngine
//
//  Created by sjc on 26.10.21.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface TTVideoEngineCodecStrategyUtil : NSObject

+ (BOOL)isDeviceSupporth265HardwareDecode;

@end

NS_ASSUME_NONNULL_END
