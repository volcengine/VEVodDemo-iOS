#pragma once

#ifdef WIN32
#define BYTEAUDIO_API __declspec(dllexport)
#else
#define BYTEAUDIO_API __attribute__((__visibility__("default")))
#endif

#include <stdint.h>

#include <string>

#include "byteaudio/bae_defines.h"
#include "byteaudio/bae_value.h"

namespace bae {

class IByteAudioDeviceManager {
public:
    /**
     * @brief Get the num of available devices.
     * @param device_type indicate the type of device, e.g. capture/render/share
     */
    virtual int get_devices_num(ByteAudioDeviceType device_type) = 0;

    /**
     * @brief Select device by device type and index.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param guid the guid indicates a device
     */
    virtual int set_device(ByteAudioDeviceType device_type, const std::string& guid) = 0;

    /**
     * @brief Get device name and guid by device type and index.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param index the index of a device which called want to query
     * @param name the derieved device name wanted by caller
     * @param guid the derieved device guid wanted by caller
     */
    virtual int get_device_by_index(ByteAudioDeviceType device_type, int index, std::string* name,
                                    std::string* guid) = 0;

    /**
     * @brief Get device name and guid by device type and option.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param option the option of a device which want to query, e.g. current/system_default/communication
     * @param name the derieved device name wanted by caller
     * @param guid the derieved device guid wanted by caller
     */
    virtual int get_device_by_option(ByteAudioDeviceType device_type, ByteAudioDeviceOption option, std::string* name,
                                     std::string* guid) = 0;

    /**
     * @brief Get explicit device info by device type and guid.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param guid the guid indicates a device
     * @param info the derieved explicit info of device
     */
    virtual int get_device_info(ByteAudioDeviceType device_type, const std::string& guid,
                                ByteAudioDeviceInfo* info) = 0;

    /**
     * @brief check device active state, only active device can be used.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param guid the guid indicates a device
     */
    virtual int check_device_active(ByteAudioDeviceType device_type, const std::string& guid) = 0;

    /**
     * @brief Start current device.
     * @attention Only for Video Conference
     * @param device_type indicate the type of device, e.g. capture/render/share
     */
    virtual int start_device(ByteAudioDeviceType device_type) = 0;

    /**
     * @brief Stop current device.
     * @attention Only for Video Conference
     * @param device_type indicate the type of device, e.g. capture/render/share
     */
    virtual int stop_device(ByteAudioDeviceType device_type) = 0;

    /**
     * @brief Set the given volume to the current capture/render/share device.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param volume integer, the value of volume the caller want to set to the device
     */
    virtual int set_volume(ByteAudioDeviceType device_type, int volume) = 0;

    /**
     * @brief Get the volume of the current capture/render/share device.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param volume pointer to integer, the value of volume derieved from current device
     */
    virtual int get_volume(ByteAudioDeviceType device_type, int* volume) = 0;

    /**
     * @brief Mute the current capture/render/share device or not.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param mute bool, indicated that to mute or not to mute
     */
    virtual int set_mute(ByteAudioDeviceType device_type, bool mute) = 0;

    /**
     * @brief Get the mute status of the current capture/render/share device.
     * @param device_type indicate the type of device, e.g. capture/render/share
     * @param mute pointer to bool, the state of mute derieved from current device
     */
    virtual int get_mute(ByteAudioDeviceType device_type, bool* muted) const = 0;

    /**
     * @brief Enable mobile route to speakerphone.
     * @param enable true: route to speakerphone, false: route to earpiece
     */
    virtual void enable_speakerphone(bool enable) = 0;

    /**
     * @brief Increase reference count of enable audio router control.
     *        If the reference count > 0, audio route in byteaudio controll will be started.
     */
    virtual int add_enable_audio_route_reference() = 0;

    /**
     * @brief Decrease the reference count of enable audio router control.
     *        If the reference count equals to 0, audio route in byteaudio controll will be stopped.
    */
    virtual int remove_enable_audio_route_reference() = 0;

    /**
     * @brief Set iOS external audio session configuration.
     * @attention only valid on iOS
     * @param category AVAudioSessionCategory
     * @param category_options AVAudioSessionCategoryOptions
     * @param mode AVAudioSessionMode
     */
    virtual int set_ios_external_audio_session_configuration(const char* category, int category_options,
                                                             const char* mode) = 0;

    /**
     * @brief set optional values to device manager.
     * @attention valid at all times.
     * @param device_type audio device type
     * @param key option key, refer to `ByteAudioDeviceConfigKey`.
     * @param value value to be set.
     * @return error code, refer to @ByteAudioErrorCode.
     */
    virtual int set_value(ByteAudioDeviceType device_type, int key, ByteAudioValue value) = 0;
};
}  // namespace bae
