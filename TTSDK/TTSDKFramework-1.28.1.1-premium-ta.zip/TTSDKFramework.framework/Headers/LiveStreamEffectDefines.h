
#ifndef LSLiveEffectDefine_h
#define LSLiveEffectDefine_h
#import "LSMacros.h"

typedef struct LSLiveIntensityParam_t {
    float intensity;
    float smoothIntensity;
    float whiteIntensity;
    float sharpIntensity;
    float eyeIntensity;
    float cheekIntensity;
    float fareyeIntensity;          
    float zoomeyeIntensity;         
    float rotateeyeIntensity;       
    float zoomnoseIntensity;        
    float movnoseIntensity;         
    float movmouthIntensity;        
    float zoommouthIntensity;       
    float movchinIntensity;         
    float zoomforeheadIntensity;    
    float zoomfaceIntensity;        
    float cutfaceIntensity;         
    float smallfaceIntensity;       
    float zoomjawboneIntensity;     
    float zoomcheekboneIntensity;   
    float draglipsIntensity;        
    float cornereyeIntensity;       
    float lipenhanceIntensity;      
    float pointychinIntensity;      
    float facialmoothIntensity;      
    
    float darkIntensity;
    float nightGamma;           
    float nightContrastK;       
    float nightContrastB;       
    float lipIntensity;         
    float blusherIntensity;     
    float decreeIntensity;      
    float pouchIntensity;       
} LSLiveIntensityParam;

typedef NS_ENUM(NSInteger, LSLiveEffectType) {
    LSLiveEffectNone = 0,
    LSLiveEffectBeautify,
    LSLiveEffectSkinDark,
    LSLiveEffectFilter,
    LSLiveEffectMusicFilter,
    LSLiveEffectNightMode,
    LSLiveEffectReshape,
    LSLiveEffectGroup,
    
    LSLiveEffectReshapeTwoParam,
    LSLiveEffectMakeup,
    LSLiveEffectGame,
};

typedef NS_ENUM(NSUInteger, LSLiveEffectUsedType)
{
    LSLiveEffectUsedNone             = 0,
    LSLiveEffectUsedBeautify         = (0x01 << 0),
    LSLiveEffectUsedFilter           = (0x01 << 1),
    LSLiveEffectUsedReshape          = (0x01 << 2),
    LSLiveEffectUsedMusicFilter      = (0x01 << 3),
    LSLiveEffectUsedGroup            = (0x01 << 4),
    LSLiveEffectUsedDark             = (0x01 << 5),
    LSLiveEffectUsedNightMode        = (0x01 << 6),
    LSLiveEffectUsedAlgorithm        = (0x01 << 7),
    LSLiveEffectUsedComposer         = (0x01 << 8),
    LSLiveEffectUsedMakeup           = (0x01 << 9),
};

typedef NS_OPTIONS(NSUInteger, LSLiveEffectResStatus) {
    LSLiveEffectResStatusUnknown = 0,
    LSLiveEffectResStatusInit,
    LSLiveEffectResStatusLoading,
    LSLiveEffectResStatusSuccess,
    LSLiveEffectResStatusFail,
    
    LSLiveEffectResEventDidSwitchEffect,
    
};

typedef NS_OPTIONS(NSUInteger, LSLiveAlgorithm) {
    LSLiveAlgorithm_None                         = 0,
    LSLiveAlgorithm_FaceDetect                   = 1,
    LSLiveAlgorithm_Matting                      = 1 << 1,
    LSLiveAlgorithm_Hair                         = 1 << 2,
    LSLiveAlgorithm_SLAM                         = 1 << 3,
    LSLiveAlgorithm_Body                         = 1 << 4,
    LSLiveAlgorithm_FaceTrack                    = 1 << 5,
    LSLiveAlgorithm_Joint                        = 1 << 6,
    LSLiveAlgorithm_FaceCatDetect                = 1 << 7,
    LSLiveAlgorithm_FaceDetect240                = 1 << 8,
    LSLiveAlgorithm_HandBase                     = 1 << 10,
    LSLiveAlgorithm_Skeleton2                    = 1 << 11,
    LSLiveAlgorithm_ExpressionDetect             = 1 << 12,
    LSLiveAlgorithm_Face3DDetect                 = 1 << 13,
    LSLiveAlgorithm_SkySeg                       = 1 << 14,
    LSLiveAlgorithm_SkeletonLiuXing              = 1 << 15,
    LSLiveAlgorithm_Enigma                       = 1 << 16,
    LSLiveAlgorithm_Pout                         = 1 << 26,
};


#define LSLiveAllTypeEvent 0xFFFFFFFF

typedef NS_ENUM(NSUInteger, LSLiveEffectMsg) {
    LSLiveEffectMsgTypeResource         = 0x00000014,

    LSLiveEffectMsgTypeAudioPlayer      = 0x00000015,
    LSLiveEffectMsgTypeAudioRecord      = 0x0000002B,  
    LSLiveEffectMsgTypeGameREQ          = 0x0000002D,  
    LSLiveEffectMsgTypeGameNTF          = 0x0000002E,  
    LSLiveEffectMsgTypeGameMusic        = 0x0000002F,  
    LSLiveEffectMsgTypeGameStartRecord  = 0x00000030,  
    LSLiveEffectMsgTypeGameStopRecord   = 0x00000031,  
    LSLiveEffectMsgMedalRecognition     = 0x00000038,  
    LSLiveEffectMsgTypeLiveGiftNotify   = 0x00000039,
    
    LSLiveEffectMsgGameStartNTF         = 0x00001001,  
    LSLiveEffectMsgGameEndNTF           = 0x00001002,  
    LSLiveEffectMsgGameEndReq           = 0x00001003,  
    LSLiveEffectMsgGamePauseNTF         = 0x00001004,  
    LSLiveEffectMsgGameResumeNTF        = 0x00001005,  
    LSLiveEffectMsgGameRestartNTF       = 0x00001006,  
    LSLiveEffectMsgGameChallengeNTF     = 0x00001007,  
    LSLiveEffectMsgGameResourceLoaded   = 0x00001008,  
    LSLiveEffectMsgStickerRecognize     = 0x00001114,  
    
    LSLiveEffectMsgFaceInfo             = 0x0000001D,  
};


typedef NS_ENUM(NSUInteger, LSStickerStatus) {
    LSStickerStatusInit = 0,
    LSStickerStatusLoading,
    LSStickerStatusValid,
    LSStickerStatusInvalid,
    LSStickerStatusAnimationFinish
};

typedef NS_ENUM(NSInteger, LSEffectAudioRecordStatus)
{
    eLSEffectAudioRecordStart = 0,
    eLSEffectAudioRecordStop = 1,
    eLSEffectAudioRecordComplete = 2
};

typedef NS_ENUM(NSUInteger, LSLiveEffectGestureType) {
    LSLiveEffectGestureTypeUnknown = 0,
    LSLiveEffectGestureTypeTap,     
    LSLiveEffectGestureTypePan,     
    LSLiveEffectGestureTypeRotate,  
    LSLiveEffectGestureTypePinch,   
    LSLiveEffectGestureTypeLongPress    
};

typedef NS_ENUM(NSUInteger, LSLiveEffectTouchType)
{
    LSLiveEffectTouchBegin = 0,
    LSLiveEffectTouchMove  = 1,
    LSLiveEffectTouchStationary = 2,
    LSLiveEffectTouchEnded = 3,
    LSLiveEffectTouchCanceled = 4
};

@interface LSLiveAlgorithmResultData : NSObject

@property (nonatomic, assign) LSLiveAlgorithm algorithmType;

- (instancetype) init;

@end

@interface LSLiveFaceDetectResultData : LSLiveAlgorithmResultData

@property (nonatomic, assign) CGFloat yaw;
@property (nonatomic, assign) CGFloat pitch;
@property (nonatomic, assign) CGFloat roll;
@property (nonatomic, assign) NSUInteger action;

@end


#endif 
