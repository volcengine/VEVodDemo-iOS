
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define LCAudioLayerID 1
@interface LCAudioMixer : NSObject

- (void)addInputWithLayerId:(int)layerId;
- (void)removeInputForLayer:(int)layerId;

- (void)setVolume:(float)volume
         forTrack:(int)trackId;

- (void)getVolume:(float *)volume
          ofTrack:(int)trackId;

- (void)renderAudioTo:(int16_t *)dst
            withAudio:(int16_t *)audioData
            withAudio:(int16_t *)otherData
              samples:(int)number_samples;

@end

NS_ASSUME_NONNULL_END
