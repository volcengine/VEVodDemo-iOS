/*
 * Copyright 2021 @bytedance
 * Created on: Sept 15, 2021.
 */

#pragma once

#include "lite_rts_push_engine_define.h"

namespace byterts {

class IRTSPushEngineObserver {
 public:
    virtual void OnEventNotify(RTSPushEngineEvent event, void* biz_data) = 0;

    virtual void OnErrorNotify(RTSPushEngineError error, void* biz_data) = 0;

    virtual void OnLogPrint(RTSPushEngineLogLevel level, const char* content, void* biz_data) = 0;

    virtual void OnTracePrint(
            RTSPushEngineTraceLevel level, const char* trace_tag, const char* content, void* biz_data) = 0;

    virtual ~IRTSPushEngineObserver() = default;
};

class IRTSPushEngine {
 public:
     virtual int32_t Init(IRTSPushEngineObserver* observer, const RTSPushEngineConfigure config) = 0;

     virtual int32_t UnInit() = 0;

     virtual int32_t Prepare() = 0;

     virtual int32_t Start() = 0;

     virtual int32_t Stop(RTSStopReason reason) = 0;
 
     virtual bool IsPushing() = 0;

     virtual const char* GetSdkVersion() const = 0;

     virtual int32_t SetParameter(const char* params) = 0;

     virtual bool SetConnectRetryCount(int count, int interval) = 0;

     virtual int32_t GetStatsReport(RTSPushEngineStats* rts_stats) = 0;

     virtual int32_t GetTracePrint(RTSTraceType trace_type, RTSPushEngineTrace* rts_trace) = 0;

     virtual void PushAudioFrame(const RTSAudioFrame& aframe, int64_t time_ns) = 0;

     virtual void PushVideoFrame(const RTSVideoFrame& vframe, int64_t time_ns) = 0;

     virtual ~IRTSPushEngine() = default;
};

BYTE_RTS_EXPORT IRTSPushEngine* CreateRtsPushEngine(const char* app_id);

BYTE_RTS_EXPORT void DestroyRtsPushEngine(IRTSPushEngine* engine);


} /* namespace byterts */
