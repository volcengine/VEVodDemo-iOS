//  Copyright © 2018 tianzhuo. All rights reserved.

#ifndef LSRecorderDefine_h
#define LSRecorderDefine_h

#define kBusZero 0
#define kBusOne 1

typedef NS_ENUM(NSUInteger, LSAudioRecorderMode) {
    LSAudioRecorderModePlayAndRecord,
    LSAudioRecorderModePlayback,
};

typedef NS_ENUM(NSUInteger, LSAudioRecorderStatus) {
    LSAudioRecorderStatusIdle,
    LSAudioRecorderStatusProcessing,
    LSAudioRecorderStatusPaused,
    LSAudioRecorderStatusStop
};

typedef NS_ENUM(NSUInteger, LSAudioConverterStatus) {
    LSAudioConverterStatusUnknown,
    LSAudioConverterStatusReady,
    LSAudioConverterStatusFailed,
    LSAudioConverterStatusDestory,
};
typedef NS_ENUM(NSInteger, LSAudioConverterErrorCode) {
    LSErrorCodeAudioStreamDescriptionInvalid = -4, 
    LSErrorCodeOpenURLFailed                 = -5,
    LSErrorCodeAudioConverterFailed          = -6,
    LSErrorCodeAudioFileReadPacketFailed     = -7,
    LSErrorCodeAudioStartTimeError           = -9,
};

typedef struct LSRecorderDescription {
    Float32 musicPitch;
    Float32 musicVolume;
    Float32 recordVolume;
    NSTimeInterval startTime;
    NSTimeInterval timeOffset;
} LSRecorderDescription;

typedef NS_ENUM(NSUInteger, LSMusicType) {
    LSMusicTypeAccompany = 0,
    LSMusicTypeOriginalSing = 1,
};

#endif 
