#pragma once

#ifdef WIN32
#define BYTEAUDIO_API __declspec(dllexport)
#else
#define BYTEAUDIO_API __attribute__((__visibility__("default")))
#endif

#include <stdint.h>

#include <map>
#include <string>
#include <vector>

#include "byteaudio/bae_defines.h"
#include "byteaudio/bae_report.h"
#include "byteaudio/bae_value.h"

namespace bae {
class IByteAudioDeviceManager;
/**
 * @brief Audio format of ByteAudioStreamBuffer.
 */
struct ByteAudioStreamFormat {
    // sample rate
    int sample_rate;
    // num of channels
    int channel_num;
    // encode bitrate bps, only for input stream
    int bitrate_bps;
    // allocate bitrate bps, only VC low_bandwidth
    int alloc_bitrate_bps;
    // frame size in ms, default 20, just used by pcm format
    int framesize_ms = 20;
    // transType, just used by aac
    ByteAudioAACTransType aac_trans_type;
    // aot, just used by aac
    int aac_aot;
    // see @ByteAudioCodecType
    ByteAudioCodecType codec_type;
};

/**
 * @brief Options for output stream pull buffer.
 * @attention Only for realx jitter buffer.
 */
struct ByteAudioPullBufferOptions {
    // whether got buffer (jitter buffer give to audio decoder)
    bool got_buffer;
    // decode operation (jitter buffer give to audio decoder)
    int decode_operation;
    // whether inbandfec (jitter buffer give to audio decoder)
    bool is_inbandfec;
    // in dtx mode (decoder give to jitter buffer)
    bool in_dtx_mode;
    // sync buffer size (decoder give to jitter buffer)
    unsigned int sync_buffer_size;
    // end timestamp (decoder give to jitter buffer)
    unsigned int end_timestamp;
    // stretched samples (decoder give to jitter buffer)
    int stretched_samples;
    // last decode length (decoder give to jitter buffer)
    unsigned int last_decode_length;
    // generate noise sample (decoder give to jitter buffer)
    unsigned int generate_noise_sample;
    // transType, just used by aac
    ByteAudioAACTransType aac_trans_type;
    // aot, just used by aac
    int aac_aot;
};

/**
 * @brief Audio buffer for stream and filter.
 * @attention Only for realx jitter buffer.
 */
enum ByteAudioStreamNum { kByteAudioMinAudioStreamNum = 1, kByteAudioMaxAudioStreamNum = 4 };
struct ByteAudioStreamBuffer {
    // data
    int8_t* data;
    // size of data
    int length = 0;
    // see @ByteAudioStreamFormat
    ByteAudioStreamFormat format;
    // sequence number
    uint16_t sequence_number = 0;
    // timestamp
    unsigned int timestamp = 0;
    // audio level dbov, only for RealX
    unsigned short audio_level_dbov = 0;
    // is voice active, only for RealX
    bool voice_active = true;
    // new audio codec payload offset, only for Realx
    int nBytes[2 * kByteAudioMaxAudioStreamNum] = {0};
    // new audio codec stream num, only for Realx
    int num_stream = 0;
    uint16_t publish_event_session_id = 0;
    uint16_t subscribe_event_session_id = 0;
    int64_t render_time_ms = 0;
    // encode  time
    int64_t encode_time_ns = 0;
    // intput time
    int64_t input_time_ns = 0;
    // audio stream sync info
    std::string stream_sync_info;
};

struct AudioSampleConfigure {
    bool aec_near_in_enable = false;
    bool aec_far_in_enable = false;
    bool aec_far_in_ref_enable = false;
    bool aec_out_enable = false;
    bool agc_out_enable = false;
    bool ns_out_enable = false;
    bool ainr_out_enable = false;
    bool mix_out_enable = false;
    bool send2encoder_enable = false;
    bool audio_share_in_enable = false;
    bool audio_share_win_ref_enable = false;
    bool audio_share_out_enable = false;
    bool external_audio_in_enable = false;
    bool pitchfilter_out_enable = false;
    bool decoder_out_enable = false;
};

/**
 * @brief Audio scenario type.
 */
enum ByteAudioScenarioType {
    /**
     * @brief music scenario, which is default.
     *        use communication mode in speaker/receiver, media mode in others.
     *        suitable in need of music performance such as live broatcasting or game.
     */
    kByteAudioScenarioMusic = 0,

    /**
     * @brief high-quality communication scenario.
     *        use communication mode in speaker/receiver and bluetooth, media mode in others.
     *        suitable in scenes of voice chat app with music.
     */
    kByteAudioScenarioHighQualityCommunication = 1,
    /**
     * @brief communication scenario.
     *        use communication mode every time whenever.
     *        suitable in scenes of switch mic frequently or video conference.
     */
    kByteAudioScenarioCommunication = 2,

    /**
     * @brief media scenario.
     *        use media mode every time whenever.
     *        suitable for special business needs and not recommended.
     */
    kByteAudioScenarioMedia = 3,

    /**
     * @brief game streaming scenario.
     *        use media mode when speaker/receiver and wired headset.
     *        use communication mode when bluetooth.
     */
    kByteAudioScenarioGameStreaming = 4,
};

/**
 * @brief Audio scenario strategy.
 */
struct ByteAudioScenarioStrategy {
    /**
     * @brief Audio session mode.
     */
    enum Mode {
        // for iOS, use remote io audiounit and default session mode
        // for Android, use default audiosource and normal mode
        Media = 0,
        // for iOS, use vpio audiounit and voicechat session mode
        // for Android, use voice_communication audiosource and communication mode
        Communication = 1,
    };

    /**
     * @brief Audio scenario option in the state of broadcast/audience/voicechat
     */
    struct Option {
        Option() = default;

        Option(Mode broadcast, Mode audience, Mode voicechat);

        Option(const Option& src) = default;

        Option& operator=(const Option& src) = default;

        bool operator!=(const ByteAudioScenarioStrategy::Option& other) const;

        bool operator==(const ByteAudioScenarioStrategy::Option& other) const;

        Mode broadcast_session_mode;
        Mode audience_session_mode;
        Mode voicechat_session_mode;
    };

    ByteAudioScenarioStrategy() = default;

    explicit ByteAudioScenarioStrategy(ByteAudioScenarioType type);

    ByteAudioScenarioStrategy(const ByteAudioScenarioStrategy& src) = default;

    ByteAudioScenarioStrategy& operator=(const ByteAudioScenarioStrategy& src) = default;

    bool operator!=(const ByteAudioScenarioStrategy& other) const;

    bool operator==(const ByteAudioScenarioStrategy& other) const;

    // indicates scenario strategy when using built-in receiver/speaker
    Option built_in_device_info;
    // indicates scenario strategy when using wired headset
    Option wired_headset_info;
    // indicates scenario strategy when using bluetooth headset
    Option bt_headset_info;
    // indicates type of scenario
    ByteAudioScenarioType type;
};

/**
 * @brief Event callback handler.
 */
class ByteAudioEventHandler {
public:
    /**
     * @brief Destructor.
     */
    virtual ~ByteAudioEventHandler() = default;

    /**
     * @brief event notify
     * @param event_key: event key, see@ByteAudioEventKey
     * @param code: event code
     * @param msg: event message
     */
    virtual void on_event(ByteAudioEventKey event_key, int code, const char* msg) {
    }

    /**
     * @brief detailed audio event info notify, only for report
     * @param ByteAudioEventInfo: see @ByteAudioEventInfo
     */
    virtual void on_event_info(const ByteAudioEventInfo& info) {
    }

    /**
     * @brief notify the change of audio device state
     * @param device_id: device id of audio device
     * @param device_type: 0: render, 1: capture, see @ByteAudioDeviceType
     * @param device_state: state of device, see @ByteAudioDeviceStateType
     * @param device_info: info of changed device
     */
    virtual void on_audio_device_state_changed(const char* device_id, int device_type, int device_state,
                                               const char* device_info) {
    }

    /**
     * @brief notify the change of default audio device changed
     * @param device_type: 0: render, 1: capture, see @ByteAudioDeviceType
     * @param device_info: info of changed device
     */
    virtual void on_default_device_changed(int device_type, const char* device_info) {
    }

    /**
     * @brief notify the volume and mute change of current using audio device
     * @param device_type: 0: render, 1: capture, see @ByteAudioDeviceType
     * @param volume: volume value [0,  255]
     * @param muted: mute status
     * @param system: system type or application type on Win, always true in other platform
     * @param msg: event message
     */
    virtual void on_volume_changed(int device_type, int volume, bool muted, bool system, const char* msg) {
    }

    /**
     * @brief log message callback
     * @param msg: log message
     */
    virtual void on_log_message(const char* msg) {
    }

    /**
     * @brief api call message callback, at entry of api.
     * @param api_name: api name, plain C string.
     * @param msg: params of api call.
     */
    virtual void on_api_call(const char* api_name, const char* msg) {
    }

    /**
     * @brief api call message callback when error occurs.
     * @param api_name: api name, plain C string.
     * @param error_code: error code of api call.
     * @param msg: includes error code of api call and error message.
     */
    virtual void on_api_call_error(const char* api_name, int error_code, const char* msg) {
    }

    /**
    * @brief report engine info when status of streams changed, callback when byteaudio process engine strategy
    * @param msg: the info including reason, status of streams and others with format of json as below:
                  input_streams: list input streams with stream_id
                  output_streams: list output streams with stream_id
                  aux_streams: list aux streams with stream_id
                  ext_info: other engine info, such as options(engine/device), scenario, and some important engine states
    */
    virtual void on_engine_info(const char* msg) {
    }

    /**
    * @brief callback android update notifications about the recording configuration
    * @param callback_info: the callback info including: audio_source_id/client_audio_source/audio_source/is_client_silenced/is_by_self
    */
    virtual void on_android_record_callback(std::vector<ByteAudioAndroidRecordCallbackInfo>& callback_info) {
    }
};

/**
 * @brief Audio filter callback for external effect process.
 */
class ByteAudioFilter {
public:
    /**
     * @brief Destructor.
     */
    virtual ~ByteAudioFilter() = default;

    /**
     * @brief Callback stream buffer for external process.
     * @param buffer: stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int on_process(ByteAudioStreamBuffer& buffer) = 0;

    // filter may use different samplerate and channel number, so need to have a specific timestamp
    unsigned int timestamp = 0;

    int32_t expected_sample_rate = -1;
    int32_t expected_channels_num = -1;
};

/**
 * @brief Option key of input/output/aux stream, determin property of stream.
 */
enum ByteAudioStreamOptionKey {
    /**
     * @brief Enable mix with aux (for input stream).
     * value_type: bool, default false
     */
    kInputOptMixWithAux = 10001,
    /**
     * @brief Enable mix with playout (for input stream).
     * value_type: bool, default false
     */
    kInputOptMixWithPlayout = 10002,
    /**
     * @brief Enable mix with record (for input stream).
     * value_type: bool, default true
     */
    kInputOptMixWithRecord = 10003,

    /**
     * @brief Enable mix with screen audio (for input stream).
     * value_type: bool, default false
     */
    kInputOptMixWithScreen = 10004,
    
    /**
     * @brief Enable smart mix ducking the music (for input stream).
     * value_type: bool, default false
     */
    kInputOptEnableSmartMix = 10005,
    
    /**
     * @brief Enable speech loudnorm only when smart mix is enabled  (for input stream).
     * value_type: bool, default false
     */
    kInputOptEnableLoudnorm = 10006,

    /**
     * @brief Aux stream type (for aux stream).
     * value_type: int32_t
     * scope: 0: audio_file (default)
     *        1: pcm_stream(pull)
     *        2: pcm_stream(push)
     */
    kAuxOptStreamType = 20000,
    /**
     * @brief Enable mix to input (for aux stream).
     * value_type: bool, default false
     */
    kAuxOptMix2Input = 20001,
    /**
     * @brief Enable mix to output (for aux stream).
     * value_type: bool, default false
     */
    kAuxOptMix2Output = 20002,
    /**
     * @brief Volume gain of mix to input (for aux stream).
     * value_type: int32_t
     * scope: 0 ~ 400 (default 100)
     */
    kAuxOptMix2InputGain = 20003,
    /**
     * @brief Volume gain of mix to output (for aux stream).
     * value_type: int32_t
     * scope: 0 ~ 400 (default 100)
     */
    kAuxOptMix2OutputGain = 20004,
    /**
     * @brief position of file aux
     * value_type: int32_t
     */
    kAuxOptPosition = 20005,
    /**
     * @brief duration of file aux
     * value_type: int32_t
     */
    kAuxOptDuration = 20006,
    /**
     * @brief Whether to mute of file aux (for aux stream).
     * value_type: bool, default false
     */
    kAuxOptMute = 20007,
    /**
     * @brief loop time for file aux
     * value_type: int32_t
     */
    kAuxOptLoopCount = 20008,

    /**
     * @brief select audio track
     * value_type: int32_t, (read/write)
     */
    kAuxOptAudioTrack = 20009,

    /**
     * @brief Wether aux stream is preloaded
     * value_type: bool, (read only)
     */
    kAuxOptPreloaded = 20010,

    /**
     * @brief Set force to use media mode.
     *        If all aux streams force to media mode,
     *        switch device mode to media when the aux stream is ready to playing out,
     *        if a output stream started once, ignore this option.
     * value_type: bool, default false
     */
    kAuxOptForceMediaMode = 20011,

    /**
     * @brief loudness for each aux stream
     * value_type: float, default 1.0f
     */
    kAuxOptIntegratedLoudness = 20012,

    /**
     * @brief playout delay in ms of the aux stream.
     * value_type: int32_t, read only
     */
    kAuxOptPlayoutDelayMs = 20013,

    /**
     * @brief publish delay in ms of the aux stream.
     * value_type: int32_t, read only
     */
    kAuxOptPublishDelayMs = 20014,

     /**
     * @brief Wether aux stream has started
     * value_type: bool, (read only)
     */
    kAuxOptStreamStarted = 20015,

    /**
     * @brief User customized Option Key (for all stream).
     * scope: [40000, 100000)
     */
};

class ByteAudioInputSink;
/**
 * @brief Input stream, charge of record/preprocess/mix/encode and push stream buffer to external SDK/APP.
 */
class ByteAudioInputStream {
public:
    /**
     * @brief Get name of stream.
     * @return name of stream
     */
    virtual const std::string& get_name() = 0;

    /**
     * @brief Get id of stream.
     * @attention id is unique and defined incrementally by engine in order of time.
     * @return id of stream
     */
    virtual uint32_t get_id() const = 0;

    /**
     * @brief Adjust volume gain.
     * @param gain: stream volume gain, scope: 0 ~ 400 (default 100)
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_gain(int gain) = 0;

    /**
     * @brief whether mute the output of input stream, have no effects on playout/aux mix
     * @param mute:
     *        true: mute the output of input stream
     *        false: unmute the output of input stream
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_mute(bool mute) = 0;

    /**
     * @brief Set stream format.
     * @attention only valid before start_stream
     * @param stream_format: see @ByteAudioStreamFormat
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_stream_format(ByteAudioStreamFormat stream_format) = 0;

    /**
     * @brief Update stream format after push_buffer, this is an api without a mutex.
     * @param stream_format: see @ByteAudioStreamFormat
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int update_stream_format(ByteAudioStreamFormat stream_format) = 0;

    /**
     * @brief Set Options value.
     * @attention only valid before start_stream
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param key: option value, refer to @ByteAudioStreamOptionKey to set RXValue with correct type
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_value(int key, ByteAudioValue value) = 0;

    /**
     * @brief Get Options value.
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param value: pointer of RXValue
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int get_value(int key, ByteAudioValue* value) = 0;

    /**
     * @brief Start stream, apply stream format and options.
     *        will offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int start_stream() = 0;

    /**
     * @brief Stop stream, apply stream format and options.
     *        will no longer offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int stop_stream() = 0;

    /**
     * @brief Register @ByteAudioInputSink for offer stream buffer.
     * @param sink: refer to @ByteAudioInputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_input_stream_sink(ByteAudioInputSink* sink) = 0;

    /**
     * @brief report statistic of InputStream
     * @return error code, refer to @ByteAudioInputStreamReport
     */
    virtual ByteAudioInputStreamReport get_report_stats() = 0;

    /**
     * @brief report statistic of InputStream
     * @return report map with pairs <report name, report value>
     */
    virtual std::map<std::string, std::string> get_report_stats_map() = 0;

    /**
     * @brief set stream sync info for send with rtp packet
     * @param stream_sync_info send value in rtp packet
     * @param repeat_times repeat send time, use 0 to send 1 times
     * @return if the queue size full return false
     * inside the audio input the size of queue is 25
     */
    virtual int32_t set_stream_sync_info(const std::string& stream_sync_info, size_t repeat_times) = 0;
};

/**
 * @brief Input sink for offer stream buffer external SDK/APP, register to input stream.
 */
class ByteAudioInputSink {
public:
    virtual ~ByteAudioInputSink() = default;

    /**
     * @brief Callback stream buffer from input stream.
     * @param stream: handle of input stream
     * @param buf: stream buffer, refer to @ByteAudioStreamBuffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int on_push_audio_buffer(ByteAudioInputStream* stream, ByteAudioStreamBuffer& buf) = 0;
};

class ByteAudioAuxSink;
/**
 * @brief Aux stream, charge of mix file/pcm_stream into input/output stream.
 */
class ByteAudioAuxStream {
public:
    virtual ~ByteAudioAuxStream() = default;

    /**
     * @brief Get name of stream.
     * @return name of stream
     */
    virtual const std::string& get_name() = 0;

    /**
     * @brief Get id of stream.
     * @attention id is unique and defined incrementally by engine in order of time.
     * @return id of stream
     */
    virtual uint32_t get_id() const = 0;

    /**
     * @brief Adjust volume gain.
     * @param gain: stream volume gain, scope: 0 ~ 400 (default 100)
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_gain(int gain) = 0;

    /**
     * @brief get current volume gain.
     * @return gain value
     */
    virtual int get_gain() = 0;
    /**
     * @brief Set stream format.
     * @attention only valid before start_stream
     * @param stream_format: see @ByteAudioStreamFormat
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_stream_format(ByteAudioStreamFormat stream_format) = 0;

    /**
     * @brief Get stream format
     * @return current stream format
     */
    virtual ByteAudioStreamFormat get_stream_format() = 0;

    /**
     * @brief Set Options value.
     * @attention only valid before start_stream
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param key: option value, refer to @ByteAudioStreamOptionKey to set RXValue with correct type
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_value(int key, ByteAudioValue value) = 0;

    /**
     * @brief Get Options value.
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param value: pointer of RXValue
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int get_value(int key, ByteAudioValue* value) = 0;

    /**
     * @brief Pause stream.
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int pause_stream() = 0;

    /**
     * @brief Resume stream.
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int resume_stream() = 0;
    /**
     * @brief preload stream
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int preload_stream() = 0;
    /**
     * @brief unload stream
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int unload_stream() = 0;
    /**
     * @brief Start stream, apply stream format and options.
     *        will offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int start_stream() = 0;

    /**
     * @brief Stop stream, apply stream format and options.
     *        will no longer offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int stop_stream() = 0;

    /**
     * @brief Register @ByteAudioAuxSink to pcm stream type aux stream.
     * @param sink: refer to @ByteAudioInputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_aux_stream_sink(ByteAudioAuxSink* sink) = 0;

    /**
     * @brief Set path to file aux stream.
     * @param sink: refer to @ByteAudioInputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_aux_stream_source_path(const std::string& path) = 0;

    /**
     * @brief Add input_stream name to aux_stream for mix.
     * @param stream_name: refer to an input_stream name
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int add_input_stream_name_for_mix(const char* stream_name) = 0;

    /**
     * @brief push pcm stream to aux stream.
     * @param sink: refer to @ByteAudioInputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int push_audio_frame(ByteAudioStreamBuffer& buffer) = 0;

    /**
     * @brief Clear input_stream name to aux_stream for mix.
     * @param stream_name: refer to an input_stream name
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int clear_input_stream_name_for_mix() = 0;

    /**
     * @brief report statistic of AuxStream
     * @return report statistic, refer to @ByteAudioAuxStreamReport
     */
    virtual ByteAudioAuxStreamReport get_report_stats() = 0;

    /**
     * @brief report statistic of AuxStream
     * @return report map with pairs <report name, report value>
     */
    virtual std::map<std::string, std::string> get_report_stats_map() = 0;
};

/**
 * @brief Aux sink for pull stream buffer and notify mix event, register to aux stream.
 */
class ByteAudioAuxSink {
public:
    /**
     * @brief Destructor.
     */
    virtual ~ByteAudioAuxSink() = default;

    /**
     * @brief Pull stream buffer from external SDK/APP.
     * @param sink: refer to @ByteAudioInputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int on_pull_audio_buffer(ByteAudioAuxStream* stream, ByteAudioStreamBuffer& buf) = 0;
    /**
     * @brief Notify external SDK/APP input mixing begin.
     */
    virtual void on_aux_mixing_begin(ByteAudioAuxStream* stream) = 0;
    /**
     * @brief Notify external SDK/APP input mixing end.
     */
    virtual void on_aux_mixing_end(ByteAudioAuxStream* stream) = 0;
};

class ByteAudioOutputSink;
class ByteAudioOutputFrameObserver;
/**
 * @brief Output stream: pull stream buffer from external SDK/APP, and decode/mix/postprocess/playout.
 */
class ByteAudioOutputStream {
public:
    /**
     * @brief Get name of stream.
     * @return name of stream
     */
    virtual const std::string& get_name() = 0;

    /**
     * @brief Get id of stream.
     * @attention id is unique and defined incrementally by engine in order of time.
     * @return id of stream
     */
    virtual uint32_t get_id() const = 0;

    /**
     * @brief Adjust volume gain.
     * @param gain: stream volume gain, scope: 0 ~ 400 (default 100)
     * @param fade_interval: stream volume fade interval : default 2000ms
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_gain(int gain, int fade_interval) = 0;

    /**
    * @brief Adjust direction.
    * @param r, theta, phi: dircation specification by sphere coord
    * @return error code, refer to @ByteAudioErrorCode
    */
    virtual int set_direction(float r, float theta, float phi) = 0;

    /**
     * @brief Adjust volume gain.
     * @param gain: stream volume gain, scope: 0 ~ 400 (default 100)
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_gain(int gain) = 0;

    /**
     * @brief whether mute the output of output stream, have no effects on input/aux mix
     * @param mute:
     *        true: mute the output of output stream
     *        false: unmute the output of output stream
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_mute(bool mute) = 0;

    /**
     * @brief Set stream format.
     * @attention only valid before start_stream
     * @param stream_format: see @ByteAudioStreamFormat
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_stream_format(ByteAudioStreamFormat stream_format) = 0;

    /**
     * @brief Set Options value.
     * @attention only valid before start_stream
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param key: option value, refer to @ByteAudioStreamOptionKey to set RXValue with correct type
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_value(int key, ByteAudioValue value) = 0;

    /**
     * @brief Get Options value.
     * @param key: option key, see @ByteAudioStreamOptionKey
     * @param value: pointer of RXValue
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int get_value(int key, ByteAudioValue* value) = 0;

    /**
     * @brief Start stream, apply stream format and options.
     *        will offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int start_stream() = 0;

    /**
     * @brief Stop stream, apply stream format and options.
     *        will no longer offer stream buffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int stop_stream() = 0;

    /**
     * @brief Register @ByteAudioOutputSink for feed stream buffer into output stream.
     * @param sink: refer to @ByteAudioOutputSink
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_output_stream_sink(ByteAudioOutputSink* sink) = 0;

    /**
     * @brief Register @ByteAudioOutputFrameObserver for callback audio frame.
     * @param observer: refer to @ByteAudioOutputFrameObserver
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_frame_observer(ByteAudioOutputFrameObserver* observer) = 0;

    /**
     * @brief report statistic of OutPutStream
     * @return error code, refer to @ByteAudioOutPutStreamReport
     */
    virtual ByteAudioOutputStreamReport get_report_stats() = 0;

    /**
     * @brief report statistic of OutputStream
     * @return report map with pairs <report name, report value>
     */
    virtual std::map<std::string, std::string> get_report_stats_map() = 0;
};

/**
 * @brief Output sink pull offer stream buffer external SDK/APP, register to output stream.
 */
class ByteAudioOutputSink {
public:
    virtual ~ByteAudioOutputSink() = default;

    /**
     * @brief Feed stream buffer into output stream when this func callback
     * @param stream: handle of output stream
     * @param buf: stream buffer, refer to @ByteAudioStreamBuffer
     * @param options: pull options, only used for RealX jitterbuffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int on_pull_audio_buffer(ByteAudioOutputStream* stream, ByteAudioStreamBuffer& buf,
                                     ByteAudioPullBufferOptions* options) = 0;
};

class ByteAudioOutputFrameObserver {
public:
    /**
     * @brief Callback the decoded pcm stream buffer from output stream.
     * need set
     * @param stream: handle of output stream
     * @param buf: stream buffer, refer to @ByteAudioStreamBuffer
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int on_audio_frame_decoded(ByteAudioOutputStream* stream, ByteAudioStreamBuffer& buf) = 0;
};

class IByteAudioEngine {
public:
    struct CreateOptions {};

    /**
     * @brief 
     * Get a shared intance of IByteAudioEngine.
     * The reference count of the shared intance will be increased
     * 
     * @return pointer of IByteAudioEngine
     */
    static IByteAudioEngine* get_engine_instance();

    /**
     * @brief 
     * Decrease the reference count of the shared intance of IByteAudioEngine.
     * @return the rest reference count of the shared intance 
     * @attention 
     * The static engine instance will be deleted when reference count 
     * equals to zero.
    */
    static int release_engine_instance();

    /**
     * @brief Create a new ByteAudio Engine.
     *
     * @return pointer of IByteAudioEngine
     *
     * @attention 
     * The instance returned from create_engine does not support realx audio device.
     * If you want to use realx audio device, please use the instance returned by get_engine_instance()
     */
    BYTEAUDIO_API static IByteAudioEngine* create_engine(const CreateOptions& options);

    /**
     * @brief destroy the audio engine returned by create_engine().
     *
     * @param engine  pointer of IByteAudioEngine
     */
    BYTEAUDIO_API static void destroy_engine(IByteAudioEngine* engine);

    /**
     * @brief get the audio device manager for this engine
     * @return pointer of IByteAudioDeviceManager
     * @attention 
     * If the audio engine is created by get_engine_instance(), this point of IByteAudioDeviceManager
     * support real audio device, if created by create_engine() then will no real device ability
     */
    virtual IByteAudioDeviceManager* get_audio_device_manager() = 0;

    /**
     * @brief Set server configure.
     * @param cfg: type of json string, contains server configure info
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_server_configure(const std::string& cfg) = 0;

    /**
     * @brief Add event handler to ByteAudio. ByteAudio can notify event to every external listener.
     * @param event_handler: refer to @ByteAudioEventHandler
     */
    virtual void add_event_handler(ByteAudioEventHandler* event_handler) = 0;

    /**
     * @brief Remove event handler from ByteAudio. If once removed, ByteAudio no longer notify event to external.
     * listener
     * @param event_handler: refer to @ByteAudioEventHandler
     */
    virtual void remove_event_handler(ByteAudioEventHandler* event_handler) = 0;

    /**
     * @brief Create a new input stream.
     * @attention The external needs hold the @ByteAudioInputStream handle, and must release it by destroy_input_stream
     * after used
     * @param name: name of stream called by external SDK/APP
     * @return handle of @ByteAudioInputStream
     */
    virtual ByteAudioInputStream* create_input_stream(const std::string& name) = 0;

    /**
     * @brief Destory a input stream.
     * @param input_stream: handle of @ByteAudioInputStream
     */
    virtual void destroy_input_stream(ByteAudioInputStream* input_stream) = 0;

    /**
     * @brief Create a new output stream.
     * @attention The external needs hold the @ByteAudioOutputStream handle, and must release it by
     * destroy_output_stream after used
     * @param name: name of stream called by external SDK/APP
     * @return handle of @ByteAudioOutputStream
     */
    virtual ByteAudioOutputStream* create_output_stream(const std::string& name) = 0;

    /**
     * @brief Destory a output stream.
     * @param output_stream: handle of @ByteAudioOutputStream
     */
    virtual void destroy_output_stream(ByteAudioOutputStream* output_stream) = 0;

    /**
     * @brief Create a new aux stream.
     * @attention The external needs hold the @ByteAudioAuxStream handle, and must release it by
     * destroy_aux_stream after used
     * @param name: name of stream called by external SDK/APP
     * @return handle of @ByteAudioAuxStream
     */
    virtual ByteAudioAuxStream* create_aux_stream(const std::string& name) = 0;

    /**
     * @brief Destory a aux stream.
     * @param aux_stream: handle of @ByteAudioAuxStream
     */
    virtual void destroy_aux_stream(ByteAudioAuxStream* aux_stream) = 0;

    /**
     * @brief Query supported audio encode codecs by ByteAudio.
     * @return vector of ByteAudioStreamFormat, contains codec_type/sample_rate/channel_num/default_bitrate combination
     */
    virtual const std::vector<ByteAudioStreamFormat> supported_encode_formats() const = 0;

    /**
     * @brief Query supported audio encode codecs by ByteAudio in rtc
     * @return vector of ByteAudioStreamFormat, contains codec_type/sample_rate/channel_num/default_bitrate combination
     */
    virtual const std::vector<ByteAudioStreamFormat> supported_rtc_encode_formats() const = 0;

    /**
     * @brief Query supported audio decode codecs by ByteAudio.
     * @return vector of ByteAudioStreamFormat, contains codec_type/sample_rate/channel_num/default_bitrate combination
     */
    virtual const std::vector<ByteAudioStreamFormat> supported_decode_formats() const = 0;

    /** Deprecated, please using the interface in bae_device_manager_interface.h
     * @brief Set mobile route to speakerphone.
     * @param enable
     *        true: route to speakerphone
     *        false: route to earpiece
     */
    virtual void set_enable_speakerphone(bool enable) = 0;

    /** Deprecated, please using the interface in bae_device_manager_interface.h
     * @brief Enable mobile audio route change.
     * @param enable
     *        true: enable mobile audio route change.
     *        false: disable mobile audio route change.
     */
    virtual void enable_audio_router(bool enable) = 0;

    /**
     * @brief Set enable ear monitor that can hear what you said.
     * @param enable
     *        true: enable
     *        false: disable
     */
    virtual void enable_ear_monitor(bool enable) = 0;

    /**
     * @brief init ear monitor that can hear what you said.
     * @attention only valid on Android.
     */
    virtual int init_ear_monitor() = 0;

    /** Deprecated, please using the interface in bae_device_manager_interface.h
     * @brief Set headset monitor volume, which is different with record/playback volume.
     * @param volume: headset monitor volume
     */
    virtual int adjust_headset_monitor_volume(int volume) = 0;

    /**
     * @brief Enable/disable external audio source.
     * @attention only valid when has no streams
     * @param enable: enable or disable external audio source
     * @param rec_sr: external record sample rate
     * @param rec_chn: external record channel nums
     * @param play_sr: external playout sample rate
     * @param play_chn: external plaout channel nums
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int set_external_audio_source(bool enable, int rec_sr, int rec_chn, int play_sr, int play_chn) = 0;

    /**
     * @brief Query external audio source is enabled.
     * @return external audio is enabled or disabled
     */
    virtual bool is_external_audio_source() = 0;

    /**
     * @brief Push external audio buffer for audio record in external audio source.
     * @attention only valid when external audio source  is enabled
     * @param buffer stream buffer for push data. ByteAudio will copy memory.
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int push_external_audio_buffer(ByteAudioStreamBuffer* buffer) = 0;

    /**
     * @brief Pull external audio buffer for audio playout in external audio source.
     * @attention only valid when external audio source is enabled
     * @param buffer stream buffer for pull data. ByteAudio write memory in buffer.
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int pull_external_audio_buffer(ByteAudioStreamBuffer* buffer) = 0;

    /**
     * @brief register external filter process sink for audio preprocess, this filter is used after headset ear monitor.
     * @attention byteaudio only callback the last filter when set repeatedly.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void register_input_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief unregister external filter process sink for audio preprocess.
     * @attention please manual disable after usage.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void unregister_input_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief register external filter process sink for front audio preprocess, this filter is used before headset ear monitor.
     * @attention byteaudio only callback the last filter when set repeatedly.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void register_front_input_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief unregister external filter process sink for front audio preprocess.
     * @attention please manual disable after usage.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void unregister_front_input_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief register external filter process sink for audio postprocess.
     * @attention byteaudio only callback the last filter when set repeatedly.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void register_output_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief unregister external filter process sink for audio postprocess.
     * @attention please manual disable after usage.
     * @param filter: the callback sink for usage of external process.
     */
    virtual void unregister_output_filter(ByteAudioFilter* filter) = 0;

    /**
     * @brief Disables/Re-enables the local audio
     * The audio function is enabled by default. This method disables or re-enables the local audio function, that is,
     * to stop or restart local audio capturing.
     * @param enable: Sets whether to disable/re-enable the local audio function
     *                true: (Default) Re-enable the local audio, that is, to start the local audio capturing device
     *                false: Disable the local audio function, that is, to stop local audio capturing.
     */
    virtual void enable_local_audio(bool enabled) = 0;

    /**
     * @brief Set audio scenario
     * @param scenario: Set the audio scenario, see @ByteAudioScenarioType.
     *                  Note: 1. only valid in Android/iOS.
     *                        2. support runtime change to device
     */
    virtual int set_audio_scenario(ByteAudioScenarioType scenario) = 0;

    /**
     * @brief Customize the audio mode strategy for the type of audio scenario
     * @param scenario_strategy: the scenario strategy with the type of ByteAudioScenarioType that want to customize, see @ByteAudioScenarioStrategy.
     *                  Note: 1. will be reset to default after every time that the last stream stop
     *                        2. support runtime change to device
     *                        3. only valid in Android/iOS.
     */
    virtual int customize_audio_scenario(const ByteAudioScenarioStrategy& scenario_strategy) = 0;

    /**
     * @brief Adjusts the recording volume of all input streams.
     * @param [in] volume: volume of recording for all input streams, scope: 0 ~ 400 (default 100)
     */
    virtual int adjust_record_volume(int volume) = 0;

    /**
     * @brief Adjusts the playback volume of all output & aux streams.
     * @param [in] volume: volume of all output & aux streams for playback, scope: 0 ~ 400 (default 100)
     */
    virtual int adjust_playback_volume(int volume) = 0;

    /**
     * @brief Enable/Disable screen audio capture.
     * @param enable whether to enable or disable screen audio capture (default disabled).
     * @param is_external_source whether if external screen source.
     */
    virtual int enable_screen_capture(bool enable, bool is_external_source = false) = 0;

    /**
     * @brief Adjusts the screen audio capture stream volume.
     * @param volume volume of screen audio capture stream, scope: 0 ~ 400 (default 100).
     */
    virtual int adjust_screen_volume(int volume) = 0;

    /**
     * @brief set optional values to engine.
     * @attention valid at all times.
     * @param key option key, defined in private interface. refer to `ByteAudioEnginePrivateOptionKey` in `bae_engine_interface_private.h`
     * @param value value to be set.
     * @return error code, refer to @ByteAudioErrorCode.
     */
    virtual int set_value(int key, ByteAudioValue value) = 0;

    /**
     * @brief Push share audio buffer for audio record in ios and android.
     * @attention only valid when enable_screen_capture() set true
     * @param buffer stream buffer for push data. ByteAudio will copy memory.
     * @return error code, refer to @ByteAudioErrorCode
     */
    virtual int push_external_screen_buffer(ByteAudioStreamBuffer* buffer) = 0;

    virtual int push_external_reference_buffer(size_t trackId, ByteAudioStreamBuffer& buffer) = 0;

    /**
     * @brief report statistic of audio engine
     * @return refer to @ByteAudioOutPutStreamReport
     */
    virtual ByteAudioEngineReport get_engine_report() = 0;

    /**
     * @brief set audio sample callback
     * @param context
     * @param callback
     */
    virtual void set_audio_sample_callback(void * context, void (*callback)(void*, int, const std::string&)) = 0;


    /**
     * @brief start audio sample
     * @param path: the folder to contain the dump files
     * @param mode: mode, 0 for standard mode ,i.e. only dump AEC_in, before_encoder and mix_out; 100 for full mode. dump as possible as it can
     * @return error code
     */
    virtual int start_audio_sample(const std::string& path, AudioSampleConfigure config) = 0;

    /**
     * @brief stop audio sample
     * @return error code
     */
    virtual int stop_audio_sample() = 0;

    /**
     * @brief get optinal values from engine.
     * @param key option key, defined in private interface.
     * @param value value to be get.
     * @return error code, refer to @ByteAudioErrorCode.
     */
    virtual int get_value(int key, ByteAudioValue* value) = 0;

    /**
     * @brief share cpu state with rx_media_engine.
     * @param cpu_overload_times to be set.
     */
    virtual void set_cpu_overload_times(int cpu_overload_times) = 0;

    /**

     * @brief get engine input report statistics
     * @return report statistics, refer to @ByteAudioEngineInputReport
     */
    virtual ByteAudioEngineInputReport get_engine_input_report() = 0;

    /**
     * @brief get engine input report statistics
     * @return report map with <report name, report value>
     */
    virtual std::map<std::string, std::string> get_engine_input_report_map() = 0;

    /**
     * @brief get engine output report statistics
     * @return report statistics, refer to @ByteAudioEngineOutputReport
     */
    virtual ByteAudioEngineOutputReport get_engine_output_report() = 0;

    /**
     * @brief get engine output report statistics
     * @return report map with <report name, report value>
     */
    virtual std::map<std::string, std::string> get_engine_output_report_map() = 0;

    /**
     * @brief set local spatializer enable
     * 
     */

    virtual void set_spatializer_enable(bool enable) = 0;
};

BYTEAUDIO_API IByteAudioEngine* get_engine_instance();

BYTEAUDIO_API int release_engine_instance();
}  // namespace bae
