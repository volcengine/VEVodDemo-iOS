//
//  TVLManager+VideoProcessing.h
//  TTVideoLive
//
//  Created by chenzhaojie on 2020/7/31.
//

#import "TVLManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface TVLManager (VideoProcessing)

@property (nonatomic, assign) BOOL shouldForbidVideoProcess;

@property (nonatomic, assign) BOOL enableVideoProcess;

@end

NS_ASSUME_NONNULL_END
