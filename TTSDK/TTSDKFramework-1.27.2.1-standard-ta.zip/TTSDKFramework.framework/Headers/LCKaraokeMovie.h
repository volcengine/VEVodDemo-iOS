#ifndef LCKaraokeMovie_h
#define LCKaraokeMovie_h

#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import <UIKit/UIKit.h>

@class LiveCore;
@class LCKaraokeMovie;
@protocol LCPlayerProtocol;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LCPlayerPlaybackState) {
    LCPlayerPlaybackStateUnknown,
    LCPlayerPlaybackStateStopped,   
    LCPlayerPlaybackStatePlaying,   
    LCPlayerPlaybackStatePaused,    
    LCPlayerPlaybackStateError,     
};

typedef NS_ENUM(NSInteger, LCPlayerLoadState) {
    LCPlayerLoadStateUnknown,
    LCPlayerLoadStateStalled,   
    LCPlayerLoadStatePlayable,  
    LCPlayerLoadStateError,     
};

@protocol LCKaraokeMovieDelegate <NSObject>

@optional

- (void)didFirstVideoReceived:(LCKaraokeMovie *)karaokeMovie;

- (void)karaokeMovie:(LCKaraokeMovie *)karaokeMovie didPlayFinishedWithError:(nullable NSError *)error;

- (void)karaokeMovie:(LCKaraokeMovie *)karaokeMovie playbackStateDidChanged:(LCPlayerPlaybackState)playbackState;

- (void)karaokeMovie:(LCKaraokeMovie *)karaokeMovie loadStateDidChanged:(LCPlayerLoadState)loadState;

@end

@protocol LCPlayerDelegate <NSObject>

@optional

- (void)videoPlayerDidFinish:(id<LCPlayerProtocol>)player error:(nullable NSError *)error;

- (void)player:(id<LCPlayerProtocol>)player playbackStateDidChanged:(LCPlayerPlaybackState)playbackState;

- (void)player:(id<LCPlayerProtocol>)player loadStateDidChanged:(LCPlayerLoadState)loadState;

@end

@protocol LCPlayerProtocol <NSObject>

@property (nonatomic, weak) id<LCPlayerDelegate> delegate;

- (void)setAudioWrapper:(void *)audioWrapper;

- (void)setVideoWrapper:(void *)videoWrapper;

- (void)setLocalURL:(NSString *)url;

- (void)play;

- (void)stop;

- (void)close;

- (void)restart;

- (void)pause;

- (void)resume;

- (void)seekPlayerTimeTo:(NSTimeInterval)time;

- (BOOL)isPlaying;

- (float)getTotalPlayTime;

- (float)getCurrentPlayTime;

- (void)setVolume:(float)volume;
- (float)getVolume;

- (void)mute:(BOOL)enable;

@end

@interface LCKaraokeMovie : NSObject

- (instancetype)initWithLiveCore:(LiveCore *)liveCore player:(id<LCPlayerProtocol>)player;

@property (nonatomic, weak) id<LCKaraokeMovieDelegate> delegate;

@property (nonatomic, assign) BOOL forceSendFirstFrameTwice;

#pragma mark -- player interface

- (void)setLocalURL:(NSString *)url;

- (void)prepare;

- (void)play;

- (void)stop;

- (void)close;

- (void)restart;

- (void)pause;

- (void)resume;

- (void)seekPlayerTimeTo:(NSTimeInterval)time;

- (BOOL)isPlaying;

- (float)getTotalPlayTime;

- (float)getCurrentPlayTime;

- (void)setVolume:(float)volume;

- (float)getVolume;

- (void)setEnableKaraokeMovieAudioPitchShifter:(BOOL)enable;
- (BOOL)isEnableKaraokeMovieAudioPitchShifter;
- (void)setKaraokeMoviePitch:(double)pitch;

- (void)mute:(BOOL)enable;

#pragma mark -- video && audio process

- (void)setKaraokeVideoMixerDescription:(NSInteger)index withPosition:(CGRect)rect;

- (void)setKaraokeVideoMixerDescription:(NSInteger)index zOrder:(int)zOrder withPosition:(CGRect)rect;

- (void)setMovieRenderView:(UIView *)view;

- (void)prepareKaraokeMovieAudio:(int)sampleRate channels:(int)channesNumber;

- (void)pushKaraokeMovieBuffer:(CVPixelBufferRef)pixelBuffer andCMTime:(CMTime)pts;

- (void)pushKaraokeMovieAudioBuffer:(float **)audioData samples:(int)samples;

- (void)setKaraokeMixVolume:(float)karaokeVolume captureVolume:(float)captureVolume;

- (void)setKaraokePlayVolume:(float)karaokeVolume;

- (void)videoWrapperRelease;

- (void)audioWrapperRelease;

@end

NS_ASSUME_NONNULL_END

#endif 
